import UIKit

final class NotesSplitContainerViewController: UIViewController,
    NotesListDelegate,
    NoteEditorDelegate {

    var onRequestOpenClickTab: (() -> Void)?
    var onLiveModeChanged: ((Bool) -> Void)?
    var onWakeLockConditionChanged: (() -> Void)?

    private let sidebarVC = NotesListViewController()
    private let editorVC = NoteEditorViewController()

    private var allNotes: [Note] = []
    private var preferences: AppPreferences = .default
    private var selectedNoteId: String?
    private var searchQuery: String = ""
    private var filterTab: NotesFilterTab = .all
    private var sidebarVisibleWide: Bool = true
    private var compactShowEditor: Bool = false
    private var importingFiles: Bool = false

    private var sidebarWidthConstraint: NSLayoutConstraint!
    private var sidebarLeadingConstraint: NSLayoutConstraint!
    private var editorLeadingToSidebar: NSLayoutConstraint!
    private var editorLeadingToView: NSLayoutConstraint!

    private var saveWorkItem: DispatchWorkItem?
    private var pendingSaveNoteId: String?
    private let toastLabel = UILabel()
    private var toastHideWork: DispatchWorkItem?

    var hasActiveNoteOrReader: Bool {
        return selectedNoteId != nil || presentedViewController is FastSheetReaderViewController
    }

    var isLiveMode: Bool {
        return preferences.liveMode
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = AtrilColors.editorSurface

        setupChildControllers()
        setupToast()
        bootstrapData()

        NotificationCenter.default.addObserver(
            self,
            selector: #selector(flushPendingSaves),
            name: UIApplication.willResignActiveNotification,
            object: nil
        )
    }

    deinit {
        NotificationCenter.default.removeObserver(self)
        flushPendingSaves()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        applyAdaptiveSplitLayout()
    }

    private func setupChildControllers() {
        sidebarVC.delegate = self
        editorVC.delegate = self
        editorVC.onEmptyCreateNote = { [weak self] in
            self?.notesListDidCreateNote()
        }

        addChild(sidebarVC)
        addChild(editorVC)

        sidebarVC.view.translatesAutoresizingMaskIntoConstraints = false
        editorVC.view.translatesAutoresizingMaskIntoConstraints = false

        view.addSubview(sidebarVC.view)
        view.addSubview(editorVC.view)

        sidebarVC.didMove(toParent: self)
        editorVC.didMove(toParent: self)

        sidebarWidthConstraint = sidebarVC.view.widthAnchor.constraint(equalToConstant: 300)
        sidebarLeadingConstraint = sidebarVC.view.leadingAnchor.constraint(equalTo: view.leadingAnchor)
        editorLeadingToSidebar = editorVC.view.leadingAnchor.constraint(equalTo: sidebarVC.view.trailingAnchor)
        editorLeadingToView = editorVC.view.leadingAnchor.constraint(equalTo: view.leadingAnchor)

        NSLayoutConstraint.activate([
            sidebarVC.view.topAnchor.constraint(equalTo: view.topAnchor),
            sidebarVC.view.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            sidebarLeadingConstraint,
            sidebarWidthConstraint,

            editorVC.view.topAnchor.constraint(equalTo: view.topAnchor),
            editorVC.view.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            editorVC.view.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            editorLeadingToSidebar
        ])
    }

    private func setupToast() {
        toastLabel.font = .systemFont(ofSize: 13, weight: .medium)
        toastLabel.textAlignment = .center
        toastLabel.layer.cornerRadius = 12
        toastLabel.layer.borderWidth = 1
        toastLabel.clipsToBounds = true
        toastLabel.alpha = 0
        toastLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(toastLabel)

        NSLayoutConstraint.activate([
            toastLabel.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -16),
            toastLabel.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -16),
            toastLabel.heightAnchor.constraint(greaterThanOrEqualToConstant: 38),
            toastLabel.widthAnchor.constraint(lessThanOrEqualToConstant: 340)
        ])
    }

    private func showToast(_ text: String, isError: Bool = false) {
        toastHideWork?.cancel()
        toastLabel.text = "   \(text)   "
        if isError {
            toastLabel.backgroundColor = UIColor(hex: 0x2C1B1B)
            toastLabel.layer.borderColor = AtrilColors.red.withAlphaComponent(0.4).cgColor
            toastLabel.textColor = UIColor(hex: 0xFF6961)
        } else {
            toastLabel.backgroundColor = UIColor(hex: 0x25252A)
            toastLabel.layer.borderColor = AtrilColors.borderLight.cgColor
            toastLabel.textColor = AtrilColors.textPrimary
        }

        UIView.animate(withDuration: 0.18) {
            self.toastLabel.alpha = 1
        }

        let work = DispatchWorkItem { [weak self] in
            UIView.animate(withDuration: 0.25) {
                self?.toastLabel.alpha = 0
            }
        }
        toastHideWork = work
        DispatchQueue.main.asyncAfter(deadline: .now() + 3.0, execute: work)
    }

    private func bootstrapData() {
        do {
            let result = try AtrilRepository.shared.bootstrap()
            allNotes = result.notes
            preferences = result.preferences
            let sorted = NoteLogic.filterAndSortNotes(allNotes, query: searchQuery, tab: filterTab)
            selectedNoteId = sorted.first?.id
            onLiveModeChanged?(preferences.liveMode)
            refreshChildUI()
        } catch {
            showToast(error.localizedDescription, isError: true)
        }
    }

    private func isCompactWidth() -> Bool {
        return view.bounds.width < 840
    }

    private func applyAdaptiveSplitLayout() {
        let compact = isCompactWidth()
        let width = view.bounds.width
        guard width > 0 else { return }

        if compact {
            sidebarWidthConstraint.constant = width
            if compactShowEditor && selectedNoteId != nil {
                sidebarVC.view.isHidden = true
                editorVC.view.isHidden = false
                editorLeadingToSidebar.isActive = false
                editorLeadingToView.isActive = true
            } else {
                sidebarVC.view.isHidden = false
                editorVC.view.isHidden = true
                editorLeadingToSidebar.isActive = false
                editorLeadingToView.isActive = true
            }
        } else {
            let sidebarW: CGFloat = width >= 1180 ? 320 : 290
            sidebarWidthConstraint.constant = sidebarW
            if sidebarVisibleWide {
                sidebarVC.view.isHidden = false
                editorVC.view.isHidden = false
                editorLeadingToView.isActive = false
                editorLeadingToSidebar.isActive = true
            } else {
                sidebarVC.view.isHidden = true
                editorVC.view.isHidden = false
                editorLeadingToSidebar.isActive = false
                editorLeadingToView.isActive = true
            }
        }
    }

    private func refreshChildUI() {
        let visible = NoteLogic.filterAndSortNotes(allNotes, query: searchQuery, tab: filterTab)
        let storage = AtrilRepository.shared.getStorageStatus(notes: allNotes)
        let selected = allNotes.first { $0.id == selectedNoteId }

        sidebarVC.update(notes: visible, selectedNoteId: selectedNoteId, storageStatus: storage, searchQuery: searchQuery)
        editorVC.configure(
            note: selected,
            liveMode: preferences.liveMode,
            sidebarVisible: sidebarVisibleWide,
            isCompactLayout: isCompactWidth(),
            importingFiles: importingFiles
        )
        applyAdaptiveSplitLayout()
        onWakeLockConditionChanged?()
    }

    func exitLiveModeFromClickPanel() {
        if preferences.liveMode {
            preferences.liveMode = false
            AtrilRepository.shared.savePreferences(preferences)
            onLiveModeChanged?(false)
            refreshChildUI()
        }
    }

    @objc func flushPendingSaves() {
        saveWorkItem?.cancel()
        saveWorkItem = nil
        if let id = pendingSaveNoteId, let note = allNotes.first(where: { $0.id == id }) {
            pendingSaveNoteId = nil
            try? AtrilRepository.shared.saveNote(note)
        }
    }

    private func scheduleDebouncedSave(noteId: String) {
        saveWorkItem?.cancel()
        pendingSaveNoteId = noteId
        let work = DispatchWorkItem { [weak self] in
            guard let self = self else { return }
            self.pendingSaveNoteId = nil
            if let latest = self.allNotes.first(where: { $0.id == noteId }) {
                try? AtrilRepository.shared.saveNote(latest)
            }
        }
        saveWorkItem = work
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.35, execute: work)
    }

    // MARK: - NotesListDelegate

    func notesListDidSelectNote(_ id: String) {
        flushPendingSaves()
        selectedNoteId = id
        compactShowEditor = true
        refreshChildUI()
    }

    func notesListDidCreateNote() {
        flushPendingSaves()
        let now = Int64(Date().timeIntervalSince1970 * 1000)
        let newNote = Note(
            id: NoteLogic.createId(prefix: "note"),
            title: "",
            body: "",
            pinned: false,
            attachments: [],
            blocks: [NoteBlock(id: NoteLogic.createId(prefix: "blk"), text: "")],
            createdAt: now,
            updatedAt: now
        )
        allNotes.insert(newNote, at: 0)
        selectedNoteId = newNote.id
        compactShowEditor = true
        do {
            try AtrilRepository.shared.saveNote(newNote)
        } catch {
            showToast("No se pudo crear la nota.", isError: true)
        }
        refreshChildUI()
    }

    func notesListDidTogglePin(_ note: Note) {
        flushPendingSaves()
        guard let idx = allNotes.firstIndex(where: { $0.id == note.id }) else { return }
        allNotes[idx].pinned.toggle()
        allNotes[idx].updatedAt = Int64(Date().timeIntervalSince1970 * 1000)
        let updated = allNotes[idx]
        do {
            try AtrilRepository.shared.saveNote(updated)
            showToast(updated.pinned ? "Nota fijada." : "Nota desfijada.")
        } catch {
            showToast("No se pudo actualizar la nota.", isError: true)
        }
        refreshChildUI()
    }

    func notesListDidRequestDelete(_ note: Note) {
        let title = note.title.trimmingCharacters(in: .whitespacesAndNewlines)
        let display = title.isEmpty ? "Nota sin título" : title
        let alert = UIAlertController(
            title: "Eliminar nota",
            message: "¿Seguro que quieres eliminar \"\(display)\"?",
            preferredStyle: .alert
        )
        alert.addAction(UIAlertAction(title: "Cancelar", style: .cancel))
        alert.addAction(UIAlertAction(title: "Eliminar", style: .destructive) { [weak self] _ in
            self?.performDeleteNote(note)
        })
        present(alert, animated: true)
    }

    private func performDeleteNote(_ note: Note) {
        if pendingSaveNoteId == note.id {
            saveWorkItem?.cancel()
            pendingSaveNoteId = nil
        }
        allNotes.removeAll { $0.id == note.id }
        if selectedNoteId == note.id {
            let sorted = NoteLogic.filterAndSortNotes(allNotes, query: searchQuery, tab: filterTab)
            selectedNoteId = sorted.first?.id
            compactShowEditor = false
        }
        do {
            try AtrilRepository.shared.deleteNoteAndFiles(note)
            showToast("Nota eliminada.")
        } catch {
            showToast("No se pudo eliminar la nota.", isError: true)
        }
        refreshChildUI()
    }

    func notesListDidChangeSearch(_ query: String) {
        searchQuery = query
        refreshChildUI()
    }

    func notesListDidChangeFilter(_ tab: NotesFilterTab) {
        filterTab = tab
        refreshChildUI()
    }

    func notesListDidOpenBackup() {
        flushPendingSaves()
        let status = AtrilRepository.shared.getStorageStatus(notes: allNotes)
        let backupVC = BackupViewController(storageStatus: status, optimizeImagesFor16GB: preferences.optimizeImagesFor16GB)
        backupVC.onToggleOptimizeImages = { [weak self] val in
            guard let self = self else { return }
            self.preferences.optimizeImagesFor16GB = val
            AtrilRepository.shared.savePreferences(self.preferences)
        }
        backupVC.onDidRestoreBackup = { [weak self] in
            guard let self = self else { return }
            if let restored = try? AtrilRepository.shared.getAllNotes() {
                self.allNotes = restored
                let sorted = NoteLogic.filterAndSortNotes(restored, query: "", tab: .all)
                if let cur = self.selectedNoteId, restored.contains(where: { $0.id == cur }) {
                    self.selectedNoteId = cur
                } else {
                    self.selectedNoteId = sorted.first?.id
                }
                self.refreshChildUI()
            }
        }
        present(backupVC, animated: true)
    }

    // MARK: - NoteEditorDelegate

    func noteEditorDidTapCompactBack() {
        flushPendingSaves()
        compactShowEditor = false
        refreshChildUI()
    }

    func noteEditorDidTapToggleSidebar() {
        sidebarVisibleWide.toggle()
        refreshChildUI()
    }

    func noteEditorDidToggleLiveMode() {
        let nextLive = !preferences.liveMode
        if nextLive {
            MetronomeAudioEngine.shared.stop()
            showToast("Modo en vivo activado: click silenciado.")
        } else {
            showToast("Modo estudio activado.")
        }
        preferences.liveMode = nextLive
        AtrilRepository.shared.savePreferences(preferences)
        onLiveModeChanged?(nextLive)
        refreshChildUI()
    }

    func noteEditorDidTapOpenClickPanel() {
        onRequestOpenClickTab?()
    }

    func noteEditorDidUpdateNote(_ noteId: String, title: String?, body: String?, blocks: [NoteBlock]?) {
        guard let idx = allNotes.firstIndex(where: { $0.id == noteId }) else { return }
        if let title = title { allNotes[idx].title = title }
        if let body = body { allNotes[idx].body = body }
        if let blocks = blocks { allNotes[idx].blocks = blocks }
        allNotes[idx].updatedAt = Int64(Date().timeIntervalSince1970 * 1000)
        scheduleDebouncedSave(noteId: noteId)

        let visible = NoteLogic.filterAndSortNotes(allNotes, query: searchQuery, tab: filterTab)
        let storage = AtrilRepository.shared.getStorageStatus(notes: allNotes)
        sidebarVC.update(notes: visible, selectedNoteId: selectedNoteId, storageStatus: storage, searchQuery: searchQuery)
    }

    func noteEditorDidImportItems(_ noteId: String, items: [(fileName: String, mimeType: String?, data: Data)], insertContext: (blockId: String?, cursorPos: Int?)) {
        importingFiles = true
        refreshChildUI()

        let optimize = preferences.optimizeImagesFor16GB
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            var newAtts: [NoteAttachment] = []
            for item in items {
                if let prepared = AtrilRepository.shared.prepareImportedFile(
                    rawData: item.data,
                    fileName: item.fileName,
                    mimeType: item.mimeType,
                    optimizeFor16GB: optimize
                ) {
                    do {
                        try AtrilRepository.shared.saveBinaryData(prepared.storedData, forAttachmentId: prepared.attachment.id)
                        newAtts.append(prepared.attachment)
                    } catch {
                        // Continue remaining files
                    }
                }
            }

            DispatchQueue.main.async {
                guard let self = self else { return }
                self.importingFiles = false
                guard !newAtts.isEmpty, let idx = self.allNotes.firstIndex(where: { $0.id == noteId }) else {
                    self.showToast("No se pudieron importar los archivos.", isError: true)
                    self.refreshChildUI()
                    return
                }

                self.flushPendingSaves()
                var target = self.allNotes[idx]
                let baseBlocks = NoteLogic.normalizeNoteBlocks(target)
                let nextBlocks = NoteLogic.insertSheetsIntoBlocks(
                    baseBlocks,
                    targetTextBlockId: insertContext.blockId,
                    cursorPos: insertContext.cursorPos,
                    newAttachmentIds: newAtts.map { $0.id }
                )
                let combinedAtts = NoteLogic.orderAttachmentsByBlocks(nextBlocks, attachments: target.attachments + newAtts)
                target.blocks = nextBlocks
                target.body = NoteLogic.deriveBodyFromBlocks(nextBlocks)
                target.attachments = combinedAtts
                target.updatedAt = Int64(Date().timeIntervalSince1970 * 1000)

                self.allNotes[idx] = target
                try? AtrilRepository.shared.saveNote(target)
                self.showToast(newAtts.count == 1 ? "Archivo añadido." : "\(newAtts.count) archivos añadidos.")
                self.refreshChildUI()
            }
        }
    }

    func noteEditorDidRemoveAttachment(_ noteId: String, attachmentId: String) {
        guard let idx = allNotes.firstIndex(where: { $0.id == noteId }) else { return }
        flushPendingSaves()
        var target = allNotes[idx]
        let nextBlocks = NoteLogic.removeSheetFromBlocks(NoteLogic.normalizeNoteBlocks(target), attachmentId: attachmentId)
        target.blocks = nextBlocks
        target.body = NoteLogic.deriveBodyFromBlocks(nextBlocks)
        target.attachments.removeAll { $0.id == attachmentId }
        target.updatedAt = Int64(Date().timeIntervalSince1970 * 1000)
        allNotes[idx] = target

        AtrilRepository.shared.deleteBinary(forAttachmentId: attachmentId)
        try? AtrilRepository.shared.saveNote(target)
        refreshChildUI()
    }

    func noteEditorDidOpenReader(_ noteId: String, attachmentId: String, pageNumber: Int) {
        guard let note = allNotes.first(where: { $0.id == noteId }), !note.attachments.isEmpty else { return }
        let reader = FastSheetReaderViewController(
            note: note,
            initialAttachmentId: attachmentId,
            initialPageNumber: pageNumber,
            liveMode: preferences.liveMode
        )
        present(reader, animated: true) { [weak self] in
            self?.onWakeLockConditionChanged?()
        }
    }
}
