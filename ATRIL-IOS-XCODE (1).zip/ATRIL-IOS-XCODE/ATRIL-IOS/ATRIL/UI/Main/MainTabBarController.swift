import UIKit

/// Root ATRIL shell providing the unified 3-panel bottom dock (`Notas · Click · Afinador`),
/// live BPM badge on the Click tab, keyboard-safe hiding, and screen wake lock.
final class MainTabBarController: UIViewController, MetronomeObserver {
    private let notesSplitVC = NotesSplitContainerViewController()
    private let clickVC = ClickViewController()
    private let tunerVC = TunerViewController()

    private var activeTab: WorkspaceTab = .notes
    private var currentController: UIViewController?

    private let contentContainer = UIView()
    private let dockBar = UIView()
    private var dockHeightConstraint: NSLayoutConstraint!
    private var dockHiddenByKeyboard = false

    private let notesTabBtn = UIButton(type: .system)
    private let clickTabBtn = UIButton(type: .system)
    private let tunerTabBtn = UIButton(type: .system)

    override var preferredStatusBarStyle: UIStatusBarStyle { .lightContent }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = AtrilColors.bgPrimary

        setupLayout()
        wireCallbacks()

        MetronomeAudioEngine.shared.addObserver(self)
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(handleKeyboardWillShow),
            name: UIResponder.keyboardWillShowNotification,
            object: nil
        )
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(handleKeyboardWillHide),
            name: UIResponder.keyboardWillHideNotification,
            object: nil
        )

        switchToTab(.notes)
        updateWakeLock()
    }

    deinit {
        MetronomeAudioEngine.shared.removeObserver(self)
        NotificationCenter.default.removeObserver(self)
        UIApplication.shared.isIdleTimerDisabled = false
    }

    private func setupLayout() {
        contentContainer.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(contentContainer)

        dockBar.backgroundColor = AtrilColors.dock
        dockBar.clipsToBounds = true
        dockBar.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(dockBar)

        let topBorder = UIView()
        topBorder.backgroundColor = AtrilColors.borderSubtle
        topBorder.translatesAutoresizingMaskIntoConstraints = false
        dockBar.addSubview(topBorder)

        configureDockButton(notesTabBtn, tag: WorkspaceTab.notes.rawValue)
        configureDockButton(clickTabBtn, tag: WorkspaceTab.click.rawValue)
        configureDockButton(tunerTabBtn, tag: WorkspaceTab.tuner.rawValue)

        let stack = UIStackView(arrangedSubviews: [notesTabBtn, clickTabBtn, tunerTabBtn])
        stack.axis = .horizontal
        stack.distribution = .fillEqually
        stack.spacing = 8
        stack.translatesAutoresizingMaskIntoConstraints = false
        dockBar.addSubview(stack)

        let guide = view.safeAreaLayoutGuide
        dockHeightConstraint = dockBar.heightAnchor.constraint(equalToConstant: 56)

        NSLayoutConstraint.activate([
            contentContainer.topAnchor.constraint(equalTo: view.topAnchor),
            contentContainer.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            contentContainer.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            contentContainer.bottomAnchor.constraint(equalTo: dockBar.topAnchor),

            dockBar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            dockBar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            dockBar.bottomAnchor.constraint(equalTo: guide.bottomAnchor),
            dockHeightConstraint,

            topBorder.topAnchor.constraint(equalTo: dockBar.topAnchor),
            topBorder.leadingAnchor.constraint(equalTo: dockBar.leadingAnchor),
            topBorder.trailingAnchor.constraint(equalTo: dockBar.trailingAnchor),
            topBorder.heightAnchor.constraint(equalToConstant: 1),

            stack.centerXAnchor.constraint(equalTo: dockBar.centerXAnchor),
            stack.centerYAnchor.constraint(equalTo: dockBar.centerYAnchor),
            stack.widthAnchor.constraint(lessThanOrEqualToConstant: 640),
            stack.leadingAnchor.constraint(greaterThanOrEqualTo: dockBar.leadingAnchor, constant: 12),
            stack.trailingAnchor.constraint(lessThanOrEqualTo: dockBar.trailingAnchor, constant: -12),
            stack.heightAnchor.constraint(equalToConstant: 42)
        ])

        let fillStack = stack.widthAnchor.constraint(equalTo: dockBar.widthAnchor, constant: -24)
        fillStack.priority = .defaultHigh
        fillStack.isActive = true

        // Bottom safe-area fill below dock
        let bottomFiller = UIView()
        bottomFiller.backgroundColor = AtrilColors.dock
        bottomFiller.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(bottomFiller)
        NSLayoutConstraint.activate([
            bottomFiller.topAnchor.constraint(equalTo: dockBar.bottomAnchor),
            bottomFiller.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            bottomFiller.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            bottomFiller.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])
    }

    private func configureDockButton(_ btn: UIButton, tag: Int) {
        btn.tag = tag
        btn.layer.cornerRadius = 11
        btn.titleLabel?.font = .monospacedDigitSystemFont(ofSize: 13.5, weight: .semibold)
        btn.addTarget(self, action: #selector(handleDockButtonTap(_:)), for: .touchUpInside)
    }

    private func wireCallbacks() {
        notesSplitVC.onRequestOpenClickTab = { [weak self] in
            self?.switchToTab(.click)
        }
        notesSplitVC.onLiveModeChanged = { [weak self] isLive in
            self?.clickVC.setLiveMode(isLive)
        }
        notesSplitVC.onWakeLockConditionChanged = { [weak self] in
            self?.updateWakeLock()
        }

        clickVC.onGoToNotes = { [weak self] in
            self?.switchToTab(.notes)
        }
        clickVC.onExitLiveAndStart = { [weak self] in
            self?.notesSplitVC.exitLiveModeFromClickPanel()
            MetronomeAudioEngine.shared.start()
        }
        clickVC.setLiveMode(notesSplitVC.isLiveMode)
    }

    private func switchToTab(_ next: WorkspaceTab) {
        let targetVC: UIViewController
        switch next {
        case .notes: targetVC = notesSplitVC
        case .click: targetVC = clickVC
        case .tuner: targetVC = tunerVC
        }

        if let current = currentController {
            if current === targetVC {
                syncDockUI()
                return
            }
            current.willMove(toParent: nil)
            current.view.removeFromSuperview()
            current.removeFromParent()
        }

        addChild(targetVC)
        targetVC.view.translatesAutoresizingMaskIntoConstraints = false
        contentContainer.addSubview(targetVC.view)
        NSLayoutConstraint.activate([
            targetVC.view.topAnchor.constraint(equalTo: contentContainer.topAnchor),
            targetVC.view.bottomAnchor.constraint(equalTo: contentContainer.bottomAnchor),
            targetVC.view.leadingAnchor.constraint(equalTo: contentContainer.leadingAnchor),
            targetVC.view.trailingAnchor.constraint(equalTo: contentContainer.trailingAnchor)
        ])
        targetVC.didMove(toParent: self)
        currentController = targetVC
        activeTab = next
        syncDockUI()
        updateWakeLock()
    }

    private func syncDockUI() {
        let engine = MetronomeAudioEngine.shared
        let iconCfg = UIImage.SymbolConfiguration(pointSize: 14, weight: .semibold)

        styleTabButton(
            notesTabBtn,
            title: " Notas",
            symbol: "book.fill",
            iconCfg: iconCfg,
            selected: activeTab == .notes,
            accented: false
        )

        let clickTitle = engine.isRunning ? " Click · \(engine.bpm)" : " Click"
        styleTabButton(
            clickTabBtn,
            title: clickTitle,
            symbol: "speedometer",
            iconCfg: iconCfg,
            selected: activeTab == .click,
            accented: engine.isRunning
        )

        styleTabButton(
            tunerTabBtn,
            title: " Afinador",
            symbol: "waveform",
            iconCfg: iconCfg,
            selected: activeTab == .tuner,
            accented: false
        )
    }

    private func styleTabButton(
        _ btn: UIButton,
        title: String,
        symbol: String,
        iconCfg: UIImage.SymbolConfiguration,
        selected: Bool,
        accented: Bool
    ) {
        btn.setImage(UIImage(systemName: symbol, withConfiguration: iconCfg), for: .normal)
        btn.setTitle(title, for: .normal)
        btn.backgroundColor = selected ? AtrilColors.activePill : .clear
        let color: UIColor = (selected || accented) ? AtrilColors.gold : UIColor(hex: 0x8E8E93)
        btn.tintColor = color
        btn.setTitleColor(color, for: .normal)
    }

    private func updateWakeLock() {
        let keepAwake =
            notesSplitVC.hasActiveNoteOrReader ||
            MetronomeAudioEngine.shared.isRunning ||
            activeTab != .notes
        UIApplication.shared.isIdleTimerDisabled = keepAwake
    }

    @objc private func handleDockButtonTap(_ sender: UIButton) {
        guard let tab = WorkspaceTab(rawValue: sender.tag) else { return }
        switchToTab(tab)
    }

    @objc private func handleKeyboardWillShow() {
        guard !dockHiddenByKeyboard else { return }
        dockHiddenByKeyboard = true
        dockHeightConstraint.constant = 0
        dockBar.isHidden = true
    }

    @objc private func handleKeyboardWillHide() {
        guard dockHiddenByKeyboard else { return }
        dockHiddenByKeyboard = false
        dockBar.isHidden = false
        dockHeightConstraint.constant = 56
    }

    // MARK: - MetronomeObserver

    func metronomeDidUpdateState(_ engine: MetronomeAudioEngine) {
        syncDockUI()
        updateWakeLock()
    }

    func metronomeDidTickBeat(_ engine: MetronomeAudioEngine, beatIndex: Int, beatTick: Int) {
        // Dock does not pulse on every beat tick
    }
}
