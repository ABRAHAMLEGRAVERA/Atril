import UIKit
import UniformTypeIdentifiers

final class BackupViewController: UIViewController, UIDocumentPickerDelegate {
    private var storageStatus: StorageStatus
    private var optimizeImagesFor16GB: Bool
    private var selectedBackupURL: URL?
    private var inspection: BackupInspectionResult?

    var onToggleOptimizeImages: ((Bool) -> Void)?
    var onDidRestoreBackup: (() -> Void)?

    private let bannerView = UIView()
    private let bannerLabel = UILabel()
    private let summaryTitleLabel = UILabel()
    private let summaryBytesLabel = UILabel()
    private let optimizeSwitch = UISwitch()
    private let exportButton = UIButton(type: .system)
    private let restoreButton = UIButton(type: .system)
    private let inspectionCard = UIView()
    private let inspectionLabel = UILabel()
    private let mergeButton = UIButton(type: .system)
    private let replaceButton = UIButton(type: .system)

    init(storageStatus: StorageStatus, optimizeImagesFor16GB: Bool) {
        self.storageStatus = storageStatus
        self.optimizeImagesFor16GB = optimizeImagesFor16GB
        super.init(nibName: nil, bundle: nil)
        modalPresentationStyle = .formSheet
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(hex: 0x1E1E22)
        setupUI()
        syncUI()
    }

    private func setupUI() {
        let header = UIView()
        header.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(header)

        let titleLbl = UILabel()
        titleLbl.text = "Espacio y copias de seguridad"
        titleLbl.font = .systemFont(ofSize: 17, weight: .semibold)
        titleLbl.textColor = AtrilColors.textPrimary
        titleLbl.translatesAutoresizingMaskIntoConstraints = false
        header.addSubview(titleLbl)

        let closeBtn = UIButton(type: .system)
        let xCfg = UIImage.SymbolConfiguration(pointSize: 15, weight: .semibold)
        closeBtn.setImage(UIImage(systemName: "xmark", withConfiguration: xCfg), for: .normal)
        closeBtn.tintColor = AtrilColors.textSecondary
        closeBtn.addTarget(self, action: #selector(handleClose), for: .touchUpInside)
        closeBtn.translatesAutoresizingMaskIntoConstraints = false
        header.addSubview(closeBtn)

        let sep = UIView()
        sep.backgroundColor = AtrilColors.borderSubtle
        sep.translatesAutoresizingMaskIntoConstraints = false
        header.addSubview(sep)

        let scroll = UIScrollView()
        scroll.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scroll)

        let contentStack = UIStackView()
        contentStack.axis = .vertical
        contentStack.spacing = 14
        contentStack.translatesAutoresizingMaskIntoConstraints = false
        scroll.addSubview(contentStack)

        NSLayoutConstraint.activate([
            header.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            header.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            header.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            header.heightAnchor.constraint(equalToConstant: 58),

            titleLbl.leadingAnchor.constraint(equalTo: header.leadingAnchor, constant: 20),
            titleLbl.centerYAnchor.constraint(equalTo: header.centerYAnchor),

            closeBtn.trailingAnchor.constraint(equalTo: header.trailingAnchor, constant: -14),
            closeBtn.centerYAnchor.constraint(equalTo: header.centerYAnchor),
            closeBtn.widthAnchor.constraint(equalToConstant: 40),
            closeBtn.heightAnchor.constraint(equalToConstant: 40),

            sep.leadingAnchor.constraint(equalTo: header.leadingAnchor),
            sep.trailingAnchor.constraint(equalTo: header.trailingAnchor),
            sep.bottomAnchor.constraint(equalTo: header.bottomAnchor),
            sep.heightAnchor.constraint(equalToConstant: 1),

            scroll.topAnchor.constraint(equalTo: header.bottomAnchor),
            scroll.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            scroll.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scroll.trailingAnchor.constraint(equalTo: view.trailingAnchor),

            contentStack.topAnchor.constraint(equalTo: scroll.contentLayoutGuide.topAnchor, constant: 20),
            contentStack.bottomAnchor.constraint(equalTo: scroll.contentLayoutGuide.bottomAnchor, constant: -24),
            contentStack.leadingAnchor.constraint(equalTo: scroll.frameLayoutGuide.leadingAnchor, constant: 20),
            contentStack.trailingAnchor.constraint(equalTo: scroll.frameLayoutGuide.trailingAnchor, constant: -20)
        ])

        // Status banner
        bannerView.layer.cornerRadius = 12
        bannerView.layer.borderWidth = 1
        bannerView.isHidden = true
        bannerLabel.font = .systemFont(ofSize: 13)
        bannerLabel.numberOfLines = 0
        bannerLabel.translatesAutoresizingMaskIntoConstraints = false
        bannerView.addSubview(bannerLabel)
        NSLayoutConstraint.activate([
            bannerLabel.topAnchor.constraint(equalTo: bannerView.topAnchor, constant: 12),
            bannerLabel.bottomAnchor.constraint(equalTo: bannerView.bottomAnchor, constant: -12),
            bannerLabel.leadingAnchor.constraint(equalTo: bannerView.leadingAnchor, constant: 14),
            bannerLabel.trailingAnchor.constraint(equalTo: bannerView.trailingAnchor, constant: -14)
        ])
        contentStack.addArrangedSubview(bannerView)

        // Storage Summary Card
        let summaryCard = makeCard()
        let icon = UIImageView(image: UIImage(systemName: "externaldrive.fill"))
        icon.tintColor = AtrilColors.gold
        icon.contentMode = .scaleAspectFit
        icon.translatesAutoresizingMaskIntoConstraints = false
        icon.widthAnchor.constraint(equalToConstant: 24).isActive = true

        summaryTitleLabel.font = .systemFont(ofSize: 14.5, weight: .semibold)
        summaryTitleLabel.textColor = AtrilColors.textPrimary
        summaryBytesLabel.font = .monospacedDigitSystemFont(ofSize: 12.5, weight: .regular)
        summaryBytesLabel.textColor = AtrilColors.textSecondary

        let textCol = UIStackView(arrangedSubviews: [summaryTitleLabel, summaryBytesLabel])
        textCol.axis = .vertical
        textCol.spacing = 3

        let sumRow = UIStackView(arrangedSubviews: [icon, textCol])
        sumRow.axis = .horizontal
        sumRow.alignment = .center
        sumRow.spacing = 12
        sumRow.translatesAutoresizingMaskIntoConstraints = false
        summaryCard.addSubview(sumRow)
        NSLayoutConstraint.activate([
            sumRow.topAnchor.constraint(equalTo: summaryCard.topAnchor, constant: 14),
            sumRow.bottomAnchor.constraint(equalTo: summaryCard.bottomAnchor, constant: -14),
            sumRow.leadingAnchor.constraint(equalTo: summaryCard.leadingAnchor, constant: 14),
            sumRow.trailingAnchor.constraint(equalTo: summaryCard.trailingAnchor, constant: -14)
        ])
        contentStack.addArrangedSubview(summaryCard)

        // 16 GB Image Optimization Toggle Card
        let optCard = makeCard()
        let optTitle = UILabel()
        optTitle.text = "Optimizar imágenes para 16 GB"
        optTitle.font = .systemFont(ofSize: 14.5, weight: .semibold)
        optTitle.textColor = AtrilColors.textPrimary

        let optDesc = UILabel()
        optDesc.text = "Ajusta fotos pesadas al tamaño de pantalla del iPad para ahorrar hasta un 80% de espacio y pasar de página sin trabarse."
        optDesc.font = .systemFont(ofSize: 12.5)
        optDesc.textColor = AtrilColors.textSecondary
        optDesc.numberOfLines = 0

        let optTextCol = UIStackView(arrangedSubviews: [optTitle, optDesc])
        optTextCol.axis = .vertical
        optTextCol.spacing = 4

        optimizeSwitch.onTintColor = AtrilColors.gold
        optimizeSwitch.addTarget(self, action: #selector(handleSwitchChanged), for: .valueChanged)

        let optRow = UIStackView(arrangedSubviews: [optTextCol, optimizeSwitch])
        optRow.axis = .horizontal
        optRow.alignment = .top
        optRow.spacing = 14
        optRow.translatesAutoresizingMaskIntoConstraints = false
        optCard.addSubview(optRow)
        NSLayoutConstraint.activate([
            optRow.topAnchor.constraint(equalTo: optCard.topAnchor, constant: 14),
            optRow.bottomAnchor.constraint(equalTo: optCard.bottomAnchor, constant: -14),
            optRow.leadingAnchor.constraint(equalTo: optCard.leadingAnchor, constant: 14),
            optRow.trailingAnchor.constraint(equalTo: optCard.trailingAnchor, constant: -14)
        ])
        contentStack.addArrangedSubview(optCard)

        // Export / Restore Buttons
        let dlCfg = UIImage.SymbolConfiguration(pointSize: 14, weight: .semibold)
        exportButton.setImage(UIImage(systemName: "square.and.arrow.up", withConfiguration: dlCfg), for: .normal)
        exportButton.setTitle(" Exportar copia (.ZIP)", for: .normal)
        exportButton.tintColor = AtrilColors.bgPrimary
        exportButton.setTitleColor(AtrilColors.bgPrimary, for: .normal)
        exportButton.titleLabel?.font = .systemFont(ofSize: 14, weight: .semibold)
        exportButton.backgroundColor = AtrilColors.gold
        exportButton.layer.cornerRadius = 12
        exportButton.heightAnchor.constraint(equalToConstant: 46).isActive = true
        exportButton.addTarget(self, action: #selector(handleExportTap), for: .touchUpInside)

        restoreButton.setImage(UIImage(systemName: "arrow.down.doc", withConfiguration: dlCfg), for: .normal)
        restoreButton.setTitle(" Restaurar copia", for: .normal)
        restoreButton.tintColor = AtrilColors.gold
        restoreButton.setTitleColor(AtrilColors.textPrimary, for: .normal)
        restoreButton.titleLabel?.font = .systemFont(ofSize: 14, weight: .medium)
        restoreButton.backgroundColor = UIColor(hex: 0x2C2C32)
        restoreButton.layer.cornerRadius = 12
        restoreButton.heightAnchor.constraint(equalToConstant: 46).isActive = true
        restoreButton.addTarget(self, action: #selector(handleRestorePickTap), for: .touchUpInside)

        let btnRow = UIStackView(arrangedSubviews: [exportButton, restoreButton])
        btnRow.axis = .horizontal
        btnRow.distribution = .fillEqually
        btnRow.spacing = 12
        contentStack.addArrangedSubview(btnRow)

        // Backup inspection card
        inspectionCard.backgroundColor = UIColor(hex: 0x26262C)
        inspectionCard.layer.cornerRadius = 12
        inspectionCard.layer.borderWidth = 1
        inspectionCard.layer.borderColor = AtrilColors.borderSubtle.cgColor
        inspectionCard.isHidden = true

        inspectionLabel.font = .systemFont(ofSize: 13)
        inspectionLabel.textColor = UIColor(hex: 0xD1D1D6)
        inspectionLabel.numberOfLines = 0

        mergeButton.setTitle("Combinar", for: .normal)
        mergeButton.setTitleColor(AtrilColors.textPrimary, for: .normal)
        mergeButton.titleLabel?.font = .systemFont(ofSize: 13, weight: .semibold)
        mergeButton.backgroundColor = UIColor(hex: 0x32323A)
        mergeButton.layer.cornerRadius = 10
        mergeButton.heightAnchor.constraint(equalToConstant: 40).isActive = true
        mergeButton.addTarget(self, action: #selector(handleMergeTap), for: .touchUpInside)

        replaceButton.setTitle("Reemplazar todo", for: .normal)
        replaceButton.setTitleColor(.white, for: .normal)
        replaceButton.titleLabel?.font = .systemFont(ofSize: 13, weight: .semibold)
        replaceButton.backgroundColor = AtrilColors.red
        replaceButton.layer.cornerRadius = 10
        replaceButton.heightAnchor.constraint(equalToConstant: 40).isActive = true
        replaceButton.addTarget(self, action: #selector(handleReplaceTap), for: .touchUpInside)

        let insBtns = UIStackView(arrangedSubviews: [mergeButton, replaceButton])
        insBtns.axis = .horizontal
        insBtns.distribution = .fillEqually
        insBtns.spacing = 10

        let insStack = UIStackView(arrangedSubviews: [inspectionLabel, insBtns])
        insStack.axis = .vertical
        insStack.spacing = 12
        insStack.translatesAutoresizingMaskIntoConstraints = false
        inspectionCard.addSubview(insStack)
        NSLayoutConstraint.activate([
            insStack.topAnchor.constraint(equalTo: inspectionCard.topAnchor, constant: 14),
            insStack.bottomAnchor.constraint(equalTo: inspectionCard.bottomAnchor, constant: -14),
            insStack.leadingAnchor.constraint(equalTo: inspectionCard.leadingAnchor, constant: 14),
            insStack.trailingAnchor.constraint(equalTo: inspectionCard.trailingAnchor, constant: -14)
        ])
        contentStack.addArrangedSubview(inspectionCard)
    }

    private func makeCard() -> UIView {
        let v = UIView()
        v.backgroundColor = AtrilColors.cardSecondary
        v.layer.cornerRadius = 12
        return v
    }

    private func syncUI() {
        let nWord = storageStatus.noteCount == 1 ? "nota" : "notas"
        let aWord = storageStatus.attachmentCount == 1 ? "archivo" : "archivos"
        summaryTitleLabel.text = "\(storageStatus.noteCount) \(nWord) · \(storageStatus.attachmentCount) \(aWord)"
        summaryBytesLabel.text = "Ocupado en el dispositivo: \(NoteLogic.formatBytes(storageStatus.attachmentsBytes))"
        optimizeSwitch.isOn = optimizeImagesFor16GB

        if let ins = inspection {
            inspectionCard.isHidden = false
            if ins.valid, let manifest = ins.manifest {
                inspectionLabel.textColor = UIColor(hex: 0xD1D1D6)
                inspectionLabel.text = "Respaldo válido: \(manifest.notes.count) notas · \(ins.fileCount) archivos (\(NoteLogic.formatBytes(ins.totalFilesBytes)))"
                mergeButton.isHidden = false
                replaceButton.isHidden = false
            } else {
                inspectionLabel.textColor = UIColor(hex: 0xFF6961)
                inspectionLabel.text = ins.errors.joined(separator: " ")
                mergeButton.isHidden = true
                replaceButton.isHidden = true
            }
        } else {
            inspectionCard.isHidden = true
        }
    }

    private func showBanner(_ text: String, isError: Bool) {
        bannerView.isHidden = false
        bannerLabel.text = text
        if isError {
            bannerView.backgroundColor = AtrilColors.red.withAlphaComponent(0.14)
            bannerView.layer.borderColor = AtrilColors.red.withAlphaComponent(0.35).cgColor
            bannerLabel.textColor = UIColor(hex: 0xFF6961)
        } else {
            bannerView.backgroundColor = AtrilColors.green.withAlphaComponent(0.14)
            bannerView.layer.borderColor = AtrilColors.green.withAlphaComponent(0.35).cgColor
            bannerLabel.textColor = AtrilColors.textPrimary
        }
    }

    // MARK: - Actions

    @objc private func handleClose() {
        dismiss(animated: true)
    }

    @objc private func handleSwitchChanged() {
        optimizeImagesFor16GB = optimizeSwitch.isOn
        onToggleOptimizeImages?(optimizeImagesFor16GB)
    }

    @objc private func handleExportTap() {
        do {
            let res = try AtrilRepository.shared.exportBackupZip()
            showBanner("Respaldo preparado: \(res.fileName) (\(NoteLogic.formatBytes(res.size))).", isError: false)
            let activity = UIActivityViewController(activityItems: [res.url], applicationActivities: nil)
            if let pop = activity.popoverPresentationController {
                pop.sourceView = exportButton
                pop.sourceRect = exportButton.bounds
            }
            present(activity, animated: true)
        } catch {
            showBanner(error.localizedDescription, isError: true)
        }
    }

    @objc private func handleRestorePickTap() {
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: [UTType.zip], asCopy: true)
        picker.delegate = self
        present(picker, animated: true)
    }

    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard let url = urls.first else { return }
        selectedBackupURL = url
        inspection = AtrilRepository.shared.inspectBackupZip(at: url)
        syncUI()
    }

    @objc private func handleMergeTap() {
        performRestore(replaceAll: false)
    }

    @objc private func handleReplaceTap() {
        let alert = UIAlertController(
            title: "¿Reemplazar todas tus notas?",
            message: "Se borrarán las notas actuales de este iPad y se restaurarán las del archivo ZIP.",
            preferredStyle: .alert
        )
        alert.addAction(UIAlertAction(title: "Cancelar", style: .cancel))
        alert.addAction(UIAlertAction(title: "Reemplazar", style: .destructive) { [weak self] _ in
            self?.performRestore(replaceAll: true)
        })
        present(alert, animated: true)
    }

    private func performRestore(replaceAll: Bool) {
        guard let url = selectedBackupURL else { return }
        do {
            let count = try AtrilRepository.shared.restoreBackupZip(at: url, replaceAll: replaceAll)
            selectedBackupURL = nil
            inspection = nil
            let updatedNotes = try AtrilRepository.shared.getAllNotes()
            storageStatus = AtrilRepository.shared.getStorageStatus(notes: updatedNotes)
            syncUI()
            showBanner("Se restauraron \(count) notas correctamente.", isError: false)
            onDidRestoreBackup?()
        } catch {
            showBanner(error.localizedDescription, isError: true)
        }
    }
}
