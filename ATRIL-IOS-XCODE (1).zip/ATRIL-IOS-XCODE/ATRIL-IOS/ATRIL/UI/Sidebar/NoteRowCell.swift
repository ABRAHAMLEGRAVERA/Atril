import UIKit

final class NoteRowCell: UITableViewCell {
    static let reuseId = "NoteRowCell"

    private let cardView = UIView()
    private let titleLabel = UILabel()
    private let pinImageView = UIImageView()
    private let subtitleLabel = UILabel()

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .clear
        contentView.backgroundColor = .clear
        selectionStyle = .none

        cardView.layer.cornerRadius = 12
        cardView.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(cardView)

        titleLabel.font = .systemFont(ofSize: 15, weight: .semibold)
        titleLabel.lineBreakMode = .byTruncatingTail
        titleLabel.translatesAutoresizingMaskIntoConstraints = false

        pinImageView.image = UIImage(systemName: "pin.fill")
        pinImageView.tintColor = AtrilColors.gold
        pinImageView.contentMode = .scaleAspectFit
        pinImageView.translatesAutoresizingMaskIntoConstraints = false
        pinImageView.setContentCompressionResistancePriority(.required, for: .horizontal)

        let topRow = UIStackView(arrangedSubviews: [titleLabel, pinImageView])
        topRow.axis = .horizontal
        topRow.alignment = .center
        topRow.spacing = 6
        topRow.translatesAutoresizingMaskIntoConstraints = false

        subtitleLabel.font = .systemFont(ofSize: 12.5, weight: .regular)
        subtitleLabel.textColor = AtrilColors.textSecondary
        subtitleLabel.lineBreakMode = .byTruncatingTail
        subtitleLabel.translatesAutoresizingMaskIntoConstraints = false

        let vStack = UIStackView(arrangedSubviews: [topRow, subtitleLabel])
        vStack.axis = .vertical
        vStack.spacing = 4
        vStack.translatesAutoresizingMaskIntoConstraints = false

        cardView.addSubview(vStack)

        NSLayoutConstraint.activate([
            cardView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 2),
            cardView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -2),
            cardView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 8),
            cardView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -8),

            pinImageView.widthAnchor.constraint(equalToConstant: 13),
            pinImageView.heightAnchor.constraint(equalToConstant: 13),

            vStack.topAnchor.constraint(equalTo: cardView.topAnchor, constant: 10),
            vStack.bottomAnchor.constraint(equalTo: cardView.bottomAnchor, constant: -10),
            vStack.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 12),
            vStack.trailingAnchor.constraint(equalTo: cardView.trailingAnchor, constant: -12)
        ])
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func configure(with note: Note, isSelected: Bool) {
        let displayTitle = note.title.trimmingCharacters(in: .whitespacesAndNewlines)
        titleLabel.text = displayTitle.isEmpty ? "Nota sin título" : displayTitle
        titleLabel.textColor = isSelected ? AtrilColors.gold : AtrilColors.textPrimary
        pinImageView.isHidden = !note.pinned
        cardView.backgroundColor = isSelected ? AtrilColors.activeNoteBg : AtrilColors.bgPrimary

        let datePart = NoteLogic.formatDateShort(note.updatedAt)
        let snippetPart = NoteLogic.getNoteSnippet(note)
        let attributed = NSMutableAttributedString(
            string: "\(datePart) · ",
            attributes: [.foregroundColor: AtrilColors.textMuted]
        )
        attributed.append(NSAttributedString(
            string: snippetPart,
            attributes: [.foregroundColor: AtrilColors.textSecondary]
        ))
        subtitleLabel.attributedText = attributed
    }
}
