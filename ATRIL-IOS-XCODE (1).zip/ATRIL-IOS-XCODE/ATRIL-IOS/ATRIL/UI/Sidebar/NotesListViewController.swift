import UIKit

protocol NotesListDelegate: AnyObject {
    func notesListDidSelectNote(_ id: String)
    func notesListDidCreateNote()
    func notesListDidTogglePin(_ note: Note)
    func notesListDidRequestDelete(_ note: Note)
    func notesListDidChangeSearch(_ query: String)
    func notesListDidChangeFilter(_ tab: NotesFilterTab)
    func notesListDidOpenBackup()
}

final class NotesListViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate {
    weak var delegate: NotesListDelegate?

    private var notes: [Note] = []
    private var selectedNoteId: String?

    private let logoView = AtrilLogoView()
    private let addButton = UIButton(type: .system)
    private let searchField = UITextField()
    private let filterControl = UISegmentedControl(items: ["Todas", "Fijadas"])
    private let tableView = UITableView(frame: .zero, style: .plain)
    private let emptyLabel = UILabel()
    private let emptyCreateBtn = UIButton(type: .system)
    private let emptyStack = UIStackView()
    private let storageButton = UIButton(type: .system)
    private let storageBytesLabel = UILabel()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = AtrilColors.bgPrimary
        setupUI()
    }

    private func setupUI() {
        // Right hairline border
        let rightBorder = UIView()
        rightBorder.backgroundColor = AtrilColors.borderSubtle
        rightBorder.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(rightBorder)

        // Header bar
        let headerBar = UIView()
        headerBar.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(headerBar)

        logoView.translatesAutoresizingMaskIntoConstraints = false
        headerBar.addSubview(logoView)

        let plusCfg = UIImage.SymbolConfiguration(pointSize: 18, weight: .semibold)
        addButton.setImage(UIImage(systemName: "square.and.pencil", withConfiguration: plusCfg), for: .normal)
        addButton.tintColor = AtrilColors.gold
        addButton.accessibilityLabel = "Nueva nota"
        addButton.addTarget(self, action: #selector(handleCreateTap), for: .touchUpInside)
        addButton.translatesAutoresizingMaskIntoConstraints = false
        headerBar.addSubview(addButton)

        let headerSep = UIView()
        headerSep.backgroundColor = AtrilColors.borderSubtle
        headerSep.translatesAutoresizingMaskIntoConstraints = false
        headerBar.addSubview(headerSep)

        // Search & Filter container
        let filterContainer = UIView()
        filterContainer.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(filterContainer)

        let searchIcon = UIImageView(image: UIImage(systemName: "magnifyingglass"))
        searchIcon.tintColor = AtrilColors.textMuted
        searchIcon.contentMode = .scaleAspectFit
        let iconWrap = UIView(frame: CGRect(x: 0, y: 0, width: 32, height: 20))
        searchIcon.frame = CGRect(x: 10, y: 2, width: 16, height: 16)
        iconWrap.addSubview(searchIcon)

        searchField.leftView = iconWrap
        searchField.leftViewMode = .always
        searchField.clearButtonMode = .whileEditing
        searchField.backgroundColor = UIColor(hex: 0x222226)
        searchField.layer.cornerRadius = 11
        searchField.layer.borderWidth = 1
        searchField.layer.borderColor = AtrilColors.borderSubtle.cgColor
        searchField.textColor = AtrilColors.textPrimary
        searchField.tintColor = AtrilColors.gold
        searchField.font = .systemFont(ofSize: 15)
        searchField.attributedPlaceholder = NSAttributedString(
            string: "Buscar notas...",
            attributes: [.foregroundColor: AtrilColors.textMuted]
        )
        searchField.returnKeyType = .search
        searchField.delegate = self
        searchField.addTarget(self, action: #selector(handleSearchChanged), for: .editingChanged)
        searchField.translatesAutoresizingMaskIntoConstraints = false
        filterContainer.addSubview(searchField)

        filterControl.selectedSegmentIndex = 0
        filterControl.backgroundColor = UIColor(hex: 0x202024)
        filterControl.selectedSegmentTintColor = UIColor(hex: 0x2E2E34)
        filterControl.setTitleTextAttributes([
            .foregroundColor: AtrilColors.textSecondary,
            .font: UIFont.systemFont(ofSize: 12.5, weight: .medium)
        ], for: .normal)
        filterControl.setTitleTextAttributes([
            .foregroundColor: AtrilColors.textPrimary,
            .font: UIFont.systemFont(ofSize: 12.5, weight: .semibold)
        ], for: .selected)
        filterControl.addTarget(self, action: #selector(handleFilterChanged), for: .valueChanged)
        filterControl.translatesAutoresizingMaskIntoConstraints = false
        filterContainer.addSubview(filterControl)

        let filterSep = UIView()
        filterSep.backgroundColor = UIColor(white: 1.0, alpha: 0.05)
        filterSep.translatesAutoresizingMaskIntoConstraints = false
        filterContainer.addSubview(filterSep)

        // Notes TableView
        tableView.backgroundColor = .clear
        tableView.separatorStyle = .none
        tableView.rowHeight = 68
        tableView.dataSource = self
        tableView.delegate = self
        tableView.keyboardDismissMode = .onDrag
        tableView.contentInset = UIEdgeInsets(top: 6, left: 0, bottom: 8, right: 0)
        tableView.register(NoteRowCell.self, forCellReuseIdentifier: NoteRowCell.reuseId)
        tableView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(tableView)

        // Empty state
        emptyLabel.text = "No hay notas todavía"
        emptyLabel.font = .systemFont(ofSize: 14)
        emptyLabel.textColor = AtrilColors.textSecondary
        emptyLabel.textAlignment = .center

        emptyCreateBtn.setTitle("Crear primera nota", for: .normal)
        emptyCreateBtn.setTitleColor(AtrilColors.gold, for: .normal)
        emptyCreateBtn.titleLabel?.font = .systemFont(ofSize: 13, weight: .semibold)
        emptyCreateBtn.backgroundColor = UIColor(hex: 0x26262B)
        emptyCreateBtn.layer.cornerRadius = 11
        emptyCreateBtn.contentEdgeInsets = UIEdgeInsets(top: 10, left: 16, bottom: 10, right: 16)
        emptyCreateBtn.addTarget(self, action: #selector(handleCreateTap), for: .touchUpInside)

        emptyStack.axis = .vertical
        emptyStack.alignment = .center
        emptyStack.spacing = 12
        emptyStack.addArrangedSubview(emptyLabel)
        emptyStack.addArrangedSubview(emptyCreateBtn)
        emptyStack.isHidden = true
        emptyStack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(emptyStack)

        // Footer bar: Storage & Backup
        let footerBar = UIView()
        footerBar.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(footerBar)

        let footerSep = UIView()
        footerSep.backgroundColor = AtrilColors.borderSubtle
        footerSep.translatesAutoresizingMaskIntoConstraints = false
        footerBar.addSubview(footerSep)

        storageButton.backgroundColor = .clear
        storageButton.layer.cornerRadius = 11
        storageButton.addTarget(self, action: #selector(handleBackupTap), for: .touchUpInside)
        storageButton.translatesAutoresizingMaskIntoConstraints = false
        footerBar.addSubview(storageButton)

        let driveIcon = UIImageView(image: UIImage(systemName: "externaldrive.fill"))
        driveIcon.tintColor = AtrilColors.gold
        driveIcon.contentMode = .scaleAspectFit
        driveIcon.isUserInteractionEnabled = false
        driveIcon.translatesAutoresizingMaskIntoConstraints = false

        let storageTitle = UILabel()
        storageTitle.text = "Espacio y copia"
        storageTitle.font = .systemFont(ofSize: 12.5, weight: .medium)
        storageTitle.textColor = AtrilColors.textSecondary
        storageTitle.isUserInteractionEnabled = false

        storageBytesLabel.text = "0 KB"
        storageBytesLabel.font = .monospacedDigitSystemFont(ofSize: 12.5, weight: .regular)
        storageBytesLabel.textColor = AtrilColors.textMuted
        storageBytesLabel.isUserInteractionEnabled = false

        let leftStack = UIStackView(arrangedSubviews: [driveIcon, storageTitle])
        leftStack.axis = .horizontal
        leftStack.alignment = .center
        leftStack.spacing = 8
        leftStack.isUserInteractionEnabled = false
        leftStack.translatesAutoresizingMaskIntoConstraints = false

        storageBytesLabel.translatesAutoresizingMaskIntoConstraints = false
        storageButton.addSubview(leftStack)
        storageButton.addSubview(storageBytesLabel)

        let guide = view.safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            rightBorder.topAnchor.constraint(equalTo: view.topAnchor),
            rightBorder.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            rightBorder.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            rightBorder.widthAnchor.constraint(equalToConstant: 1),

            headerBar.topAnchor.constraint(equalTo: guide.topAnchor),
            headerBar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            headerBar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            headerBar.heightAnchor.constraint(equalToConstant: 56),

            logoView.leadingAnchor.constraint(equalTo: headerBar.leadingAnchor, constant: 16),
            logoView.centerYAnchor.constraint(equalTo: headerBar.centerYAnchor),

            addButton.trailingAnchor.constraint(equalTo: headerBar.trailingAnchor, constant: -10),
            addButton.centerYAnchor.constraint(equalTo: headerBar.centerYAnchor),
            addButton.widthAnchor.constraint(equalToConstant: 44),
            addButton.heightAnchor.constraint(equalToConstant: 44),

            headerSep.leadingAnchor.constraint(equalTo: headerBar.leadingAnchor),
            headerSep.trailingAnchor.constraint(equalTo: headerBar.trailingAnchor),
            headerSep.bottomAnchor.constraint(equalTo: headerBar.bottomAnchor),
            headerSep.heightAnchor.constraint(equalToConstant: 1),

            filterContainer.topAnchor.constraint(equalTo: headerBar.bottomAnchor),
            filterContainer.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            filterContainer.trailingAnchor.constraint(equalTo: view.trailingAnchor),

            searchField.topAnchor.constraint(equalTo: filterContainer.topAnchor, constant: 12),
            searchField.leadingAnchor.constraint(equalTo: filterContainer.leadingAnchor, constant: 12),
            searchField.trailingAnchor.constraint(equalTo: filterContainer.trailingAnchor, constant: -12),
            searchField.heightAnchor.constraint(equalToConstant: 40),

            filterControl.topAnchor.constraint(equalTo: searchField.bottomAnchor, constant: 10),
            filterControl.leadingAnchor.constraint(equalTo: filterContainer.leadingAnchor, constant: 12),
            filterControl.trailingAnchor.constraint(equalTo: filterContainer.trailingAnchor, constant: -12),
            filterControl.heightAnchor.constraint(equalToConstant: 34),
            filterControl.bottomAnchor.constraint(equalTo: filterContainer.bottomAnchor, constant: -12),

            filterSep.leadingAnchor.constraint(equalTo: filterContainer.leadingAnchor),
            filterSep.trailingAnchor.constraint(equalTo: filterContainer.trailingAnchor),
            filterSep.bottomAnchor.constraint(equalTo: filterContainer.bottomAnchor),
            filterSep.heightAnchor.constraint(equalToConstant: 1),

            tableView.topAnchor.constraint(equalTo: filterContainer.bottomAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: footerBar.topAnchor),

            emptyStack.centerXAnchor.constraint(equalTo: tableView.centerXAnchor),
            emptyStack.centerYAnchor.constraint(equalTo: tableView.centerYAnchor),
            emptyStack.leadingAnchor.constraint(greaterThanOrEqualTo: view.leadingAnchor, constant: 24),
            emptyStack.trailingAnchor.constraint(lessThanOrEqualTo: view.trailingAnchor, constant: -24),

            footerBar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            footerBar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            footerBar.bottomAnchor.constraint(equalTo: guide.bottomAnchor),
            footerBar.heightAnchor.constraint(equalToConstant: 56),

            footerSep.topAnchor.constraint(equalTo: footerBar.topAnchor),
            footerSep.leadingAnchor.constraint(equalTo: footerBar.leadingAnchor),
            footerSep.trailingAnchor.constraint(equalTo: footerBar.trailingAnchor),
            footerSep.heightAnchor.constraint(equalToConstant: 1),

            storageButton.leadingAnchor.constraint(equalTo: footerBar.leadingAnchor, constant: 10),
            storageButton.trailingAnchor.constraint(equalTo: footerBar.trailingAnchor, constant: -10),
            storageButton.centerYAnchor.constraint(equalTo: footerBar.centerYAnchor),
            storageButton.heightAnchor.constraint(equalToConstant: 42),

            driveIcon.widthAnchor.constraint(equalToConstant: 15),
            driveIcon.heightAnchor.constraint(equalToConstant: 15),

            leftStack.leadingAnchor.constraint(equalTo: storageButton.leadingAnchor, constant: 10),
            leftStack.centerYAnchor.constraint(equalTo: storageButton.centerYAnchor),

            storageBytesLabel.trailingAnchor.constraint(equalTo: storageButton.trailingAnchor, constant: -10),
            storageBytesLabel.centerYAnchor.constraint(equalTo: storageButton.centerYAnchor)
        ])
    }

    func update(notes: [Note], selectedNoteId: String?, storageStatus: StorageStatus, searchQuery: String) {
        self.notes = notes
        self.selectedNoteId = selectedNoteId
        if searchField.text != searchQuery {
            searchField.text = searchQuery
        }

        storageBytesLabel.text = NoteLogic.formatBytes(storageStatus.attachmentsBytes)
        storageBytesLabel.textColor = storageStatus.isNearLimit ? AtrilColors.amber : AtrilColors.textMuted
        storageBytesLabel.font = .monospacedDigitSystemFont(ofSize: 12.5, weight: storageStatus.isNearLimit ? .semibold : .regular)

        let isEmpty = notes.isEmpty
        emptyStack.isHidden = !isEmpty
        emptyLabel.text = searchQuery.isEmpty ? "No hay notas todavía" : "Sin resultados"
        emptyCreateBtn.isHidden = !searchQuery.isEmpty

        tableView.reloadData()
    }

    @objc private func handleCreateTap() {
        delegate?.notesListDidCreateNote()
    }

    @objc private func handleSearchChanged() {
        delegate?.notesListDidChangeSearch(searchField.text ?? "")
    }

    @objc private func handleFilterChanged() {
        let tab: NotesFilterTab = filterControl.selectedSegmentIndex == 1 ? .pinned : .all
        delegate?.notesListDidChangeFilter(tab)
    }

    @objc private func handleBackupTap() {
        delegate?.notesListDidOpenBackup()
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }

    // MARK: - UITableViewDataSource / Delegate

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return notes.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: NoteRowCell.reuseId, for: indexPath) as? NoteRowCell else {
            return UITableViewCell()
        }
        let note = notes[indexPath.row]
        cell.configure(with: note, isSelected: note.id == selectedNoteId)
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let note = notes[indexPath.row]
        delegate?.notesListDidSelectNote(note.id)
    }

    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let note = notes[indexPath.row]

        let deleteAction = UIContextualAction(style: .destructive, title: "Eliminar") { [weak self] _, _, done in
            self?.delegate?.notesListDidRequestDelete(note)
            done(true)
        }
        deleteAction.backgroundColor = AtrilColors.red
        deleteAction.image = UIImage(systemName: "trash.fill")

        let pinTitle = note.pinned ? "Desfijar" : "Fijar"
        let pinAction = UIContextualAction(style: .normal, title: pinTitle) { [weak self] _, _, done in
            self?.delegate?.notesListDidTogglePin(note)
            done(true)
        }
        pinAction.backgroundColor = AtrilColors.gold
        pinAction.image = UIImage(systemName: note.pinned ? "pin.slash.fill" : "pin.fill")

        let config = UISwipeActionsConfiguration(actions: [deleteAction, pinAction])
        config.performsFirstActionWithFullSwipe = false
        return config
    }
}
