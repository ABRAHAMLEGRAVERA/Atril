import PhotosUI
import UIKit
import UniformTypeIdentifiers

protocol NoteEditorDelegate: AnyObject {
    func noteEditorDidTapCompactBack()
    func noteEditorDidTapToggleSidebar()
    func noteEditorDidToggleLiveMode()
    func noteEditorDidTapOpenClickPanel()
    func noteEditorDidUpdateNote(_ noteId: String, title: String?, body: String?, blocks: [NoteBlock]?)
    func noteEditorDidImportItems(_ noteId: String, items: [(fileName: String, mimeType: String?, data: Data)], insertContext: (blockId: String?, cursorPos: Int?))
    func noteEditorDidRemoveAttachment(_ noteId: String, attachmentId: String)
    func noteEditorDidOpenReader(_ noteId: String, attachmentId: String, pageNumber: Int)
}

final class NoteEditorViewController: UIViewController,
    UITextFieldDelegate,
    UIDocumentPickerDelegate,
    PHPickerViewControllerDelegate,
    UIDropInteractionDelegate,
    MetronomeObserver {

    weak var delegate: NoteEditorDelegate?

    private var note: Note?
    private var liveMode: Bool = false
    private var sidebarVisible: Bool = true
    private var isCompactLayout: Bool = false
    private var studyBarOpen: Bool = false
    private var importingFiles: Bool = false

    private var cursorContext: (blockId: String?, cursorPos: Int?) = (nil, nil)
    private var renderedBlocksSignature: String = ""

    // Toolbar
    private let toolbar = UIView()
    private let backButton = UIButton(type: .system)
    private let sidebarToggleButton = UIButton(type: .system)
    private let liveModeButton = UIButton(type: .system)
    private let studyToggleButton = UIButton(type: .system)
    private let studyToggleBpmLabel = UILabel()
    private let addFileButton = UIButton(type: .system)

    // Study Click Strip
    private let studyStrip = UIView()
    private var studyStripHeightZero: NSLayoutConstraint!
    private let studyPlayBtn = UIButton(type: .system)
    private let studyBpmNumberLabel = UILabel()
    private let studyBpmSuffixLabel = UILabel()
    private let studySlider = UISlider()
    private let studyMinus1Btn = UIButton(type: .system)
    private let studyPlus1Btn = UIButton(type: .system)
    private let studyDotsView = VisualBeatDotsView(size: .md)
    private let studyAdjustBtn = UIButton(type: .system)

    // Document Canvas
    private let scrollView = UIScrollView()
    private let contentContainer = UIView()
    private let metaLabel = UILabel()
    private let titleField = UITextField()
    private let blocksStack = UIStackView()

    // Empty State
    private let emptyLabel = UILabel()
    private let emptyCreateBtn = UIButton(type: .system)
    private let emptyView = UIStackView()
    var onEmptyCreateNote: (() -> Void)?

    // Keyboard bottom inset tracking
    private var scrollBottomConstraint: NSLayoutConstraint!

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = AtrilColors.editorSurface
        setupToolbar()
        setupStudyStrip()
        setupScrollCanvas()
        setupEmptyState()

        view.addInteraction(UIDropInteraction(delegate: self))
        MetronomeAudioEngine.shared.addObserver(self)

        NotificationCenter.default.addObserver(
            self,
            selector: #selector(handleKeyboardFrame(_:)),
            name: UIResponder.keyboardWillChangeFrameNotification,
            object: nil
        )
        syncMetronomeUI()
    }

    deinit {
        MetronomeAudioEngine.shared.removeObserver(self)
        NotificationCenter.default.removeObserver(self)
    }

    // MARK: - UI Setup

    private func setupToolbar() {
        toolbar.backgroundColor = AtrilColors.editorSurface
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(toolbar)

        let bottomBorder = UIView()
        bottomBorder.backgroundColor = AtrilColors.borderSubtle
        bottomBorder.translatesAutoresizingMaskIntoConstraints = false
        toolbar.addSubview(bottomBorder)

        // Left navigation buttons
        let backCfg = UIImage.SymbolConfiguration(pointSize: 15, weight: .semibold)
        backButton.setImage(UIImage(systemName: "chevron.left", withConfiguration: backCfg), for: .normal)
        backButton.setTitle(" Notas", for: .normal)
        backButton.tintColor = AtrilColors.gold
        backButton.titleLabel?.font = .systemFont(ofSize: 15, weight: .semibold)
        backButton.addTarget(self, action: #selector(handleBackTap), for: .touchUpInside)
        backButton.translatesAutoresizingMaskIntoConstraints = false
        toolbar.addSubview(backButton)

        let sbCfg = UIImage.SymbolConfiguration(pointSize: 16, weight: .medium)
        sidebarToggleButton.setImage(UIImage(systemName: "sidebar.left", withConfiguration: sbCfg), for: .normal)
        sidebarToggleButton.tintColor = AtrilColors.textSecondary
        sidebarToggleButton.accessibilityLabel = "Mostrar u ocultar lista de notas"
        sidebarToggleButton.addTarget(self, action: #selector(handleToggleSidebarTap), for: .touchUpInside)
        sidebarToggleButton.translatesAutoresizingMaskIntoConstraints = false
        toolbar.addSubview(sidebarToggleButton)

        // Right controls
        let rightStack = UIStackView()
        rightStack.axis = .horizontal
        rightStack.alignment = .center
        rightStack.spacing = 8
        rightStack.translatesAutoresizingMaskIntoConstraints = false
        toolbar.addSubview(rightStack)

        // En vivo pill
        let liveCfg = UIImage.SymbolConfiguration(pointSize: 13, weight: .semibold)
        liveModeButton.setImage(UIImage(systemName: "antenna.radiowaves.left.and.right", withConfiguration: liveCfg), for: .normal)
        liveModeButton.setTitle(" En vivo", for: .normal)
        liveModeButton.titleLabel?.font = .systemFont(ofSize: 12.5, weight: .semibold)
        liveModeButton.layer.cornerRadius = 11
        liveModeButton.layer.borderWidth = 1
        liveModeButton.contentEdgeInsets = UIEdgeInsets(top: 8, left: 11, bottom: 8, right: 11)
        liveModeButton.addTarget(self, action: #selector(handleToggleLiveTap), for: .touchUpInside)
        rightStack.addArrangedSubview(liveModeButton)

        // Study BPM button
        studyToggleButton.layer.cornerRadius = 11
        studyToggleButton.layer.borderWidth = 1
        studyToggleButton.addTarget(self, action: #selector(handleStudyToggleTap), for: .touchUpInside)
        studyToggleButton.translatesAutoresizingMaskIntoConstraints = false
        let gaugeIcon = UIImageView(image: UIImage(systemName: "speedometer", withConfiguration: liveCfg))
        gaugeIcon.tintColor = AtrilColors.textBody
        gaugeIcon.isUserInteractionEnabled = false
        studyToggleBpmLabel.font = .monospacedDigitSystemFont(ofSize: 12.5, weight: .semibold)
        studyToggleBpmLabel.textAlignment = .right
        studyToggleBpmLabel.isUserInteractionEnabled = false
        studyToggleBpmLabel.widthAnchor.constraint(greaterThanOrEqualToConstant: 26).isActive = true

        let stStack = UIStackView(arrangedSubviews: [gaugeIcon, studyToggleBpmLabel])
        stStack.axis = .horizontal
        stStack.alignment = .center
        stStack.spacing = 5
        stStack.isUserInteractionEnabled = false
        stStack.translatesAutoresizingMaskIntoConstraints = false
        studyToggleButton.addSubview(stStack)
        NSLayoutConstraint.activate([
            studyToggleButton.heightAnchor.constraint(equalToConstant: 38),
            stStack.leadingAnchor.constraint(equalTo: studyToggleButton.leadingAnchor, constant: 10),
            stStack.trailingAnchor.constraint(equalTo: studyToggleButton.trailingAnchor, constant: -10),
            stStack.centerYAnchor.constraint(equalTo: studyToggleButton.centerYAnchor)
        ])
        rightStack.addArrangedSubview(studyToggleButton)

        // Add File button
        let clipCfg = UIImage.SymbolConfiguration(pointSize: 13.5, weight: .semibold)
        addFileButton.setImage(UIImage(systemName: "paperclip", withConfiguration: clipCfg), for: .normal)
        addFileButton.setTitle(" Añadir archivo", for: .normal)
        addFileButton.tintColor = AtrilColors.gold
        addFileButton.setTitleColor(AtrilColors.textPrimary, for: .normal)
        addFileButton.titleLabel?.font = .systemFont(ofSize: 12.5, weight: .semibold)
        addFileButton.backgroundColor = UIColor(hex: 0x27272C)
        addFileButton.layer.cornerRadius = 11
        addFileButton.contentEdgeInsets = UIEdgeInsets(top: 8, left: 12, bottom: 8, right: 12)
        addFileButton.addTarget(self, action: #selector(handleAddFileTap), for: .touchUpInside)
        rightStack.addArrangedSubview(addFileButton)

        let guide = view.safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            toolbar.topAnchor.constraint(equalTo: guide.topAnchor),
            toolbar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            toolbar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            toolbar.heightAnchor.constraint(equalToConstant: 56),

            bottomBorder.leadingAnchor.constraint(equalTo: toolbar.leadingAnchor),
            bottomBorder.trailingAnchor.constraint(equalTo: toolbar.trailingAnchor),
            bottomBorder.bottomAnchor.constraint(equalTo: toolbar.bottomAnchor),
            bottomBorder.heightAnchor.constraint(equalToConstant: 1),

            backButton.leadingAnchor.constraint(equalTo: toolbar.leadingAnchor, constant: 10),
            backButton.centerYAnchor.constraint(equalTo: toolbar.centerYAnchor),
            backButton.heightAnchor.constraint(equalToConstant: 44),

            sidebarToggleButton.leadingAnchor.constraint(equalTo: toolbar.leadingAnchor, constant: 10),
            sidebarToggleButton.centerYAnchor.constraint(equalTo: toolbar.centerYAnchor),
            sidebarToggleButton.widthAnchor.constraint(equalToConstant: 44),
            sidebarToggleButton.heightAnchor.constraint(equalToConstant: 44),

            rightStack.trailingAnchor.constraint(equalTo: toolbar.trailingAnchor, constant: -14),
            rightStack.centerYAnchor.constraint(equalTo: toolbar.centerYAnchor)
        ])
    }

    private func setupStudyStrip() {
        studyStrip.backgroundColor = AtrilColors.studyStrip
        studyStrip.clipsToBounds = true
        studyStrip.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(studyStrip)

        let sep = UIView()
        sep.backgroundColor = AtrilColors.borderSubtle
        sep.translatesAutoresizingMaskIntoConstraints = false
        studyStrip.addSubview(sep)

        // Row 1: Iniciar + fixed-width 3ch BPM · sig + UISlider on right
        studyPlayBtn.layer.cornerRadius = 9
        studyPlayBtn.titleLabel?.font = .systemFont(ofSize: 12.5, weight: .semibold)
        studyPlayBtn.contentEdgeInsets = UIEdgeInsets(top: 7, left: 12, bottom: 7, right: 12)
        studyPlayBtn.addTarget(self, action: #selector(handleStudyPlayTap), for: .touchUpInside)
        studyPlayBtn.translatesAutoresizingMaskIntoConstraints = false
        studyPlayBtn.heightAnchor.constraint(equalToConstant: 36).isActive = true

        studyBpmNumberLabel.font = .monospacedDigitSystemFont(ofSize: 13.5, weight: .semibold)
        studyBpmNumberLabel.textColor = AtrilColors.textPrimary
        studyBpmNumberLabel.textAlignment = .right
        studyBpmNumberLabel.translatesAutoresizingMaskIntoConstraints = false
        studyBpmNumberLabel.widthAnchor.constraint(equalToConstant: 30).isActive = true

        studyBpmSuffixLabel.font = .monospacedDigitSystemFont(ofSize: 12.5, weight: .medium)
        studyBpmSuffixLabel.textColor = AtrilColors.textSecondary
        studyBpmSuffixLabel.translatesAutoresizingMaskIntoConstraints = false

        let bpmGroup = UIStackView(arrangedSubviews: [studyBpmNumberLabel, studyBpmSuffixLabel])
        bpmGroup.axis = .horizontal
        bpmGroup.alignment = .center
        bpmGroup.spacing = 4

        let leftRow1 = UIStackView(arrangedSubviews: [studyPlayBtn, bpmGroup])
        leftRow1.axis = .horizontal
        leftRow1.alignment = .center
        leftRow1.spacing = 10

        studySlider.minimumValue = Float(MusicStudioMath.bpmMin)
        studySlider.maximumValue = Float(MusicStudioMath.bpmMax)
        studySlider.minimumTrackTintColor = AtrilColors.gold
        studySlider.maximumTrackTintColor = UIColor(hex: 0x2C2C34)
        studySlider.thumbTintColor = AtrilColors.gold
        studySlider.addTarget(self, action: #selector(handleStudySliderChanged), for: .valueChanged)
        studySlider.translatesAutoresizingMaskIntoConstraints = false
        studySlider.widthAnchor.constraint(greaterThanOrEqualToConstant: 120).isActive = true
        studySlider.widthAnchor.constraint(lessThanOrEqualToConstant: 280).isActive = true

        let row1 = UIStackView(arrangedSubviews: [leftRow1, UIView(), studySlider])
        row1.axis = .horizontal
        row1.alignment = .center
        row1.spacing = 12
        row1.translatesAutoresizingMaskIntoConstraints = false

        // Row 2: -1 / +1 buttons below Iniciar + VisualBeatDotsView + Ajustar
        configureStepButton(studyMinus1Btn, title: "−1", action: #selector(handleMinus1Tap))
        configureStepButton(studyPlus1Btn, title: "+1", action: #selector(handlePlus1Tap))

        let stepStack = UIStackView(arrangedSubviews: [studyMinus1Btn, studyPlus1Btn])
        stepStack.axis = .horizontal
        stepStack.spacing = 6

        studyAdjustBtn.setTitle("Ajustar", for: .normal)
        studyAdjustBtn.setTitleColor(AtrilColors.gold, for: .normal)
        studyAdjustBtn.titleLabel?.font = .systemFont(ofSize: 12.5, weight: .semibold)
        studyAdjustBtn.contentEdgeInsets = UIEdgeInsets(top: 6, left: 10, bottom: 6, right: 10)
        studyAdjustBtn.addTarget(self, action: #selector(handleOpenClickTap), for: .touchUpInside)

        let row2 = UIStackView(arrangedSubviews: [stepStack, UIView(), studyDotsView, UIView(), studyAdjustBtn])
        row2.axis = .horizontal
        row2.alignment = .center
        row2.spacing = 8
        row2.translatesAutoresizingMaskIntoConstraints = false

        let stripStack = UIStackView(arrangedSubviews: [row1, row2])
        stripStack.axis = .vertical
        stripStack.spacing = 8
        stripStack.translatesAutoresizingMaskIntoConstraints = false
        studyStrip.addSubview(stripStack)

        studyStripHeightZero = studyStrip.heightAnchor.constraint(equalToConstant: 0)
        studyStripHeightZero.priority = .required

        NSLayoutConstraint.activate([
            studyStrip.topAnchor.constraint(equalTo: toolbar.bottomAnchor),
            studyStrip.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            studyStrip.trailingAnchor.constraint(equalTo: view.trailingAnchor),

            sep.leadingAnchor.constraint(equalTo: studyStrip.leadingAnchor),
            sep.trailingAnchor.constraint(equalTo: studyStrip.trailingAnchor),
            sep.bottomAnchor.constraint(equalTo: studyStrip.bottomAnchor),
            sep.heightAnchor.constraint(equalToConstant: 1),

            stripStack.topAnchor.constraint(equalTo: studyStrip.topAnchor, constant: 10),
            stripStack.bottomAnchor.constraint(equalTo: studyStrip.bottomAnchor, constant: -10),
            stripStack.leadingAnchor.constraint(equalTo: studyStrip.leadingAnchor, constant: 16),
            stripStack.trailingAnchor.constraint(equalTo: studyStrip.trailingAnchor, constant: -16)
        ])
    }

    private func configureStepButton(_ btn: UIButton, title: String, action: Selector) {
        btn.setTitle(title, for: .normal)
        btn.setTitleColor(AtrilColors.textPrimary, for: .normal)
        btn.titleLabel?.font = .monospacedDigitSystemFont(ofSize: 12.5, weight: .semibold)
        btn.backgroundColor = UIColor(hex: 0x232329)
        btn.layer.cornerRadius = 8
        btn.layer.borderWidth = 1
        btn.layer.borderColor = AtrilColors.borderSubtle.cgColor
        btn.addTarget(self, action: action, for: .touchUpInside)
        btn.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            btn.widthAnchor.constraint(equalToConstant: 44),
            btn.heightAnchor.constraint(equalToConstant: 34)
        ])
    }

    private func setupScrollCanvas() {
        scrollView.backgroundColor = AtrilColors.editorSurface
        scrollView.keyboardDismissMode = .interactive
        scrollView.alwaysBounceVertical = true
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scrollView)

        contentContainer.translatesAutoresizingMaskIntoConstraints = false
        scrollView.addSubview(contentContainer)

        metaLabel.font = .monospacedDigitSystemFont(ofSize: 12, weight: .regular)
        metaLabel.textColor = AtrilColors.textMuted
        metaLabel.textAlignment = .center
        metaLabel.translatesAutoresizingMaskIntoConstraints = false

        titleField.font = .systemFont(ofSize: 27, weight: .bold)
        titleField.textColor = AtrilColors.textPrimary
        titleField.tintColor = AtrilColors.gold
        titleField.attributedPlaceholder = NSAttributedString(
            string: "Título",
            attributes: [.foregroundColor: AtrilColors.placeholder]
        )
        titleField.delegate = self
        titleField.addTarget(self, action: #selector(handleTitleChanged), for: .editingChanged)
        titleField.translatesAutoresizingMaskIntoConstraints = false

        blocksStack.axis = .vertical
        blocksStack.spacing = 14
        blocksStack.translatesAutoresizingMaskIntoConstraints = false

        let docStack = UIStackView(arrangedSubviews: [metaLabel, titleField, blocksStack])
        docStack.axis = .vertical
        docStack.spacing = 14
        docStack.translatesAutoresizingMaskIntoConstraints = false
        contentContainer.addSubview(docStack)

        scrollBottomConstraint = scrollView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        let widthCap = contentContainer.widthAnchor.constraint(lessThanOrEqualToConstant: 740)
        widthCap.priority = .required
        let fullWidth = contentContainer.widthAnchor.constraint(equalTo: scrollView.frameLayoutGuide.widthAnchor)
        fullWidth.priority = .defaultHigh

        NSLayoutConstraint.activate([
            scrollView.topAnchor.constraint(equalTo: studyStrip.bottomAnchor),
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            scrollBottomConstraint,

            contentContainer.topAnchor.constraint(equalTo: scrollView.contentLayoutGuide.topAnchor),
            contentContainer.bottomAnchor.constraint(equalTo: scrollView.contentLayoutGuide.bottomAnchor),
            contentContainer.centerXAnchor.constraint(equalTo: scrollView.frameLayoutGuide.centerXAnchor),
            widthCap,
            fullWidth,

            docStack.topAnchor.constraint(equalTo: contentContainer.topAnchor, constant: 22),
            docStack.bottomAnchor.constraint(equalTo: contentContainer.bottomAnchor, constant: -60),
            docStack.leadingAnchor.constraint(equalTo: contentContainer.leadingAnchor, constant: 24),
            docStack.trailingAnchor.constraint(equalTo: contentContainer.trailingAnchor, constant: -24)
        ])
    }

    private func setupEmptyState() {
        emptyLabel.text = "Selecciona una nota o crea una nueva para empezar."
        emptyLabel.font = .systemFont(ofSize: 16)
        emptyLabel.textColor = AtrilColors.textSecondary
        emptyLabel.textAlignment = .center
        emptyLabel.numberOfLines = 0

        emptyCreateBtn.setTitle(" Nueva nota", for: .normal)
        let cfg = UIImage.SymbolConfiguration(pointSize: 15, weight: .semibold)
        emptyCreateBtn.setImage(UIImage(systemName: "square.and.pencil", withConfiguration: cfg), for: .normal)
        emptyCreateBtn.tintColor = AtrilColors.bgPrimary
        emptyCreateBtn.setTitleColor(AtrilColors.bgPrimary, for: .normal)
        emptyCreateBtn.titleLabel?.font = .systemFont(ofSize: 14.5, weight: .semibold)
        emptyCreateBtn.backgroundColor = AtrilColors.gold
        emptyCreateBtn.layer.cornerRadius = 12
        emptyCreateBtn.contentEdgeInsets = UIEdgeInsets(top: 12, left: 18, bottom: 12, right: 18)
        emptyCreateBtn.addTarget(self, action: #selector(handleEmptyCreateTap), for: .touchUpInside)

        emptyView.axis = .vertical
        emptyView.alignment = .center
        emptyView.spacing = 16
        emptyView.addArrangedSubview(emptyLabel)
        emptyView.addArrangedSubview(emptyCreateBtn)
        emptyView.isHidden = true
        emptyView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(emptyView)

        NSLayoutConstraint.activate([
            emptyView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            emptyView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            emptyView.leadingAnchor.constraint(greaterThanOrEqualTo: view.leadingAnchor, constant: 32),
            emptyView.trailingAnchor.constraint(lessThanOrEqualTo: view.trailingAnchor, constant: -32)
        ])
    }

    // MARK: - State Updates

    func configure(note: Note?, liveMode: Bool, sidebarVisible: Bool, isCompactLayout: Bool, importingFiles: Bool) {
        let noteChanged = self.note?.id != note?.id
        self.note = note
        self.liveMode = liveMode
        self.sidebarVisible = sidebarVisible
        self.isCompactLayout = isCompactLayout
        self.importingFiles = importingFiles

        if noteChanged {
            cursorContext = (nil, nil)
            renderedBlocksSignature = ""
        }
        if liveMode {
            studyBarOpen = false
        }

        backButton.isHidden = !isCompactLayout
        sidebarToggleButton.isHidden = isCompactLayout

        let hasNote = note != nil
        toolbar.isHidden = !hasNote
        studyStrip.isHidden = !hasNote
        scrollView.isHidden = !hasNote
        emptyView.isHidden = hasNote

        addFileButton.isEnabled = !importingFiles
        addFileButton.alpha = importingFiles ? 0.55 : 1.0
        addFileButton.setTitle(importingFiles ? " Añadiendo..." : (isCompactLayout ? " Archivo" : " Añadir archivo"), for: .normal)

        syncMetronomeUI()

        guard let note = note else { return }

        let attCount = note.attachments.count
        var metaText = NoteLogic.formatDateShort(note.updatedAt)
        if attCount > 0 {
            let word = attCount == 1 ? "archivo" : "archivos"
            let bytesStr = NoteLogic.formatBytes(NoteLogic.getNoteTotalBytes(note))
            metaText += " · \(attCount) \(word) · \(bytesStr)"
        }
        metaLabel.text = metaText

        if !titleField.isFirstResponder && titleField.text != note.title {
            titleField.text = note.title
        }

        rebuildBlocksIfNeeded(note)
    }

    private func rebuildBlocksIfNeeded(_ note: Note) {
        let blocks = NoteLogic.normalizeNoteBlocks(note)
        let signature = blocks.map { b in
            b.type == .text ? "T:\(b.id)" : "S:\(b.id):\(b.attachmentId ?? "")"
        }.joined(separator: "|")

        if signature == renderedBlocksSignature && blocksStack.arrangedSubviews.count == blocks.count {
            // Update text views in-place without destroying focus
            for (idx, block) in blocks.enumerated() where block.type == .text {
                if let textViewBlock = blocksStack.arrangedSubviews[idx] as? InlineTextBlockView {
                    let isLast = idx == blocks.count - 1
                    let minH: CGFloat = isLast ? (blocks.count == 1 ? 150 : 96) : 34
                    textViewBlock.update(text: block.text ?? "", minHeight: minH)
                }
            }
            return
        }

        renderedBlocksSignature = signature
        blocksStack.arrangedSubviews.forEach { $0.removeFromSuperview() }
        let attById = Dictionary(uniqueKeysWithValues: note.attachments.map { ($0.id, $0) })

        for (idx, block) in blocks.enumerated() {
            if block.type == .text {
                let isFirst = idx == 0
                let isLast = idx == blocks.count - 1
                let minH: CGFloat = isLast ? (blocks.count == 1 ? 150 : 96) : 34
                let textBlockView = InlineTextBlockView(
                    blockId: block.id,
                    text: block.text ?? "",
                    placeholder: isFirst ? "Notas" : nil,
                    minHeight: minH
                )
                textBlockView.onFocusCursor = { [weak self] pos in
                    self?.cursorContext = (block.id, pos)
                }
                textBlockView.onTextChange = { [weak self] nextText, pos in
                    self?.handleTextBlockEdited(blockId: block.id, text: nextText, cursorPos: pos)
                }
                blocksStack.addArrangedSubview(textBlockView)
            } else if let attId = block.attachmentId, let att = attById[attId] {
                if att.kind == .image {
                    let imgCard = InlineImageSheetView(attachment: att)
                    imgCard.onOpen = { [weak self] id, page in
                        guard let nId = self?.note?.id else { return }
                        self?.delegate?.noteEditorDidOpenReader(nId, attachmentId: id, pageNumber: page)
                    }
                    imgCard.onRemove = { [weak self] id in
                        guard let nId = self?.note?.id else { return }
                        self?.delegate?.noteEditorDidRemoveAttachment(nId, attachmentId: id)
                    }
                    blocksStack.addArrangedSubview(imgCard)
                } else {
                    let pdfCard = InlinePdfSheetView(attachment: att)
                    pdfCard.onOpen = { [weak self] id, page in
                        guard let nId = self?.note?.id else { return }
                        self?.delegate?.noteEditorDidOpenReader(nId, attachmentId: id, pageNumber: page)
                    }
                    pdfCard.onRemove = { [weak self] id in
                        guard let nId = self?.note?.id else { return }
                        self?.delegate?.noteEditorDidRemoveAttachment(nId, attachmentId: id)
                    }
                    blocksStack.addArrangedSubview(pdfCard)
                }
            }
        }
    }

    private func handleTextBlockEdited(blockId: String, text: String, cursorPos: Int) {
        guard var current = note else { return }
        cursorContext = (blockId, cursorPos)
        let normalized = NoteLogic.normalizeNoteBlocks(current)
        let nextBlocks = normalized.map { block -> NoteBlock in
            if block.id == blockId && block.type == .text {
                return NoteBlock(id: block.id, text: text)
            }
            return block
        }
        let nextBody = NoteLogic.deriveBodyFromBlocks(nextBlocks)
        current.blocks = nextBlocks
        current.body = nextBody
        self.note = current
        delegate?.noteEditorDidUpdateNote(current.id, title: nil, body: nextBody, blocks: nextBlocks)
    }

    private func syncMetronomeUI() {
        let engine = MetronomeAudioEngine.shared

        // Live Mode pill appearance
        if liveMode {
            liveModeButton.backgroundColor = AtrilColors.gold
            liveModeButton.layer.borderColor = AtrilColors.gold.cgColor
            liveModeButton.tintColor = AtrilColors.bgPrimary
            liveModeButton.setTitleColor(AtrilColors.bgPrimary, for: .normal)
        } else {
            liveModeButton.backgroundColor = UIColor(hex: 0x222227)
            liveModeButton.layer.borderColor = AtrilColors.borderSubtle.cgColor
            liveModeButton.tintColor = AtrilColors.textSecondary
            liveModeButton.setTitleColor(AtrilColors.textSecondary, for: .normal)
        }

        // Study toggle pill
        studyToggleButton.isHidden = liveMode
        studyToggleBpmLabel.text = "\(engine.bpm)"
        if engine.isRunning {
            studyToggleButton.backgroundColor = AtrilColors.activeNoteBg
            studyToggleButton.layer.borderColor = AtrilColors.gold.withAlphaComponent(0.5).cgColor
            studyToggleBpmLabel.textColor = AtrilColors.gold
        } else if studyBarOpen {
            studyToggleButton.backgroundColor = UIColor(hex: 0x2A2A30)
            studyToggleButton.layer.borderColor = AtrilColors.borderLight.cgColor
            studyToggleBpmLabel.textColor = AtrilColors.textPrimary
        } else {
            studyToggleButton.backgroundColor = UIColor(hex: 0x222227)
            studyToggleButton.layer.borderColor = AtrilColors.borderSubtle.cgColor
            studyToggleBpmLabel.textColor = AtrilColors.textBody
        }

        // Study strip visibility
        let showStrip = (note != nil) && !liveMode && (studyBarOpen || engine.isRunning)
        studyStripHeightZero.isActive = !showStrip
        studyStrip.isHidden = !showStrip

        if engine.isRunning {
            studyPlayBtn.backgroundColor = AtrilColors.red
            studyPlayBtn.setTitle(" Detener", for: .normal)
            studyPlayBtn.setTitleColor(.white, for: .normal)
            studyPlayBtn.tintColor = .white
            let cfg = UIImage.SymbolConfiguration(pointSize: 11, weight: .bold)
            studyPlayBtn.setImage(UIImage(systemName: "pause.fill", withConfiguration: cfg), for: .normal)
        } else {
            studyPlayBtn.backgroundColor = AtrilColors.gold
            studyPlayBtn.setTitle(" Iniciar", for: .normal)
            studyPlayBtn.setTitleColor(AtrilColors.bgPrimary, for: .normal)
            studyPlayBtn.tintColor = AtrilColors.bgPrimary
            let cfg = UIImage.SymbolConfiguration(pointSize: 11, weight: .bold)
            studyPlayBtn.setImage(UIImage(systemName: "play.fill", withConfiguration: cfg), for: .normal)
        }

        studyBpmNumberLabel.text = "\(engine.bpm)"
        studyBpmSuffixLabel.text = "BPM · \(engine.timeSignature.rawValue)"
        if !studySlider.isTracking {
            studySlider.value = Float(engine.bpm)
        }
        studyDotsView.update(accents: engine.accents, currentBeat: engine.currentBeat, isRunning: engine.isRunning)
    }

    // MARK: - Actions

    @objc private func handleBackTap() {
        view.endEditing(true)
        delegate?.noteEditorDidTapCompactBack()
    }

    @objc private func handleToggleSidebarTap() {
        delegate?.noteEditorDidTapToggleSidebar()
    }

    @objc private func handleToggleLiveTap() {
        delegate?.noteEditorDidToggleLiveMode()
    }

    @objc private func handleStudyToggleTap() {
        studyBarOpen.toggle()
        syncMetronomeUI()
    }

    @objc private func handleStudyPlayTap() {
        MetronomeAudioEngine.shared.toggle()
    }

    @objc private func handleStudySliderChanged() {
        MetronomeAudioEngine.shared.setBpm(Int(studySlider.value.rounded()))
    }

    @objc private func handleMinus1Tap() {
        MetronomeAudioEngine.shared.adjustBpm(-1)
    }

    @objc private func handlePlus1Tap() {
        MetronomeAudioEngine.shared.adjustBpm(1)
    }

    @objc private func handleOpenClickTap() {
        delegate?.noteEditorDidTapOpenClickPanel()
    }

    @objc private func handleTitleChanged() {
        guard var current = note else { return }
        let title = titleField.text ?? ""
        current.title = title
        self.note = current
        delegate?.noteEditorDidUpdateNote(current.id, title: title, body: nil, blocks: nil)
    }

    @objc private func handleEmptyCreateTap() {
        onEmptyCreateNote?()
    }

    @objc private func handleAddFileTap() {
        let sheet = UIAlertController(title: "Añadir partitura o imagen", message: nil, preferredStyle: .actionSheet)
        sheet.addAction(UIAlertAction(title: "Elegir PDF o archivo (Archivos)", style: .default) { [weak self] _ in
            self?.presentDocumentPicker()
        })
        sheet.addAction(UIAlertAction(title: "Elegir foto o partitura (Fotos)", style: .default) { [weak self] _ in
            self?.presentPhotoPicker()
        })
        sheet.addAction(UIAlertAction(title: "Cancelar", style: .cancel))

        if let popover = sheet.popoverPresentationController {
            popover.sourceView = addFileButton
            popover.sourceRect = addFileButton.bounds
        }
        present(sheet, animated: true)
    }

    private func presentDocumentPicker() {
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: [UTType.pdf, UTType.image], asCopy: true)
        picker.allowsMultipleSelection = true
        picker.delegate = self
        present(picker, animated: true)
    }

    private func presentPhotoPicker() {
        var config = PHPickerConfiguration()
        config.selectionLimit = 10
        config.filter = .images
        let picker = PHPickerViewController(configuration: config)
        picker.delegate = self
        present(picker, animated: true)
    }

    @objc private func handleKeyboardFrame(_ notification: Notification) {
        guard let info = notification.userInfo,
              let endFrame = info[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect else { return }
        let converted = view.convert(endFrame, from: nil)
        let overlap = max(0, view.bounds.maxY - converted.minY)
        scrollBottomConstraint.constant = -overlap
        UIView.animate(withDuration: 0.22) {
            self.view.layoutIfNeeded()
        }
    }

    // MARK: - UIDocumentPickerDelegate

    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard let noteId = note?.id else { return }
        let ctx = cursorContext
        cursorContext = (nil, nil)

        var imported: [(fileName: String, mimeType: String?, data: Data)] = []
        for url in urls {
            let accessed = url.startAccessingSecurityScopedResource()
            defer { if accessed { url.stopAccessingSecurityScopedResource() } }
            if let data = try? Data(contentsOf: url) {
                let name = url.lastPathComponent
                let ext = url.pathExtension.lowercased()
                let mime = ext == "pdf" ? "application/pdf" : "image/\(ext.isEmpty ? "jpeg" : ext)"
                imported.append((name, mime, data))
            }
        }
        if !imported.isEmpty {
            delegate?.noteEditorDidImportItems(noteId, items: imported, insertContext: ctx)
        }
    }

    // MARK: - PHPickerViewControllerDelegate

    func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
        picker.dismiss(animated: true)
        guard !results.isEmpty, let noteId = note?.id else { return }
        let ctx = cursorContext
        cursorContext = (nil, nil)

        let group = DispatchGroup()
        var collected: [(Int, String, String?, Data)] = []
        let lock = NSLock()

        for (index, result) in results.enumerated() {
            let provider = result.itemProvider
            if provider.hasItemConformingToTypeIdentifier(UTType.image.identifier) {
                group.enter()
                provider.loadDataRepresentation(forTypeIdentifier: UTType.image.identifier) { data, _ in
                    defer { group.leave() }
                    guard let data = data else { return }
                    let suggested = provider.suggestedName ?? "Foto_\(index + 1)"
                    lock.lock()
                    collected.append((index, "\(suggested).jpg", "image/jpeg", data))
                    lock.unlock()
                }
            }
        }

        group.notify(queue: .main) { [weak self] in
            let sorted = collected.sorted { $0.0 < $1.0 }.map { ($0.1, $0.2, $0.3) }
            if !sorted.isEmpty {
                self?.delegate?.noteEditorDidImportItems(noteId, items: sorted, insertContext: ctx)
            }
        }
    }

    // MARK: - UIDropInteractionDelegate (iPad Split View Drag & Drop)

    func dropInteraction(_ interaction: UIDropInteraction, canHandle session: UIDropSession) -> Bool {
        return session.canLoadObjects(ofClass: UIImage.self) ||
            session.hasItemsConforming(toTypeIdentifiers: [UTType.pdf.identifier, UTType.image.identifier])
    }

    func dropInteraction(_ interaction: UIDropInteraction, sessionDidUpdate session: UIDropSession) -> UIDropProposal {
        return UIDropProposal(operation: .copy)
    }

    func dropInteraction(_ interaction: UIDropInteraction, performDrop session: UIDropSession) {
        guard let noteId = note?.id else { return }
        let ctx = cursorContext
        cursorContext = (nil, nil)

        let group = DispatchGroup()
        var collected: [(Int, String, String?, Data)] = []
        let lock = NSLock()

        for (idx, item) in session.items.enumerated() {
            let provider = item.itemProvider
            if provider.hasItemConformingToTypeIdentifier(UTType.pdf.identifier) {
                group.enter()
                provider.loadDataRepresentation(forTypeIdentifier: UTType.pdf.identifier) { data, _ in
                    defer { group.leave() }
                    guard let data = data else { return }
                    let name = (provider.suggestedName ?? "Partitura_\(idx + 1)") + ".pdf"
                    lock.lock()
                    collected.append((idx, name, "application/pdf", data))
                    lock.unlock()
                }
            } else if provider.hasItemConformingToTypeIdentifier(UTType.image.identifier) {
                group.enter()
                provider.loadDataRepresentation(forTypeIdentifier: UTType.image.identifier) { data, _ in
                    defer { group.leave() }
                    guard let data = data else { return }
                    let name = (provider.suggestedName ?? "Imagen_\(idx + 1)") + ".jpg"
                    lock.lock()
                    collected.append((idx, name, "image/jpeg", data))
                    lock.unlock()
                }
            }
        }

        group.notify(queue: .main) { [weak self] in
            let sorted = collected.sorted { $0.0 < $1.0 }.map { ($0.1, $0.2, $0.3) }
            if !sorted.isEmpty {
                self?.delegate?.noteEditorDidImportItems(noteId, items: sorted, insertContext: ctx)
            }
        }
    }

    // MARK: - MetronomeObserver

    func metronomeDidUpdateState(_ engine: MetronomeAudioEngine) {
        syncMetronomeUI()
    }

    func metronomeDidTickBeat(_ engine: MetronomeAudioEngine, beatIndex: Int, beatTick: Int) {
        studyDotsView.update(accents: engine.accents, currentBeat: beatIndex, isRunning: engine.isRunning)
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}
