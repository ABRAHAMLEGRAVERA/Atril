import UIKit

/// Auto-sizing UITextView representing one interleaved text block in a Note,
/// tracking exact cursor position so newly imported PDFs/images insert inline at the cursor.
final class InlineTextBlockView: UIView, UITextViewDelegate {
    let blockId: String
    private let textView = UITextView()
    private let placeholderLabel = UILabel()
    private var minHeightConstraint: NSLayoutConstraint!

    var onFocusCursor: ((Int) -> Void)?
    var onTextChange: ((String, Int) -> Void)?

    init(blockId: String, text: String, placeholder: String?, minHeight: CGFloat) {
        self.blockId = blockId
        super.init(frame: .zero)

        textView.backgroundColor = .clear
        textView.textColor = AtrilColors.textBody
        textView.tintColor = AtrilColors.gold
        textView.font = .systemFont(ofSize: 16.5, weight: .regular)
        textView.isScrollEnabled = false
        textView.textContainerInset = UIEdgeInsets(top: 4, left: 0, bottom: 4, right: 0)
        textView.textContainer.lineFragmentPadding = 0
        textView.text = text
        textView.delegate = self
        textView.translatesAutoresizingMaskIntoConstraints = false

        placeholderLabel.text = placeholder
        placeholderLabel.font = .systemFont(ofSize: 16.5, weight: .regular)
        placeholderLabel.textColor = AtrilColors.placeholder
        placeholderLabel.isHidden = !text.isEmpty || placeholder == nil
        placeholderLabel.translatesAutoresizingMaskIntoConstraints = false

        addSubview(placeholderLabel)
        addSubview(textView)

        minHeightConstraint = textView.heightAnchor.constraint(greaterThanOrEqualToConstant: minHeight)
        NSLayoutConstraint.activate([
            minHeightConstraint,
            textView.topAnchor.constraint(equalTo: topAnchor),
            textView.bottomAnchor.constraint(equalTo: bottomAnchor),
            textView.leadingAnchor.constraint(equalTo: leadingAnchor),
            textView.trailingAnchor.constraint(equalTo: trailingAnchor),

            placeholderLabel.topAnchor.constraint(equalTo: textView.topAnchor, constant: 4),
            placeholderLabel.leadingAnchor.constraint(equalTo: textView.leadingAnchor),
            placeholderLabel.trailingAnchor.constraint(equalTo: textView.trailingAnchor)
        ])
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func update(text: String, minHeight: CGFloat) {
        if !textView.isFirstResponder && textView.text != text {
            textView.text = text
        }
        placeholderLabel.isHidden = !(textView.text ?? "").isEmpty || placeholderLabel.text == nil
        minHeightConstraint.constant = minHeight
    }

    func textViewDidBeginEditing(_ textView: UITextView) {
        onFocusCursor?(textView.selectedRange.location)
    }

    func textViewDidChangeSelection(_ textView: UITextView) {
        if textView.isFirstResponder {
            onFocusCursor?(textView.selectedRange.location)
        }
    }

    func textViewDidChange(_ textView: UITextView) {
        let current = textView.text ?? ""
        placeholderLabel.isHidden = !current.isEmpty || placeholderLabel.text == nil
        onTextChange?(current, textView.selectedRange.location)
        invalidateIntrinsicContentSize()
    }
}
