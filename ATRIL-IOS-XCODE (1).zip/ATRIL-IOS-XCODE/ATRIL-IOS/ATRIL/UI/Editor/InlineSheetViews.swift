import PDFKit
import UIKit

/// Inline image card inside NoteEditor with async ImageIO thumbnail loading, tap-to-read, and remove button.
final class InlineImageSheetView: UIView {
    private let attachment: NoteAttachment
    private let imageView = UIImageView()
    private let aspectConstraint: NSLayoutConstraint
    private let removeButton = UIButton(type: .system)
    private let errorLabel = UILabel()
    private var loadedWidth: CGFloat = 0

    var onOpen: ((String, Int) -> Void)?
    var onRemove: ((String) -> Void)?

    init(attachment: NoteAttachment) {
        self.attachment = attachment
        self.aspectConstraint = imageView.heightAnchor.constraint(equalTo: imageView.widthAnchor, multiplier: 1.25)
        self.aspectConstraint.priority = .defaultHigh
        super.init(frame: .zero)

        layer.cornerRadius = 12
        clipsToBounds = true
        backgroundColor = AtrilColors.cardSecondary

        imageView.contentMode = .scaleAspectFit
        imageView.backgroundColor = .white
        imageView.isUserInteractionEnabled = true
        imageView.translatesAutoresizingMaskIntoConstraints = false
        let tap = UITapGestureRecognizer(target: self, action: #selector(handleTap))
        imageView.addGestureRecognizer(tap)
        addSubview(imageView)

        errorLabel.text = "No se pudo cargar \(attachment.fileName)"
        errorLabel.font = .systemFont(ofSize: 12.5)
        errorLabel.textColor = AtrilColors.textSecondary
        errorLabel.textAlignment = .center
        errorLabel.isHidden = true
        errorLabel.translatesAutoresizingMaskIntoConstraints = false
        addSubview(errorLabel)

        setupRemoveButton(removeButton, target: self, action: #selector(handleRemove))
        addSubview(removeButton)

        NSLayoutConstraint.activate([
            aspectConstraint,
            imageView.topAnchor.constraint(equalTo: topAnchor),
            imageView.bottomAnchor.constraint(equalTo: bottomAnchor),
            imageView.leadingAnchor.constraint(equalTo: leadingAnchor),
            imageView.trailingAnchor.constraint(equalTo: trailingAnchor),

            errorLabel.centerXAnchor.constraint(equalTo: centerXAnchor),
            errorLabel.centerYAnchor.constraint(equalTo: centerYAnchor),
            errorLabel.leadingAnchor.constraint(greaterThanOrEqualTo: leadingAnchor, constant: 16),

            removeButton.topAnchor.constraint(equalTo: topAnchor, constant: 8),
            removeButton.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -8),
            removeButton.widthAnchor.constraint(equalToConstant: 32),
            removeButton.heightAnchor.constraint(equalToConstant: 32)
        ])
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        let w = bounds.width
        if w > 80 && abs(w - loadedWidth) > 24 {
            loadedWidth = w
            loadImage(targetWidth: w)
        }
    }

    private func loadImage(targetWidth: CGFloat) {
        let scale = min(UIScreen.main.scale, 1.5)
        AtrilRepository.shared.renderThumbnail(for: attachment, pageNumber: 1, targetWidthPoints: targetWidth, scale: scale) { [weak self] img in
            guard let self = self else { return }
            if let img = img, img.size.width > 0 {
                self.errorLabel.isHidden = true
                self.imageView.image = img
                let ratio = max(0.3, min(2.5, img.size.height / img.size.width))
                self.aspectConstraint.isActive = false
                let next = self.imageView.heightAnchor.constraint(equalTo: self.imageView.widthAnchor, multiplier: ratio)
                next.priority = .required
                next.isActive = true
                self.invalidateIntrinsicContentSize()
            } else {
                self.errorLabel.isHidden = false
            }
        }
    }

    @objc private func handleTap() {
        onOpen?(attachment.id, 1)
    }

    @objc private func handleRemove() {
        onRemove?(attachment.id)
    }
}

/// Inline multi-page PDF sheet stack inside NoteEditor backed natively by PDFKit.
final class InlinePdfSheetView: UIView {
    private let attachment: NoteAttachment
    private let pagesStack = UIStackView()
    private let removeButton = UIButton(type: .system)
    private var pageViews: [(pageNum: Int, imageView: UIImageView, ratioConstraint: NSLayoutConstraint)] = []
    private var loadedWidth: CGFloat = 0

    var onOpen: ((String, Int) -> Void)?
    var onRemove: ((String) -> Void)?

    init(attachment: NoteAttachment) {
        self.attachment = attachment
        super.init(frame: .zero)

        pagesStack.axis = .vertical
        pagesStack.spacing = 10
        pagesStack.translatesAutoresizingMaskIntoConstraints = false
        addSubview(pagesStack)

        setupRemoveButton(removeButton, target: self, action: #selector(handleRemove))
        addSubview(removeButton)

        let totalPages = max(1, attachment.pageCount)
        for p in 1...totalPages {
            let iv = UIImageView()
            iv.contentMode = .scaleAspectFit
            iv.backgroundColor = .white
            iv.layer.cornerRadius = 12
            iv.clipsToBounds = true
            iv.isUserInteractionEnabled = true
            iv.tag = p
            iv.translatesAutoresizingMaskIntoConstraints = false

            let tap = UITapGestureRecognizer(target: self, action: #selector(handlePageTap(_:)))
            iv.addGestureRecognizer(tap)

            let ratioConstraint = iv.heightAnchor.constraint(equalTo: iv.widthAnchor, multiplier: 1.294)
            ratioConstraint.priority = .required
            ratioConstraint.isActive = true

            pagesStack.addArrangedSubview(iv)
            pageViews.append((p, iv, ratioConstraint))
        }

        NSLayoutConstraint.activate([
            pagesStack.topAnchor.constraint(equalTo: topAnchor),
            pagesStack.bottomAnchor.constraint(equalTo: bottomAnchor),
            pagesStack.leadingAnchor.constraint(equalTo: leadingAnchor),
            pagesStack.trailingAnchor.constraint(equalTo: trailingAnchor),

            removeButton.topAnchor.constraint(equalTo: topAnchor, constant: 8),
            removeButton.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -8),
            removeButton.widthAnchor.constraint(equalToConstant: 32),
            removeButton.heightAnchor.constraint(equalToConstant: 32)
        ])
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        let w = bounds.width
        if w > 80 && abs(w - loadedWidth) > 24 {
            loadedWidth = w
            renderPages(targetWidth: w)
        }
    }

    private func renderPages(targetWidth: CGFloat) {
        let scale: CGFloat = 1.5
        for item in pageViews {
            AtrilRepository.shared.renderThumbnail(for: attachment, pageNumber: item.pageNum, targetWidthPoints: targetWidth, scale: scale) { [weak self] img in
                guard let self = self, let img = img, img.size.width > 0 else { return }
                item.imageView.image = img
                let ratio = max(0.4, min(2.2, img.size.height / img.size.width))
                if abs(item.ratioConstraint.multiplier - ratio) > 0.02 {
                    item.ratioConstraint.isActive = false
                    let updated = item.imageView.heightAnchor.constraint(equalTo: item.imageView.widthAnchor, multiplier: ratio)
                    updated.priority = .required
                    updated.isActive = true
                    if let idx = self.pageViews.firstIndex(where: { $0.pageNum == item.pageNum }) {
                        self.pageViews[idx].ratioConstraint = updated
                    }
                    self.invalidateIntrinsicContentSize()
                }
            }
        }
    }

    @objc private func handlePageTap(_ gesture: UITapGestureRecognizer) {
        guard let view = gesture.view else { return }
        onOpen?(attachment.id, max(1, view.tag))
    }

    @objc private func handleRemove() {
        onRemove?(attachment.id)
    }
}

private func setupRemoveButton(_ button: UIButton, target: Any?, action: Selector) {
    let cfg = UIImage.SymbolConfiguration(pointSize: 12, weight: .bold)
    button.setImage(UIImage(systemName: "xmark", withConfiguration: cfg), for: .normal)
    button.tintColor = .white
    button.backgroundColor = UIColor.black.withAlphaComponent(0.62)
    button.layer.cornerRadius = 16
    button.accessibilityLabel = "Quitar archivo"
    button.addTarget(target, action: action, for: .touchUpInside)
    button.translatesAutoresizingMaskIntoConstraints = false
}
