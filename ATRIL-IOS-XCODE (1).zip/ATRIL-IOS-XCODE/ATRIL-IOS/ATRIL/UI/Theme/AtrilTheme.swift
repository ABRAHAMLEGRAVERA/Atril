import UIKit

enum AtrilColors {
    static let bgPrimary = UIColor(hex: 0x161618)
    static let editorSurface = UIColor(hex: 0x1C1C1F)
    static let studyStrip = UIColor(hex: 0x18181B)
    static let card = UIColor(hex: 0x1E1E23)
    static let cardSecondary = UIColor(hex: 0x25252A)
    static let controlSurface = UIColor(hex: 0x27272E)
    static let dock = UIColor(hex: 0x141416)
    static let activePill = UIColor(hex: 0x25252B)
    static let activeNoteBg = UIColor(hex: 0x2B251B)

    static let gold = UIColor(hex: 0xE5A93C)
    static let textPrimary = UIColor(hex: 0xF5F5F7)
    static let textBody = UIColor(hex: 0xE5E5EA)
    static let textSecondary = UIColor(hex: 0xA1A1A6)
    static let textMuted = UIColor(hex: 0x78787E)
    static let placeholder = UIColor(hex: 0x5E5E64)

    static let green = UIColor(hex: 0x30D158)
    static let red = UIColor(hex: 0xFF453A)
    static let amber = UIColor(hex: 0xFF9F0A)
    static let borderSubtle = UIColor(white: 1.0, alpha: 0.08)
    static let borderLight = UIColor(white: 1.0, alpha: 0.14)
}

extension UIColor {
    convenience init(hex: UInt32, alpha: CGFloat = 1.0) {
        let r = CGFloat((hex >> 16) & 0xFF) / 255.0
        let g = CGFloat((hex >> 8) & 0xFF) / 255.0
        let b = CGFloat(hex & 0xFF) / 255.0
        self.init(red: r, green: g, blue: b, alpha: alpha)
    }
}

/// Core Graphics music-stand emblem + "ATRIL" wordmark used in the sidebar header.
final class AtrilLogoView: UIView {
    private let iconView = AtrilMarkView()
    private let titleLabel = UILabel()

    override init(frame: CGRect) {
        super.init(frame: frame)
        let stack = UIStackView(arrangedSubviews: [iconView, titleLabel])
        stack.axis = .horizontal
        stack.alignment = .center
        stack.spacing = 10
        stack.translatesAutoresizingMaskIntoConstraints = false

        iconView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            iconView.widthAnchor.constraint(equalToConstant: 28),
            iconView.heightAnchor.constraint(equalToConstant: 28)
        ])

        titleLabel.text = "ATRIL"
        titleLabel.font = .systemFont(ofSize: 17, weight: .bold)
        titleLabel.textColor = AtrilColors.textPrimary
        let attributed = NSMutableAttributedString(string: "ATRIL")
        attributed.addAttribute(.kern, value: 0.8, range: NSRange(location: 0, length: 5))
        titleLabel.attributedText = attributed

        addSubview(stack)
        NSLayoutConstraint.activate([
            stack.leadingAnchor.constraint(equalTo: leadingAnchor),
            stack.trailingAnchor.constraint(equalTo: trailingAnchor),
            stack.topAnchor.constraint(equalTo: topAnchor),
            stack.bottomAnchor.constraint(equalTo: bottomAnchor)
        ])
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

private final class AtrilMarkView: UIView {
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = UIColor(hex: 0x232327)
        layer.cornerRadius = 7
        clipsToBounds = true
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func draw(_ rect: CGRect) {
        guard let ctx = UIGraphicsGetCurrentContext() else { return }
        let s = min(rect.width, rect.height) / 120.0
        ctx.saveGState()
        ctx.scaleBy(x: s, y: s)

        AtrilColors.gold.setFill()
        AtrilColors.gold.setStroke()

        // Music desk board
        let board = UIBezierPath()
        board.move(to: CGPoint(x: 34, y: 70))
        board.addLine(to: CGPoint(x: 38, y: 34))
        board.addLine(to: CGPoint(x: 82, y: 34))
        board.addLine(to: CGPoint(x: 86, y: 70))
        board.lineWidth = 6.5
        board.lineCapStyle = .round
        board.lineJoinStyle = .round
        board.stroke()

        // Desk shelf
        let tray = UIBezierPath()
        tray.move(to: CGPoint(x: 26, y: 70))
        tray.addLine(to: CGPoint(x: 94, y: 70))
        tray.addLine(to: CGPoint(x: 88, y: 80))
        tray.addLine(to: CGPoint(x: 32, y: 80))
        tray.close()
        tray.fill()

        // Stand pole & base
        let stand = UIBezierPath()
        stand.move(to: CGPoint(x: 60, y: 80))
        stand.addLine(to: CGPoint(x: 60, y: 100))
        stand.move(to: CGPoint(x: 44, y: 100))
        stand.addLine(to: CGPoint(x: 76, y: 100))
        stand.lineWidth = 6.5
        stand.lineCapStyle = .round
        stand.stroke()

        // Eighth note inside desk
        let notePath = UIBezierPath()
        notePath.move(to: CGPoint(x: 64, y: 42))
        notePath.addLine(to: CGPoint(x: 64, y: 60))
        notePath.move(to: CGPoint(x: 64, y: 42))
        notePath.addLine(to: CGPoint(x: 74, y: 48))
        notePath.lineWidth = 5
        notePath.lineCapStyle = .round
        notePath.stroke()

        let head = UIBezierPath(ovalIn: CGRect(x: 51, y: 55.5, width: 12.5, height: 9))
        head.fill()

        ctx.restoreGState()
    }
}

/// Visual Beat Dots (3 / 4 / 6 dots matching time signature) shown inside Note Editor & Sheet Reader.
final class VisualBeatDotsView: UIView {
    enum Size {
        case sm
        case md
    }

    private let dotSize: Size
    private var dotViews: [UIView] = []
    private let stack = UIStackView()

    init(size: Size) {
        self.dotSize = size
        super.init(frame: .zero)
        stack.axis = .horizontal
        stack.alignment = .center
        stack.spacing = (size == .sm) ? 6 : 8
        stack.translatesAutoresizingMaskIntoConstraints = false
        addSubview(stack)
        NSLayoutConstraint.activate([
            stack.leadingAnchor.constraint(equalTo: leadingAnchor),
            stack.trailingAnchor.constraint(equalTo: trailingAnchor),
            stack.topAnchor.constraint(equalTo: topAnchor),
            stack.bottomAnchor.constraint(equalTo: bottomAnchor)
        ])
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func update(accents: [BeatAccent], currentBeat: Int?, isRunning: Bool) {
        if dotViews.count != accents.count {
            dotViews.forEach { $0.removeFromSuperview() }
            dotViews.removeAll()

            let dim: CGFloat = (dotSize == .sm) ? 8 : 10
            for _ in 0..<accents.count {
                let dot = UIView()
                dot.translatesAutoresizingMaskIntoConstraints = false
                dot.layer.cornerRadius = dim / 2.0
                NSLayoutConstraint.activate([
                    dot.widthAnchor.constraint(equalToConstant: dim),
                    dot.heightAnchor.constraint(equalToConstant: dim)
                ])
                stack.addArrangedSubview(dot)
                dotViews.append(dot)
            }
        }

        for (idx, accent) in accents.enumerated() {
            let dot = dotViews[idx]
            let isActive = isRunning && currentBeat == idx

            if isActive {
                if accent == .strong || idx == 0 {
                    dot.backgroundColor = AtrilColors.gold
                } else if accent == .mute {
                    dot.backgroundColor = UIColor(white: 1.0, alpha: 0.45)
                } else {
                    dot.backgroundColor = AtrilColors.textPrimary
                }
                dot.transform = CGAffineTransform(scaleX: 1.32, y: 1.32)
            } else {
                dot.transform = .identity
                if accent == .mute {
                    dot.backgroundColor = UIColor(white: 1.0, alpha: 0.12)
                } else if accent == .strong {
                    dot.backgroundColor = AtrilColors.gold.withAlphaComponent(0.28)
                } else {
                    dot.backgroundColor = UIColor(white: 1.0, alpha: 0.22)
                }
            }
        }
    }
}
