import UIKit

final class TunerViewController: UIViewController {
    private let audioEngine = TunerAudioEngine()

    private var instrument: TunerInstrument = .guitar
    private var a4Hz: Double = 440.0
    private var lockedMidi: Int?
    private var playRefToneOnTap: Bool = true
    private var listening: Bool = false
    private var micError: String?
    private var detected: DetectedNoteInfo?
    private var smoothedCents: Double = 0

    private let instrumentControl = UISegmentedControl(items: ["GUITARRA", "BAJO"])
    private let a4Button = UIButton(type: .system)

    private let noteReadoutLabel = UILabel()
    private let hzLabel = UILabel()
    private let statusLabel = UILabel()
    private let gaugeView = TunerGaugeView()
    private let centsLabel = UILabel()

    private let modeLabel = UILabel()
    private let speakerButton = UIButton(type: .system)
    private let stringsContainer = UIStackView()
    private var stringButtons: [(spec: TunerStringSpec, button: UIButton)] = []

    private let micStatusLabel = UILabel()
    private let micButton = UIButton(type: .system)
    private let adaptiveGrid = UIStackView()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = AtrilColors.bgPrimary
        setupUI()
        syncUI()
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if listening {
            stopMicrophone()
        }
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        let isWide = view.bounds.width >= 820
        adaptiveGrid.axis = isWide ? .horizontal : .vertical
        adaptiveGrid.alignment = isWide ? .center : .fill
        adaptiveGrid.distribution = isWide ? .fillEqually : .fill
        adaptiveGrid.spacing = isWide ? 36 : 24
    }

    private func setupUI() {
        let header = UIView()
        header.backgroundColor = AtrilColors.bgPrimary
        header.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(header)

        let headerSep = UIView()
        headerSep.backgroundColor = UIColor(white: 1, alpha: 0.06)
        headerSep.translatesAutoresizingMaskIntoConstraints = false
        header.addSubview(headerSep)

        let titleLbl = UILabel()
        titleLbl.text = "Afinador Cromático"
        titleLbl.font = .systemFont(ofSize: 17, weight: .semibold)
        titleLbl.textColor = AtrilColors.textPrimary
        titleLbl.translatesAutoresizingMaskIntoConstraints = false
        header.addSubview(titleLbl)

        instrumentControl.selectedSegmentIndex = 0
        instrumentControl.backgroundColor = UIColor(hex: 0x202026)
        instrumentControl.selectedSegmentTintColor = UIColor(hex: 0x2E2E36)
        instrumentControl.setTitleTextAttributes([
            .foregroundColor: AtrilColors.textSecondary,
            .font: UIFont.systemFont(ofSize: 12, weight: .semibold)
        ], for: .normal)
        instrumentControl.setTitleTextAttributes([
            .foregroundColor: AtrilColors.textPrimary,
            .font: UIFont.systemFont(ofSize: 12, weight: .semibold)
        ], for: .selected)
        instrumentControl.addTarget(self, action: #selector(handleInstrumentChanged), for: .valueChanged)

        a4Button.setTitleColor(AtrilColors.textPrimary, for: .normal)
        a4Button.titleLabel?.font = .monospacedDigitSystemFont(ofSize: 12.5, weight: .medium)
        a4Button.backgroundColor = UIColor(hex: 0x202026)
        a4Button.layer.cornerRadius = 11
        a4Button.layer.borderWidth = 1
        a4Button.layer.borderColor = AtrilColors.borderSubtle.cgColor
        a4Button.contentEdgeInsets = UIEdgeInsets(top: 8, left: 12, bottom: 8, right: 12)
        a4Button.addTarget(self, action: #selector(handleToggleA4), for: .touchUpInside)

        let rightHeader = UIStackView(arrangedSubviews: [instrumentControl, a4Button])
        rightHeader.axis = .horizontal
        rightHeader.alignment = .center
        rightHeader.spacing = 8
        rightHeader.translatesAutoresizingMaskIntoConstraints = false
        header.addSubview(rightHeader)

        let scrollView = UIScrollView()
        scrollView.alwaysBounceVertical = true
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scrollView)

        let guide = view.safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            header.topAnchor.constraint(equalTo: guide.topAnchor),
            header.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            header.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            header.heightAnchor.constraint(equalToConstant: 56),

            headerSep.leadingAnchor.constraint(equalTo: header.leadingAnchor),
            headerSep.trailingAnchor.constraint(equalTo: header.trailingAnchor),
            headerSep.bottomAnchor.constraint(equalTo: header.bottomAnchor),
            headerSep.heightAnchor.constraint(equalToConstant: 1),

            titleLbl.leadingAnchor.constraint(equalTo: header.leadingAnchor, constant: 20),
            titleLbl.centerYAnchor.constraint(equalTo: header.centerYAnchor),

            rightHeader.trailingAnchor.constraint(equalTo: header.trailingAnchor, constant: -20),
            rightHeader.centerYAnchor.constraint(equalTo: header.centerYAnchor),

            scrollView.topAnchor.constraint(equalTo: header.bottomAnchor),
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            scrollView.bottomAnchor.constraint(equalTo: guide.bottomAnchor)
        ])

        // Left Column: Note Readout + Gauge + Cents
        let leftCol = UIStackView()
        leftCol.axis = .vertical
        leftCol.alignment = .center
        leftCol.spacing = 10

        noteReadoutLabel.font = .monospacedDigitSystemFont(ofSize: 60, weight: .bold)
        noteReadoutLabel.textAlignment = .center

        hzLabel.font = .monospacedDigitSystemFont(ofSize: 13.5, weight: .medium)
        hzLabel.textColor = AtrilColors.textSecondary

        let dotLbl = UILabel()
        dotLbl.text = "·"
        dotLbl.textColor = AtrilColors.placeholder

        statusLabel.font = .systemFont(ofSize: 13.5, weight: .semibold)

        let subRow = UIStackView(arrangedSubviews: [hzLabel, dotLbl, statusLabel])
        subRow.axis = .horizontal
        subRow.spacing = 8

        gaugeView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            gaugeView.widthAnchor.constraint(equalToConstant: 290),
            gaugeView.heightAnchor.constraint(equalToConstant: 168)
        ])

        centsLabel.font = .monospacedDigitSystemFont(ofSize: 13.5, weight: .medium)
        centsLabel.textColor = AtrilColors.textSecondary
        centsLabel.textAlignment = .center

        leftCol.addArrangedSubview(noteReadoutLabel)
        leftCol.addArrangedSubview(subRow)
        leftCol.addArrangedSubview(gaugeView)
        leftCol.addArrangedSubview(centsLabel)

        // Right Column: Mode bar + Strings Grid + Mic CTA
        let rightCol = UIStackView()
        rightCol.axis = .vertical
        rightCol.spacing = 14

        let modeCard = UIView()
        modeCard.backgroundColor = AtrilColors.card
        modeCard.layer.cornerRadius = 12
        modeCard.layer.borderWidth = 1
        modeCard.layer.borderColor = AtrilColors.borderSubtle.cgColor

        modeLabel.font = .systemFont(ofSize: 12.5)
        modeLabel.textColor = UIColor(hex: 0xD1D1D6)
        modeLabel.lineBreakMode = .byTruncatingTail
        modeLabel.translatesAutoresizingMaskIntoConstraints = false

        speakerButton.layer.cornerRadius = 9
        speakerButton.addTarget(self, action: #selector(handleToggleSpeaker), for: .touchUpInside)
        speakerButton.translatesAutoresizingMaskIntoConstraints = false

        modeCard.addSubview(modeLabel)
        modeCard.addSubview(speakerButton)
        NSLayoutConstraint.activate([
            modeCard.heightAnchor.constraint(equalToConstant: 46),
            modeLabel.leadingAnchor.constraint(equalTo: modeCard.leadingAnchor, constant: 14),
            modeLabel.centerYAnchor.constraint(equalTo: modeCard.centerYAnchor),
            modeLabel.trailingAnchor.constraint(lessThanOrEqualTo: speakerButton.leadingAnchor, constant: -8),
            speakerButton.trailingAnchor.constraint(equalTo: modeCard.trailingAnchor, constant: -8),
            speakerButton.centerYAnchor.constraint(equalTo: modeCard.centerYAnchor),
            speakerButton.widthAnchor.constraint(equalToConstant: 34),
            speakerButton.heightAnchor.constraint(equalToConstant: 34)
        ])

        stringsContainer.axis = .vertical
        stringsContainer.spacing = 8

        micStatusLabel.font = .systemFont(ofSize: 12.5)
        micStatusLabel.textAlignment = .center
        micStatusLabel.numberOfLines = 0

        micButton.layer.cornerRadius = 16
        micButton.titleLabel?.font = .systemFont(ofSize: 15, weight: .semibold)
        micButton.heightAnchor.constraint(equalToConstant: 54).isActive = true
        micButton.addTarget(self, action: #selector(handleToggleMic), for: .touchUpInside)

        rightCol.addArrangedSubview(modeCard)
        rightCol.addArrangedSubview(stringsContainer)
        rightCol.addArrangedSubview(micStatusLabel)
        rightCol.addArrangedSubview(micButton)

        adaptiveGrid.addArrangedSubview(leftCol)
        adaptiveGrid.addArrangedSubview(rightCol)
        adaptiveGrid.translatesAutoresizingMaskIntoConstraints = false

        let holder = UIView()
        holder.translatesAutoresizingMaskIntoConstraints = false
        scrollView.addSubview(holder)
        holder.addSubview(adaptiveGrid)

        let maxW = adaptiveGrid.widthAnchor.constraint(lessThanOrEqualToConstant: 920)
        maxW.priority = .required
        let fillW = adaptiveGrid.widthAnchor.constraint(equalTo: holder.widthAnchor, constant: -40)
        fillW.priority = .defaultHigh

        NSLayoutConstraint.activate([
            holder.topAnchor.constraint(equalTo: scrollView.contentLayoutGuide.topAnchor),
            holder.bottomAnchor.constraint(equalTo: scrollView.contentLayoutGuide.bottomAnchor),
            holder.leadingAnchor.constraint(equalTo: scrollView.contentLayoutGuide.leadingAnchor),
            holder.trailingAnchor.constraint(equalTo: scrollView.contentLayoutGuide.trailingAnchor),
            holder.widthAnchor.constraint(equalTo: scrollView.frameLayoutGuide.widthAnchor),
            holder.heightAnchor.constraint(greaterThanOrEqualTo: scrollView.frameLayoutGuide.heightAnchor),

            adaptiveGrid.centerXAnchor.constraint(equalTo: holder.centerXAnchor),
            adaptiveGrid.centerYAnchor.constraint(equalTo: holder.centerYAnchor),
            adaptiveGrid.topAnchor.constraint(greaterThanOrEqualTo: holder.topAnchor, constant: 24),
            adaptiveGrid.bottomAnchor.constraint(lessThanOrEqualTo: holder.bottomAnchor, constant: -24),
            maxW,
            fillW
        ])

        rebuildStringsGrid()
    }

    private func rebuildStringsGrid() {
        stringsContainer.arrangedSubviews.forEach { $0.removeFromSuperview() }
        stringButtons.removeAll()

        let specs = instrument == .guitar ? MusicStudioMath.guitarStrings : MusicStudioMath.bassStrings
        let cols = instrument == .guitar ? 3 : 2
        let rowCount = Int(ceil(Double(specs.count) / Double(cols)))

        for r in 0..<rowCount {
            let row = UIStackView()
            row.axis = .horizontal
            row.distribution = .fillEqually
            row.spacing = 8
            for c in 0..<cols {
                let idx = r * cols + c
                if idx < specs.count {
                    let spec = specs[idx]
                    let btn = UIButton(type: .system)
                    btn.tag = spec.midi
                    btn.layer.cornerRadius = 12
                    btn.layer.borderWidth = 1
                    btn.titleLabel?.numberOfLines = 2
                    btn.titleLabel?.textAlignment = .center
                    btn.heightAnchor.constraint(equalToConstant: 58).isActive = true
                    btn.addTarget(self, action: #selector(handleStringTap(_:)), for: .touchUpInside)
                    row.addArrangedSubview(btn)
                    stringButtons.append((spec, btn))
                }
            }
            stringsContainer.addArrangedSubview(row)
        }
    }

    private func syncUI() {
        a4Button.setTitle("A4 = \(Int(a4Hz)) Hz", for: .normal)

        let specs = instrument == .guitar ? MusicStudioMath.guitarStrings : MusicStudioMath.bassStrings
        let lockedSpec = specs.first { $0.midi == lockedMidi }

        if let det = detected {
            noteReadoutLabel.text = det.label
            noteReadoutLabel.textColor = det.status == .inTune ? AtrilColors.green : AtrilColors.textPrimary
            hzLabel.text = String(format: "%.1f Hz", det.frequency)
            centsLabel.text = "\(smoothedCents >= 0 ? "+" : "")\(Int(smoothedCents.rounded())) cents"
            gaugeView.update(cents: smoothedCents, isDetected: true, isInTune: det.status == .inTune)
        } else {
            noteReadoutLabel.text = lockedSpec?.label ?? "–"
            noteReadoutLabel.textColor = AtrilColors.textPrimary
            hzLabel.text = "— Hz"
            centsLabel.text = "— cents"
            gaugeView.update(cents: 0, isDetected: false, isInTune: false)
        }

        if !listening {
            statusLabel.text = "En espera"
            statusLabel.textColor = AtrilColors.textSecondary
        } else if let det = detected {
            switch det.status {
            case .inTune:
                statusLabel.text = "Afinado"
                statusLabel.textColor = AtrilColors.green
            case .flat:
                statusLabel.text = "Bajo (tensar)"
                statusLabel.textColor = AtrilColors.gold
            case .sharp:
                statusLabel.text = "Alto (aflojar)"
                statusLabel.textColor = AtrilColors.gold
            }
        } else {
            statusLabel.text = "Escuchando..."
            statusLabel.textColor = AtrilColors.textSecondary
        }

        if let locked = lockedSpec {
            modeLabel.text = "Fijada: \(locked.label) · Toca otra vez para modo libre"
        } else {
            modeLabel.text = "Modo libre · Toca una nota para fijarla"
        }

        let spkCfg = UIImage.SymbolConfiguration(pointSize: 15, weight: .semibold)
        if playRefToneOnTap {
            speakerButton.setImage(UIImage(systemName: "speaker.wave.2.fill", withConfiguration: spkCfg), for: .normal)
            speakerButton.tintColor = AtrilColors.gold
            speakerButton.backgroundColor = AtrilColors.gold.withAlphaComponent(0.14)
        } else {
            speakerButton.setImage(UIImage(systemName: "speaker.slash.fill", withConfiguration: spkCfg), for: .normal)
            speakerButton.tintColor = AtrilColors.textMuted
            speakerButton.backgroundColor = .clear
        }

        for (spec, btn) in stringButtons {
            let hz = MusicStudioMath.midiToFrequency(spec.midi, a4Hz: a4Hz)
            let isLocked = lockedMidi == spec.midi
            btn.backgroundColor = isLocked ? AtrilColors.gold.withAlphaComponent(0.18) : AtrilColors.card
            btn.layer.borderColor = isLocked ? AtrilColors.gold.cgColor : AtrilColors.borderSubtle.cgColor

            let attr = NSMutableAttributedString(
                string: "\(spec.label)\n",
                attributes: [.font: UIFont.systemFont(ofSize: 14.5, weight: .semibold), .foregroundColor: AtrilColors.textPrimary]
            )
            attr.append(NSAttributedString(
                string: String(format: "%.2f Hz", hz),
                attributes: [.font: UIFont.monospacedDigitSystemFont(ofSize: 11, weight: .regular), .foregroundColor: AtrilColors.textSecondary]
            ))
            btn.setAttributedTitle(attr, for: .normal)
        }

        if let err = micError {
            micStatusLabel.text = err
            micStatusLabel.textColor = UIColor(hex: 0xFF6961)
        } else if listening {
            micStatusLabel.text = "Micrófono activo · Toca una cuerda para afinar"
            micStatusLabel.textColor = UIColor(hex: 0x8E8E93)
        } else {
            micStatusLabel.text = "Pulsa «Iniciar micrófono» para afinar"
            micStatusLabel.textColor = UIColor(hex: 0x8E8E93)
        }

        let micCfg = UIImage.SymbolConfiguration(pointSize: 15, weight: .semibold)
        if listening {
            micButton.backgroundColor = AtrilColors.red
            micButton.setTitle(" Detener micrófono", for: .normal)
            micButton.setTitleColor(.white, for: .normal)
            micButton.tintColor = .white
            micButton.setImage(UIImage(systemName: "mic.slash.fill", withConfiguration: micCfg), for: .normal)
        } else {
            micButton.backgroundColor = AtrilColors.gold
            micButton.setTitle(" Iniciar micrófono", for: .normal)
            micButton.setTitleColor(AtrilColors.bgPrimary, for: .normal)
            micButton.tintColor = AtrilColors.bgPrimary
            micButton.setImage(UIImage(systemName: "mic.fill", withConfiguration: micCfg), for: .normal)
        }
    }

    private func startMicrophone() {
        micError = nil
        audioEngine.startMicrophone(
            onPitch: { [weak self] freq in
                guard let self = self else { return }
                if let info = MusicStudioMath.analyzeFrequency(freq, a4Hz: self.a4Hz, lockedMidi: self.lockedMidi) {
                    self.smoothedCents = self.smoothedCents * 0.55 + info.cents * 0.45
                    self.detected = info
                    self.syncUI()
                }
            },
            onStateChange: { [weak self] active in
                self?.listening = active
                self?.syncUI()
            },
            onError: { [weak self] msg in
                self?.micError = msg
                self?.listening = false
                self?.syncUI()
            }
        )
    }

    private func stopMicrophone() {
        audioEngine.stopMicrophone()
        listening = false
        detected = nil
        smoothedCents = 0
        syncUI()
    }

    // MARK: - Actions

    @objc private func handleInstrumentChanged() {
        instrument = instrumentControl.selectedSegmentIndex == 1 ? .bass : .guitar
        lockedMidi = nil
        rebuildStringsGrid()
        syncUI()
    }

    @objc private func handleToggleA4() {
        a4Hz = (a4Hz == 440.0) ? 432.0 : 440.0
        syncUI()
    }

    @objc private func handleToggleSpeaker() {
        playRefToneOnTap.toggle()
        syncUI()
    }

    @objc private func handleStringTap(_ sender: UIButton) {
        let midi = sender.tag
        lockedMidi = (lockedMidi == midi) ? nil : midi
        if playRefToneOnTap {
            audioEngine.playReferenceTone(frequency: MusicStudioMath.midiToFrequency(midi, a4Hz: a4Hz))
        }
        syncUI()
    }

    @objc private func handleToggleMic() {
        if listening {
            stopMicrophone()
        } else {
            startMicrophone()
        }
    }
}

/// Core Graphics semicircular chromatic cents gauge with green center target zone and rotating needle.
private final class TunerGaugeView: UIView {
    private var cents: Double = 0
    private var isDetected: Bool = false
    private var isInTune: Bool = false

    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        isOpaque = false
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func update(cents: Double, isDetected: Bool, isInTune: Bool) {
        self.cents = cents
        self.isDetected = isDetected
        self.isInTune = isInTune
        setNeedsDisplay()
    }

    override func draw(_ rect: CGRect) {
        guard let ctx = UIGraphicsGetCurrentContext() else { return }
        let center = CGPoint(x: rect.width / 2.0, y: rect.height - 20)
        let radius: CGFloat = 95

        // Background track arc (-135 deg to -45 deg in UIKit coordinates, i.e., +/-45 deg from vertical up)
        let startAngle = -CGFloat.pi / 2.0 - CGFloat.pi / 4.0
        let endAngle = -CGFloat.pi / 2.0 + CGFloat.pi / 4.0

        let bgArc = UIBezierPath(arcCenter: center, radius: radius, startAngle: startAngle, endAngle: endAngle, clockwise: true)
        UIColor(white: 1, alpha: 0.12).setStroke()
        bgArc.lineWidth = 10
        bgArc.lineCapStyle = .round
        bgArc.stroke()

        // Green target zone (+/- 5 cents ~ +/- 4.5 deg around -90 deg)
        let greenDelta = CGFloat.pi * 0.045
        let greenArc = UIBezierPath(
            arcCenter: center,
            radius: radius,
            startAngle: -CGFloat.pi / 2.0 - greenDelta,
            endAngle: -CGFloat.pi / 2.0 + greenDelta,
            clockwise: true
        )
        AtrilColors.green.withAlphaComponent(isInTune ? 1.0 : 0.72).setStroke()
        greenArc.lineWidth = 10
        greenArc.lineCapStyle = .round
        greenArc.stroke()

        // Scale labels: -50, -25, 0, +25, +50
        let labels: [(text: String, frac: CGFloat, color: UIColor)] = [
            ("−50", -1.0, AtrilColors.textMuted),
            ("−25", -0.5, AtrilColors.textMuted),
            ("0", 0.0, AtrilColors.green),
            ("+25", 0.5, AtrilColors.textMuted),
            ("+50", 1.0, AtrilColors.textMuted)
        ]

        for item in labels {
            let angle = -CGFloat.pi / 2.0 + item.frac * (CGFloat.pi / 4.0)
            let labelRadius = radius + 22
            let lx = center.x + cos(angle) * labelRadius
            let ly = center.y + sin(angle) * labelRadius
            let attrs: [NSAttributedString.Key: Any] = [
                .font: UIFont.monospacedDigitSystemFont(ofSize: item.frac == 0 ? 12 : 11, weight: item.frac == 0 ? .bold : .medium),
                .foregroundColor: item.color
            ]
            let sz = (item.text as NSString).size(withAttributes: attrs)
            (item.text as NSString).draw(at: CGPoint(x: lx - sz.width / 2, y: ly - sz.height / 2), withAttributes: attrs)
        }

        // Needle
        let clampedCents = isDetected ? max(-50.0, min(50.0, cents)) : 0.0
        let needleAngle = -CGFloat.pi / 2.0 + CGFloat(clampedCents / 50.0) * (CGFloat.pi / 4.0)
        let needleTip = CGPoint(
            x: center.x + cos(needleAngle) * (radius - 6),
            y: center.y + sin(needleAngle) * (radius - 6)
        )
        let needle = UIBezierPath()
        needle.move(to: center)
        needle.addLine(to: needleTip)
        (isInTune ? AtrilColors.green : AtrilColors.textPrimary).setStroke()
        needle.lineWidth = 3.5
        needle.lineCapStyle = .round
        needle.stroke()

        // Pivot cap
        ctx.saveGState()
        let pivotRect = CGRect(x: center.x - 6, y: center.y - 6, width: 12, height: 12)
        let pivot = UIBezierPath(ovalIn: pivotRect)
        AtrilColors.bgPrimary.setFill()
        pivot.fill()
        AtrilColors.textSecondary.setStroke()
        pivot.lineWidth = 2.5
        pivot.stroke()
        ctx.restoreGState()
    }
}
