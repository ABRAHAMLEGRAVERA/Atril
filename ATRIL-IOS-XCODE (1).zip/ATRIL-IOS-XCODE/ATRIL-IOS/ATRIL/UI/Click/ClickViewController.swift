import UIKit

final class ClickViewController: UIViewController, MetronomeObserver {
    var onExitLiveAndStart: (() -> Void)?
    var onGoToNotes: (() -> Void)?
    private var liveMode: Bool = false

    private let scrollView = UIScrollView()
    private let headerSigLabel = UILabel()
    private let goToNotesBtn = UIButton(type: .system)

    // Visual Pulse Beacon
    private let pulseRingContainer = UIView()
    private let coreDot = UIView()
    private let beatStatusLabel = UILabel()

    // Giant BPM & Accent Pads
    private let bpmValueLabel = UILabel()
    private let bpmMarkingLabel = UILabel()
    private let padsGridStack = UIStackView()
    private var padButtons: [UIButton] = []

    // Controls Card
    private let bpmSlider = UISlider()
    private let sigControl = UISegmentedControl(items: ["4/4", "3/4", "6/8"])
    private var subdivisionButtons: [(RhythmicSubdivision, UIButton, SubdivisionIconView, UILabel)] = []
    private let tapButton = UIButton(type: .system)
    private let startStopButton = UIButton(type: .system)
    private let hintLabel = UILabel()

    private let adaptiveGrid = UIStackView()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = AtrilColors.bgPrimary
        setupUI()
        MetronomeAudioEngine.shared.addObserver(self)
        syncUI()
    }

    deinit {
        MetronomeAudioEngine.shared.removeObserver(self)
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        let isWide = view.bounds.width >= 820
        adaptiveGrid.axis = isWide ? .horizontal : .vertical
        adaptiveGrid.alignment = isWide ? .center : .fill
        adaptiveGrid.distribution = isWide ? .fillEqually : .fill
        adaptiveGrid.spacing = isWide ? 36 : 24
    }

    func setLiveMode(_ live: Bool) {
        liveMode = live
        if isViewLoaded {
            syncUI()
        }
    }

    private func setupUI() {
        // Header
        let header = UIView()
        header.backgroundColor = AtrilColors.bgPrimary
        header.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(header)

        let headerSep = UIView()
        headerSep.backgroundColor = UIColor(white: 1, alpha: 0.06)
        headerSep.translatesAutoresizingMaskIntoConstraints = false
        header.addSubview(headerSep)

        let titleLbl = UILabel()
        titleLbl.text = "Metrónomo · Click"
        titleLbl.font = .systemFont(ofSize: 17, weight: .semibold)
        titleLbl.textColor = AtrilColors.textPrimary
        titleLbl.translatesAutoresizingMaskIntoConstraints = false
        header.addSubview(titleLbl)

        headerSigLabel.font = .monospacedDigitSystemFont(ofSize: 12.5, weight: .medium)
        headerSigLabel.textColor = AtrilColors.textSecondary

        let bookCfg = UIImage.SymbolConfiguration(pointSize: 13, weight: .semibold)
        goToNotesBtn.setImage(UIImage(systemName: "book.fill", withConfiguration: bookCfg), for: .normal)
        goToNotesBtn.setTitle(" Ir a Notas", for: .normal)
        goToNotesBtn.tintColor = AtrilColors.gold
        goToNotesBtn.setTitleColor(AtrilColors.textPrimary, for: .normal)
        goToNotesBtn.titleLabel?.font = .systemFont(ofSize: 12.5, weight: .semibold)
        goToNotesBtn.backgroundColor = UIColor(hex: 0x242429)
        goToNotesBtn.layer.cornerRadius = 11
        goToNotesBtn.layer.borderWidth = 1
        goToNotesBtn.layer.borderColor = AtrilColors.borderSubtle.cgColor
        goToNotesBtn.contentEdgeInsets = UIEdgeInsets(top: 8, left: 12, bottom: 8, right: 12)
        goToNotesBtn.addTarget(self, action: #selector(handleGoToNotesTap), for: .touchUpInside)

        let headerRight = UIStackView(arrangedSubviews: [headerSigLabel, goToNotesBtn])
        headerRight.axis = .horizontal
        headerRight.alignment = .center
        headerRight.spacing = 12
        headerRight.translatesAutoresizingMaskIntoConstraints = false
        header.addSubview(headerRight)

        scrollView.alwaysBounceVertical = true
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scrollView)

        let guide = view.safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            header.topAnchor.constraint(equalTo: guide.topAnchor),
            header.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            header.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            header.heightAnchor.constraint(equalToConstant: 56),

            headerSep.leadingAnchor.constraint(equalTo: header.leadingAnchor),
            headerSep.trailingAnchor.constraint(equalTo: header.trailingAnchor),
            headerSep.bottomAnchor.constraint(equalTo: header.bottomAnchor),
            headerSep.heightAnchor.constraint(equalToConstant: 1),

            titleLbl.leadingAnchor.constraint(equalTo: header.leadingAnchor, constant: 20),
            titleLbl.centerYAnchor.constraint(equalTo: header.centerYAnchor),

            headerRight.trailingAnchor.constraint(equalTo: header.trailingAnchor, constant: -20),
            headerRight.centerYAnchor.constraint(equalTo: header.centerYAnchor),

            scrollView.topAnchor.constraint(equalTo: header.bottomAnchor),
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            scrollView.bottomAnchor.constraint(equalTo: guide.bottomAnchor)
        ])

        // Left Column: Visual Pulse Beacon + BPM Readout + Accent Pads
        let leftCol = UIStackView()
        leftCol.axis = .vertical
        leftCol.alignment = .center
        leftCol.spacing = 22

        pulseRingContainer.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            pulseRingContainer.widthAnchor.constraint(equalToConstant: 44),
            pulseRingContainer.heightAnchor.constraint(equalToConstant: 44)
        ])

        coreDot.layer.cornerRadius = 10
        coreDot.layer.borderWidth = 1
        coreDot.translatesAutoresizingMaskIntoConstraints = false
        pulseRingContainer.addSubview(coreDot)
        NSLayoutConstraint.activate([
            coreDot.centerXAnchor.constraint(equalTo: pulseRingContainer.centerXAnchor),
            coreDot.centerYAnchor.constraint(equalTo: pulseRingContainer.centerYAnchor),
            coreDot.widthAnchor.constraint(equalToConstant: 20),
            coreDot.heightAnchor.constraint(equalToConstant: 20)
        ])

        beatStatusLabel.font = .monospacedDigitSystemFont(ofSize: 13, weight: .medium)
        beatStatusLabel.textColor = AtrilColors.textSecondary
        beatStatusLabel.translatesAutoresizingMaskIntoConstraints = false
        beatStatusLabel.widthAnchor.constraint(greaterThanOrEqualToConstant: 82).isActive = true

        let pulseRow = UIStackView(arrangedSubviews: [pulseRingContainer, beatStatusLabel])
        pulseRow.axis = .horizontal
        pulseRow.alignment = .center
        pulseRow.spacing = 10
        leftCol.addArrangedSubview(pulseRow)

        bpmValueLabel.font = .monospacedDigitSystemFont(ofSize: 72, weight: .bold)
        bpmValueLabel.textColor = AtrilColors.textPrimary
        bpmValueLabel.textAlignment = .center

        bpmMarkingLabel.font = .systemFont(ofSize: 14, weight: .medium)
        bpmMarkingLabel.textColor = AtrilColors.textSecondary
        bpmMarkingLabel.textAlignment = .center

        let bpmStack = UIStackView(arrangedSubviews: [bpmValueLabel, bpmMarkingLabel])
        bpmStack.axis = .vertical
        bpmStack.spacing = 4
        leftCol.addArrangedSubview(bpmStack)

        padsGridStack.axis = .horizontal
        padsGridStack.distribution = .fillEqually
        padsGridStack.spacing = 8
        padsGridStack.translatesAutoresizingMaskIntoConstraints = false

        let padsHint = UILabel()
        padsHint.text = "Toca un tiempo para cambiar acento (▲ fuerte · • normal · × mudo)"
        padsHint.font = .systemFont(ofSize: 11.5)
        padsHint.textColor = AtrilColors.textMuted
        padsHint.textAlignment = .center
        padsHint.numberOfLines = 0

        let padsBox = UIStackView(arrangedSubviews: [padsGridStack, padsHint])
        padsBox.axis = .vertical
        padsBox.spacing = 10
        padsBox.translatesAutoresizingMaskIntoConstraints = false
        leftCol.addArrangedSubview(padsBox)
        NSLayoutConstraint.activate([
            padsGridStack.widthAnchor.constraint(lessThanOrEqualToConstant: 420),
            padsBox.widthAnchor.constraint(equalTo: leftCol.widthAnchor, multiplier: 0.96)
        ])

        // Right Column: Control Card + Tap Tempo + Start/Stop
        let rightCol = UIStackView()
        rightCol.axis = .vertical
        rightCol.spacing = 14

        let card = UIView()
        card.backgroundColor = AtrilColors.card
        card.layer.cornerRadius = 18
        card.layer.borderWidth = 1
        card.layer.borderColor = AtrilColors.borderSubtle.cgColor
        card.translatesAutoresizingMaskIntoConstraints = false

        let minus5 = makeStepBtn("−5", delta: -5)
        let minus1 = makeStepBtn("−1", delta: -1)
        let plus1 = makeStepBtn("+1", delta: 1)
        let plus5 = makeStepBtn("+5", delta: 5)

        bpmSlider.minimumValue = Float(MusicStudioMath.bpmMin)
        bpmSlider.maximumValue = Float(MusicStudioMath.bpmMax)
        bpmSlider.minimumTrackTintColor = AtrilColors.gold
        bpmSlider.maximumTrackTintColor = UIColor(hex: 0x2C2C34)
        bpmSlider.thumbTintColor = AtrilColors.gold
        bpmSlider.addTarget(self, action: #selector(handleSliderChanged), for: .valueChanged)

        let sliderRow = UIStackView(arrangedSubviews: [minus5, minus1, bpmSlider, plus1, plus5])
        sliderRow.axis = .horizontal
        sliderRow.alignment = .center
        sliderRow.spacing = 8

        sigControl.backgroundColor = AtrilColors.bgPrimary
        sigControl.selectedSegmentTintColor = UIColor(hex: 0x2C2C34)
        sigControl.setTitleTextAttributes([
            .foregroundColor: AtrilColors.textSecondary,
            .font: UIFont.monospacedDigitSystemFont(ofSize: 13, weight: .semibold)
        ], for: .normal)
        sigControl.setTitleTextAttributes([
            .foregroundColor: AtrilColors.textPrimary,
            .font: UIFont.monospacedDigitSystemFont(ofSize: 13, weight: .semibold)
        ], for: .selected)
        sigControl.addTarget(self, action: #selector(handleSigChanged), for: .valueChanged)
        sigControl.heightAnchor.constraint(equalToConstant: 40).isActive = true

        let subHeader = UILabel()
        subHeader.text = "Subdivisión"
        subHeader.font = .systemFont(ofSize: 11.5, weight: .medium)
        subHeader.textColor = AtrilColors.textSecondary

        let subContainer = UIView()
        subContainer.backgroundColor = AtrilColors.bgPrimary
        subContainer.layer.cornerRadius = 12
        subContainer.layer.borderWidth = 1
        subContainer.layer.borderColor = AtrilColors.borderSubtle.cgColor

        let subStack = UIStackView()
        subStack.axis = .horizontal
        subStack.distribution = .fillEqually
        subStack.spacing = 6
        subStack.translatesAutoresizingMaskIntoConstraints = false
        subContainer.addSubview(subStack)
        NSLayoutConstraint.activate([
            subStack.topAnchor.constraint(equalTo: subContainer.topAnchor, constant: 4),
            subStack.bottomAnchor.constraint(equalTo: subContainer.bottomAnchor, constant: -4),
            subStack.leadingAnchor.constraint(equalTo: subContainer.leadingAnchor, constant: 4),
            subStack.trailingAnchor.constraint(equalTo: subContainer.trailingAnchor, constant: -4)
        ])

        for sub in RhythmicSubdivision.allCases {
            let btn = UIButton(type: .system)
            btn.layer.cornerRadius = 9
            btn.heightAnchor.constraint(equalToConstant: 40).isActive = true
            btn.addTarget(self, action: #selector(handleSubdivisionTap(_:)), for: .touchUpInside)

            let icon = SubdivisionIconView(kind: sub)
            icon.isUserInteractionEnabled = false
            icon.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                icon.widthAnchor.constraint(equalToConstant: 18),
                icon.heightAnchor.constraint(equalToConstant: 16)
            ])

            let lbl = UILabel()
            lbl.text = sub.displayLabel
            lbl.font = .systemFont(ofSize: 12.5, weight: .semibold)
            lbl.isUserInteractionEnabled = false

            let h = UIStackView(arrangedSubviews: [icon, lbl])
            h.axis = .horizontal
            h.alignment = .center
            h.spacing = 6
            h.isUserInteractionEnabled = false
            h.translatesAutoresizingMaskIntoConstraints = false
            btn.addSubview(h)
            NSLayoutConstraint.activate([
                h.centerXAnchor.constraint(equalTo: btn.centerXAnchor),
                h.centerYAnchor.constraint(equalTo: btn.centerYAnchor)
            ])

            subStack.addArrangedSubview(btn)
            subdivisionButtons.append((sub, btn, icon, lbl))
        }

        let cardInner = UIStackView(arrangedSubviews: [sliderRow, sigControl, subHeader, subContainer])
        cardInner.axis = .vertical
        cardInner.spacing = 12
        cardInner.setCustomSpacing(6, after: subHeader)
        cardInner.translatesAutoresizingMaskIntoConstraints = false
        card.addSubview(cardInner)
        NSLayoutConstraint.activate([
            cardInner.topAnchor.constraint(equalTo: card.topAnchor, constant: 16),
            cardInner.bottomAnchor.constraint(equalTo: card.bottomAnchor, constant: -16),
            cardInner.leadingAnchor.constraint(equalTo: card.leadingAnchor, constant: 16),
            cardInner.trailingAnchor.constraint(equalTo: card.trailingAnchor, constant: -16)
        ])

        let tapCfg = UIImage.SymbolConfiguration(pointSize: 15, weight: .semibold)
        tapButton.setImage(UIImage(systemName: "hand.tap.fill", withConfiguration: tapCfg), for: .normal)
        tapButton.setTitle(" TAP TEMPO", for: .normal)
        tapButton.tintColor = AtrilColors.gold
        tapButton.setTitleColor(AtrilColors.textPrimary, for: .normal)
        tapButton.titleLabel?.font = .systemFont(ofSize: 14.5, weight: .semibold)
        tapButton.backgroundColor = AtrilColors.card
        tapButton.layer.cornerRadius = 16
        tapButton.layer.borderWidth = 1
        tapButton.layer.borderColor = AtrilColors.borderSubtle.cgColor
        tapButton.heightAnchor.constraint(equalToConstant: 52).isActive = true
        tapButton.addTarget(self, action: #selector(handleTapTempo), for: .touchUpInside)

        startStopButton.layer.cornerRadius = 16
        startStopButton.titleLabel?.font = .systemFont(ofSize: 15, weight: .semibold)
        startStopButton.heightAnchor.constraint(equalToConstant: 54).isActive = true
        startStopButton.addTarget(self, action: #selector(handleStartStopTap), for: .touchUpInside)

        hintLabel.font = .systemFont(ofSize: 12.5)
        hintLabel.textColor = AtrilColors.textSecondary
        hintLabel.textAlignment = .center
        hintLabel.numberOfLines = 0

        rightCol.addArrangedSubview(card)
        rightCol.addArrangedSubview(tapButton)
        rightCol.addArrangedSubview(startStopButton)
        rightCol.addArrangedSubview(hintLabel)

        adaptiveGrid.addArrangedSubview(leftCol)
        adaptiveGrid.addArrangedSubview(rightCol)
        adaptiveGrid.translatesAutoresizingMaskIntoConstraints = false

        let holder = UIView()
        holder.translatesAutoresizingMaskIntoConstraints = false
        scrollView.addSubview(holder)
        holder.addSubview(adaptiveGrid)

        let maxW = adaptiveGrid.widthAnchor.constraint(lessThanOrEqualToConstant: 920)
        maxW.priority = .required
        let fillW = adaptiveGrid.widthAnchor.constraint(equalTo: holder.widthAnchor, constant: -40)
        fillW.priority = .defaultHigh

        NSLayoutConstraint.activate([
            holder.topAnchor.constraint(equalTo: scrollView.contentLayoutGuide.topAnchor),
            holder.bottomAnchor.constraint(equalTo: scrollView.contentLayoutGuide.bottomAnchor),
            holder.leadingAnchor.constraint(equalTo: scrollView.contentLayoutGuide.leadingAnchor),
            holder.trailingAnchor.constraint(equalTo: scrollView.contentLayoutGuide.trailingAnchor),
            holder.widthAnchor.constraint(equalTo: scrollView.frameLayoutGuide.widthAnchor),
            holder.heightAnchor.constraint(greaterThanOrEqualTo: scrollView.frameLayoutGuide.heightAnchor),

            adaptiveGrid.centerXAnchor.constraint(equalTo: holder.centerXAnchor),
            adaptiveGrid.centerYAnchor.constraint(equalTo: holder.centerYAnchor),
            adaptiveGrid.topAnchor.constraint(greaterThanOrEqualTo: holder.topAnchor, constant: 24),
            adaptiveGrid.bottomAnchor.constraint(lessThanOrEqualTo: holder.bottomAnchor, constant: -24),
            maxW,
            fillW
        ])
    }

    private func makeStepBtn(_ title: String, delta: Int) -> UIButton {
        let btn = UIButton(type: .system)
        btn.setTitle(title, for: .normal)
        btn.setTitleColor(AtrilColors.textPrimary, for: .normal)
        btn.titleLabel?.font = .monospacedDigitSystemFont(ofSize: 13, weight: .semibold)
        btn.backgroundColor = AtrilColors.controlSurface
        btn.layer.cornerRadius = 11
        btn.layer.borderWidth = 1
        btn.layer.borderColor = AtrilColors.borderSubtle.cgColor
        btn.tag = delta
        btn.addTarget(self, action: #selector(handleStepBtnTap(_:)), for: .touchUpInside)
        btn.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            btn.widthAnchor.constraint(equalToConstant: 44),
            btn.heightAnchor.constraint(equalToConstant: 44)
        ])
        return btn
    }

    private func syncUI() {
        let engine = MetronomeAudioEngine.shared
        let marking = MusicStudioMath.tempoMarking(for: engine.bpm)

        headerSigLabel.text = "\(engine.timeSignature.rawValue) · \(marking)"
        bpmValueLabel.text = "\(engine.bpm)"
        bpmMarkingLabel.text = "BPM · \(marking)"

        if !bpmSlider.isTracking {
            bpmSlider.value = Float(engine.bpm)
        }

        if let sigIdx = TimeSignature.allCases.firstIndex(of: engine.timeSignature) {
            sigControl.selectedSegmentIndex = sigIdx
        }

        for (sub, btn, icon, lbl) in subdivisionButtons {
            let active = (sub == engine.subdivision)
            btn.backgroundColor = active ? UIColor(hex: 0x2C2C34) : .clear
            lbl.textColor = active ? AtrilColors.textPrimary : UIColor(hex: 0x8E8E93)
            icon.tintColor = active ? AtrilColors.gold : UIColor(hex: 0x8E8E93)
            icon.setNeedsDisplay()
        }

        // Beat Status & Core Dot
        if engine.isRunning, let beat = engine.currentBeat {
            beatStatusLabel.text = "Tiempo \(beat + 1)/\(engine.accents.count)"
            let accent = engine.accents[beat]
            if beat == 0 {
                coreDot.backgroundColor = AtrilColors.gold
            } else if accent == .mute {
                coreDot.backgroundColor = UIColor(white: 1, alpha: 0.25)
            } else {
                coreDot.backgroundColor = AtrilColors.textPrimary
            }
            coreDot.layer.borderColor = UIColor.clear.cgColor
        } else {
            beatStatusLabel.text = "En espera"
            coreDot.backgroundColor = UIColor(white: 1, alpha: 0.14)
            coreDot.layer.borderColor = UIColor(white: 1, alpha: 0.22).cgColor
        }

        rebuildOrUpdatePads(accents: engine.accents, currentBeat: engine.currentBeat, isRunning: engine.isRunning)

        let playCfg = UIImage.SymbolConfiguration(pointSize: 14, weight: .bold)
        if engine.isRunning {
            startStopButton.backgroundColor = AtrilColors.red
            startStopButton.setTitle(" Detener click", for: .normal)
            startStopButton.setTitleColor(.white, for: .normal)
            startStopButton.tintColor = .white
            startStopButton.setImage(UIImage(systemName: "pause.fill", withConfiguration: playCfg), for: .normal)
        } else {
            startStopButton.backgroundColor = AtrilColors.gold
            startStopButton.setTitle(" Iniciar click", for: .normal)
            startStopButton.setTitleColor(AtrilColors.bgPrimary, for: .normal)
            startStopButton.tintColor = AtrilColors.bgPrimary
            startStopButton.setImage(UIImage(systemName: "play.fill", withConfiguration: playCfg), for: .normal)
        }

        hintLabel.text = liveMode
            ? "Modo en vivo activo: al iniciar el click se activará el modo Estudio para practicar con tus partituras."
            : "El click sigue sonando al pasar a Notas o abrir tus partituras para estudiar."
    }

    private func rebuildOrUpdatePads(accents: [BeatAccent], currentBeat: Int?, isRunning: Bool) {
        if padButtons.count != accents.count {
            padButtons.forEach { $0.removeFromSuperview() }
            padButtons.removeAll()
            for i in 0..<accents.count {
                let btn = UIButton(type: .system)
                btn.tag = i
                btn.layer.cornerRadius = 12
                btn.layer.borderWidth = 1
                btn.titleLabel?.numberOfLines = 2
                btn.titleLabel?.textAlignment = .center
                btn.heightAnchor.constraint(equalToConstant: 58).isActive = true
                btn.addTarget(self, action: #selector(handlePadTap(_:)), for: .touchUpInside)
                padsGridStack.addArrangedSubview(btn)
                padButtons.append(btn)
            }
        }

        for (idx, accent) in accents.enumerated() {
            let btn = padButtons[idx]
            let isActive = isRunning && currentBeat == idx
            let symbol = accent == .strong ? "▲" : (accent == .mute ? "×" : "•")

            let topColor: UIColor
            let symbolColor: UIColor
            if isActive && accent == .strong {
                btn.backgroundColor = AtrilColors.gold
                btn.layer.borderColor = AtrilColors.gold.cgColor
                topColor = AtrilColors.bgPrimary
                symbolColor = AtrilColors.bgPrimary
            } else if isActive && accent == .mute {
                btn.backgroundColor = UIColor(hex: 0x2C2C32)
                btn.layer.borderColor = UIColor(white: 1, alpha: 0.25).cgColor
                topColor = AtrilColors.textSecondary
                symbolColor = AtrilColors.textSecondary
            } else if isActive {
                btn.backgroundColor = AtrilColors.gold.withAlphaComponent(0.25)
                btn.layer.borderColor = AtrilColors.gold.withAlphaComponent(0.75).cgColor
                topColor = AtrilColors.textPrimary
                symbolColor = AtrilColors.textPrimary
            } else if accent == .strong {
                btn.backgroundColor = UIColor(hex: 0x222228)
                btn.layer.borderColor = AtrilColors.gold.withAlphaComponent(0.45).cgColor
                topColor = AtrilColors.textPrimary
                symbolColor = AtrilColors.gold
            } else if accent == .mute {
                btn.backgroundColor = UIColor(hex: 0x1A1A1F)
                btn.layer.borderColor = UIColor(white: 1, alpha: 0.06).cgColor
                topColor = UIColor(hex: 0x6E6E75)
                symbolColor = UIColor(hex: 0x6E6E75)
            } else {
                btn.backgroundColor = UIColor(hex: 0x202025)
                btn.layer.borderColor = AtrilColors.borderSubtle.cgColor
                topColor = UIColor(hex: 0xD1D1D6)
                symbolColor = UIColor(hex: 0xD1D1D6)
            }

            let attr = NSMutableAttributedString(
                string: "\(idx + 1)\n",
                attributes: [.font: UIFont.monospacedDigitSystemFont(ofSize: 14, weight: .bold), .foregroundColor: topColor]
            )
            attr.append(NSAttributedString(
                string: symbol,
                attributes: [.font: UIFont.systemFont(ofSize: 12, weight: .semibold), .foregroundColor: symbolColor]
            ))
            btn.setAttributedTitle(attr, for: .normal)
        }
    }

    private func triggerPulseFlash(beatIndex: Int) {
        let engine = MetronomeAudioEngine.shared
        let accent = beatIndex < engine.accents.count ? engine.accents[beatIndex] : .normal

        let ring = CAShapeLayer()
        let bounds = pulseRingContainer.bounds
        ring.frame = bounds
        ring.path = UIBezierPath(ovalIn: bounds.insetBy(dx: 10, dy: 10)).cgPath
        if beatIndex == 0 {
            ring.fillColor = AtrilColors.gold.withAlphaComponent(0.42).cgColor
            ring.strokeColor = AtrilColors.gold.cgColor
        } else if accent == .mute {
            ring.fillColor = UIColor(white: 1, alpha: 0.1).cgColor
            ring.strokeColor = UIColor(white: 1, alpha: 0.25).cgColor
        } else {
            ring.fillColor = UIColor(white: 1, alpha: 0.28).cgColor
            ring.strokeColor = UIColor(white: 1, alpha: 0.6).cgColor
        }
        ring.lineWidth = 1.5
        pulseRingContainer.layer.insertSublayer(ring, below: coreDot.layer)

        let scaleAnim = CABasicAnimation(keyPath: "transform.scale")
        scaleAnim.fromValue = 1.0
        scaleAnim.toValue = 1.85

        let fadeAnim = CABasicAnimation(keyPath: "opacity")
        fadeAnim.fromValue = 1.0
        fadeAnim.toValue = 0.0

        let group = CAAnimationGroup()
        group.animations = [scaleAnim, fadeAnim]
        group.duration = 0.26
        group.timingFunction = CAMediaTimingFunction(name: .easeOut)
        group.fillMode = .forwards
        group.isRemovedOnCompletion = false
        CATransaction.begin()
        CATransaction.setCompletionBlock {
            ring.removeFromSuperlayer()
        }
        ring.add(group, forKey: "flash")
        CATransaction.commit()
    }

    // MARK: - Actions

    @objc private func handleGoToNotesTap() {
        onGoToNotes?()
    }

    @objc private func handleStepBtnTap(_ sender: UIButton) {
        MetronomeAudioEngine.shared.adjustBpm(sender.tag)
    }

    @objc private func handleSliderChanged() {
        MetronomeAudioEngine.shared.setBpm(Int(bpmSlider.value.rounded()))
    }

    @objc private func handleSigChanged() {
        let idx = sigControl.selectedSegmentIndex
        guard idx >= 0 && idx < TimeSignature.allCases.count else { return }
        MetronomeAudioEngine.shared.setTimeSignature(TimeSignature.allCases[idx])
    }

    @objc private func handleSubdivisionTap(_ sender: UIButton) {
        if let match = subdivisionButtons.first(where: { $0.1 === sender }) {
            MetronomeAudioEngine.shared.setSubdivision(match.0)
        }
    }

    @objc private func handlePadTap(_ sender: UIButton) {
        MetronomeAudioEngine.shared.cycleAccent(at: sender.tag)
    }

    @objc private func handleTapTempo() {
        MetronomeAudioEngine.shared.tapTempo()
    }

    @objc private func handleStartStopTap() {
        let engine = MetronomeAudioEngine.shared
        if engine.isRunning {
            engine.stop()
        } else {
            onExitLiveAndStart?()
        }
    }

    // MARK: - MetronomeObserver

    func metronomeDidUpdateState(_ engine: MetronomeAudioEngine) {
        syncUI()
    }

    func metronomeDidTickBeat(_ engine: MetronomeAudioEngine, beatIndex: Int, beatTick: Int) {
        syncUI()
        triggerPulseFlash(beatIndex: beatIndex)
    }
}

/// Core Graphics musical note symbol for Quarter / Eighth / Triplet subdivision tabs.
private final class SubdivisionIconView: UIView {
    let kind: RhythmicSubdivision

    init(kind: RhythmicSubdivision) {
        self.kind = kind
        super.init(frame: .zero)
        backgroundColor = .clear
        isOpaque = false
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func draw(_ rect: CGRect) {
        let color = tintColor ?? AtrilColors.textSecondary
        color.setFill()
        color.setStroke()

        let sx = rect.width / 20.0
        let sy = rect.height / 16.0
        guard let ctx = UIGraphicsGetCurrentContext() else { return }
        ctx.saveGState()
        ctx.scaleBy(x: sx, y: sy)

        switch kind {
        case .quarter:
            drawNoteHead(cx: 8.5, cy: 11.5, rx: 3.1, ry: 2.2)
            UIBezierPath(roundedRect: CGRect(x: 10.4, y: 2.5, width: 1.6, height: 9), cornerRadius: 0.8).fill()
        case .eighth:
            drawNoteHead(cx: 5.5, cy: 12, rx: 2.5, ry: 1.8)
            drawNoteHead(cx: 14.0, cy: 12, rx: 2.5, ry: 1.8)
            UIBezierPath(rect: CGRect(x: 7.0, y: 3, width: 1.4, height: 9)).fill()
            UIBezierPath(rect: CGRect(x: 15.5, y: 3, width: 1.4, height: 9)).fill()
            UIBezierPath(roundedRect: CGRect(x: 7.0, y: 2.5, width: 9.9, height: 2.1), cornerRadius: 0.6).fill()
        case .triplet:
            let attrs: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 6.2, weight: .bold),
                .foregroundColor: color
            ]
            ("3" as NSString).draw(at: CGPoint(x: 8.2, y: -0.5), withAttributes: attrs)
            drawNoteHead(cx: 3.8, cy: 13.5, rx: 2.1, ry: 1.6)
            drawNoteHead(cx: 10.0, cy: 13.5, rx: 2.1, ry: 1.6)
            drawNoteHead(cx: 16.2, cy: 13.5, rx: 2.1, ry: 1.6)
            UIBezierPath(rect: CGRect(x: 5.0, y: 6.5, width: 1.3, height: 7)).fill()
            UIBezierPath(rect: CGRect(x: 11.2, y: 6.5, width: 1.3, height: 7)).fill()
            UIBezierPath(rect: CGRect(x: 17.4, y: 6.5, width: 1.3, height: 7)).fill()
            UIBezierPath(roundedRect: CGRect(x: 5.0, y: 6.0, width: 13.7, height: 1.8), cornerRadius: 0.5).fill()
        }

        ctx.restoreGState()
    }

    private func drawNoteHead(cx: CGFloat, cy: CGFloat, rx: CGFloat, ry: CGFloat) {
        let p = UIBezierPath(ovalIn: CGRect(x: cx - rx, y: cy - ry, width: rx * 2, height: ry * 2))
        p.fill()
    }
}
