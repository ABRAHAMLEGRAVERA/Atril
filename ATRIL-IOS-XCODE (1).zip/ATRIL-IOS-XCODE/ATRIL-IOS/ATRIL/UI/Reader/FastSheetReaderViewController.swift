import PDFKit
import UIKit

/// Zero-lag borderless fullscreen sheet reader powered natively by PDFKit + UIPageViewController
/// with pinch-to-zoom, 4-slide memory-bounded cache for iPad Air 2, and discreet Study Click capsule.
final class FastSheetReaderViewController: UIViewController,
    UIPageViewControllerDataSource,
    UIPageViewControllerDelegate,
    MetronomeObserver {

    private let slides: [ReaderSlide]
    private var currentIndex: Int
    private let liveMode: Bool
    private var studyControlsExpanded = false

    private var pageViewController: UIPageViewController!
    private let closeButton = UIButton(type: .system)
    private let prevArrowButton = UIButton(type: .system)
    private let nextArrowButton = UIButton(type: .system)
    private let pageBadgeLabel = UILabel()

    // Floating top-left study click controls
    private let studyContainer = UIStackView()
    private let collapsedGaugeButton = UIButton(type: .system)
    private let expandedPill = UIView()
    private let pillPlayButton = UIButton(type: .system)
    private let pillBpmLabel = UILabel()
    private let pillMinusBtn = UIButton(type: .system)
    private let pillPlusBtn = UIButton(type: .system)
    private let pillCloseBtn = UIButton(type: .system)
    private let dotsPill = UIView()
    private let visualDots = VisualBeatDotsView(size: .sm)

    init(note: Note, initialAttachmentId: String?, initialPageNumber: Int?, liveMode: Bool) {
        self.slides = NoteLogic.buildNoteSlides(note)
        self.currentIndex = NoteLogic.resolveReaderSlideIndex(
            slides: self.slides,
            attachmentId: initialAttachmentId,
            pageNumber: initialPageNumber
        )
        self.liveMode = liveMode
        super.init(nibName: nil, bundle: nil)
        modalPresentationStyle = .fullScreen
        modalTransitionStyle = .crossDissolve
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override var prefersStatusBarHidden: Bool { true }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black

        setupPageViewController()
        setupOverlayControls()
        MetronomeAudioEngine.shared.addObserver(self)
        syncUI()
    }

    deinit {
        MetronomeAudioEngine.shared.removeObserver(self)
    }

    private func setupPageViewController() {
        pageViewController = UIPageViewController(transitionStyle: .scroll, navigationOrientation: .horizontal)
        pageViewController.dataSource = self
        pageViewController.delegate = self

        addChild(pageViewController)
        pageViewController.view.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(pageViewController.view)
        pageViewController.didMove(toParent: self)

        NSLayoutConstraint.activate([
            pageViewController.view.topAnchor.constraint(equalTo: view.topAnchor),
            pageViewController.view.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            pageViewController.view.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            pageViewController.view.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])

        if !slides.isEmpty {
            let initialVC = makeSlideVC(at: currentIndex)
            pageViewController.setViewControllers([initialVC], direction: .forward, animated: false)
        }
    }

    private func setupOverlayControls() {
        let guide = view.safeAreaLayoutGuide

        // Top-right close button
        let xCfg = UIImage.SymbolConfiguration(pointSize: 16, weight: .bold)
        closeButton.setImage(UIImage(systemName: "xmark", withConfiguration: xCfg), for: .normal)
        closeButton.tintColor = .white
        closeButton.backgroundColor = UIColor.black.withAlphaComponent(0.65)
        closeButton.layer.cornerRadius = 22
        closeButton.layer.borderWidth = 1
        closeButton.layer.borderColor = UIColor(white: 1, alpha: 0.16).cgColor
        closeButton.accessibilityLabel = "Cerrar lector"
        closeButton.addTarget(self, action: #selector(handleCloseTap), for: .touchUpInside)
        closeButton.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(closeButton)

        // Top-left study click capsule (hidden in liveMode)
        studyContainer.axis = .horizontal
        studyContainer.alignment = .center
        studyContainer.spacing = 6
        studyContainer.isHidden = liveMode
        studyContainer.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(studyContainer)

        let gaugeCfg = UIImage.SymbolConfiguration(pointSize: 16, weight: .semibold)
        collapsedGaugeButton.setImage(UIImage(systemName: "speedometer", withConfiguration: gaugeCfg), for: .normal)
        collapsedGaugeButton.tintColor = UIColor(white: 1, alpha: 0.72)
        collapsedGaugeButton.backgroundColor = UIColor.black.withAlphaComponent(0.55)
        collapsedGaugeButton.layer.cornerRadius = 22
        collapsedGaugeButton.layer.borderWidth = 1
        collapsedGaugeButton.layer.borderColor = UIColor(white: 1, alpha: 0.14).cgColor
        collapsedGaugeButton.accessibilityLabel = "Click de estudio"
        collapsedGaugeButton.addTarget(self, action: #selector(handleExpandStudyTap), for: .touchUpInside)
        collapsedGaugeButton.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            collapsedGaugeButton.widthAnchor.constraint(equalToConstant: 44),
            collapsedGaugeButton.heightAnchor.constraint(equalToConstant: 44)
        ])

        // Expanded study pill
        expandedPill.backgroundColor = UIColor.black.withAlphaComponent(0.78)
        expandedPill.layer.cornerRadius = 21
        expandedPill.layer.borderWidth = 1
        expandedPill.layer.borderColor = UIColor(white: 1, alpha: 0.16).cgColor
        expandedPill.translatesAutoresizingMaskIntoConstraints = false

        pillPlayButton.layer.cornerRadius = 17
        pillPlayButton.addTarget(self, action: #selector(handleToggleClickTap), for: .touchUpInside)
        pillPlayButton.translatesAutoresizingMaskIntoConstraints = false

        pillBpmLabel.font = .monospacedDigitSystemFont(ofSize: 13, weight: .bold)
        pillBpmLabel.textColor = .white
        pillBpmLabel.textAlignment = .center
        pillBpmLabel.translatesAutoresizingMaskIntoConstraints = false
        pillBpmLabel.widthAnchor.constraint(greaterThanOrEqualToConstant: 30).isActive = true

        configureMiniCircleBtn(pillMinusBtn, title: "−", action: #selector(handleMinusTap))
        configureMiniCircleBtn(pillPlusBtn, title: "+", action: #selector(handlePlusTap))

        let smXCfg = UIImage.SymbolConfiguration(pointSize: 12, weight: .bold)
        pillCloseBtn.setImage(UIImage(systemName: "xmark", withConfiguration: smXCfg), for: .normal)
        pillCloseBtn.tintColor = UIColor(white: 1, alpha: 0.75)
        pillCloseBtn.addTarget(self, action: #selector(handleCollapseStudyTap), for: .touchUpInside)
        pillCloseBtn.translatesAutoresizingMaskIntoConstraints = false

        let pillStack = UIStackView(arrangedSubviews: [pillPlayButton, pillBpmLabel, pillMinusBtn, pillPlusBtn, pillCloseBtn])
        pillStack.axis = .horizontal
        pillStack.alignment = .center
        pillStack.spacing = 6
        pillStack.translatesAutoresizingMaskIntoConstraints = false
        expandedPill.addSubview(pillStack)

        NSLayoutConstraint.activate([
            pillPlayButton.widthAnchor.constraint(equalToConstant: 34),
            pillPlayButton.heightAnchor.constraint(equalToConstant: 34),
            pillCloseBtn.widthAnchor.constraint(equalToConstant: 32),
            pillCloseBtn.heightAnchor.constraint(equalToConstant: 32),
            pillStack.topAnchor.constraint(equalTo: expandedPill.topAnchor, constant: 4),
            pillStack.bottomAnchor.constraint(equalTo: expandedPill.bottomAnchor, constant: -4),
            pillStack.leadingAnchor.constraint(equalTo: expandedPill.leadingAnchor, constant: 5),
            pillStack.trailingAnchor.constraint(equalTo: expandedPill.trailingAnchor, constant: -6)
        ])

        dotsPill.backgroundColor = UIColor.black.withAlphaComponent(0.72)
        dotsPill.layer.cornerRadius = 15
        dotsPill.layer.borderWidth = 1
        dotsPill.layer.borderColor = UIColor(white: 1, alpha: 0.16).cgColor
        dotsPill.isUserInteractionEnabled = false
        dotsPill.translatesAutoresizingMaskIntoConstraints = false
        visualDots.translatesAutoresizingMaskIntoConstraints = false
        dotsPill.addSubview(visualDots)
        NSLayoutConstraint.activate([
            visualDots.topAnchor.constraint(equalTo: dotsPill.topAnchor, constant: 8),
            visualDots.bottomAnchor.constraint(equalTo: dotsPill.bottomAnchor, constant: -8),
            visualDots.leadingAnchor.constraint(equalTo: dotsPill.leadingAnchor, constant: 10),
            visualDots.trailingAnchor.constraint(equalTo: dotsPill.trailingAnchor, constant: -10)
        ])

        studyContainer.addArrangedSubview(collapsedGaugeButton)
        studyContainer.addArrangedSubview(expandedPill)
        studyContainer.addArrangedSubview(dotsPill)

        // Left / right soft page arrows + bottom page indicator
        configureArrowButton(prevArrowButton, symbol: "chevron.left", label: "Anterior", action: #selector(goPrev))
        configureArrowButton(nextArrowButton, symbol: "chevron.right", label: "Siguiente", action: #selector(goNext))
        view.addSubview(prevArrowButton)
        view.addSubview(nextArrowButton)

        pageBadgeLabel.backgroundColor = UIColor.black.withAlphaComponent(0.75)
        pageBadgeLabel.textColor = .white
        pageBadgeLabel.font = .monospacedDigitSystemFont(ofSize: 12.5, weight: .semibold)
        pageBadgeLabel.textAlignment = .center
        pageBadgeLabel.layer.cornerRadius = 9
        pageBadgeLabel.clipsToBounds = true
        pageBadgeLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(pageBadgeLabel)

        NSLayoutConstraint.activate([
            closeButton.topAnchor.constraint(equalTo: guide.topAnchor, constant: 12),
            closeButton.trailingAnchor.constraint(equalTo: guide.trailingAnchor, constant: -14),
            closeButton.widthAnchor.constraint(equalToConstant: 44),
            closeButton.heightAnchor.constraint(equalToConstant: 44),

            studyContainer.topAnchor.constraint(equalTo: guide.topAnchor, constant: 12),
            studyContainer.leadingAnchor.constraint(equalTo: guide.leadingAnchor, constant: 14),

            prevArrowButton.leadingAnchor.constraint(equalTo: guide.leadingAnchor, constant: 14),
            prevArrowButton.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            prevArrowButton.widthAnchor.constraint(equalToConstant: 44),
            prevArrowButton.heightAnchor.constraint(equalToConstant: 44),

            nextArrowButton.trailingAnchor.constraint(equalTo: guide.trailingAnchor, constant: -14),
            nextArrowButton.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            nextArrowButton.widthAnchor.constraint(equalToConstant: 44),
            nextArrowButton.heightAnchor.constraint(equalToConstant: 44),

            pageBadgeLabel.bottomAnchor.constraint(equalTo: guide.bottomAnchor, constant: -14),
            pageBadgeLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            pageBadgeLabel.widthAnchor.constraint(greaterThanOrEqualToConstant: 64),
            pageBadgeLabel.heightAnchor.constraint(equalToConstant: 26)
        ])
    }

    private func configureMiniCircleBtn(_ btn: UIButton, title: String, action: Selector) {
        btn.setTitle(title, for: .normal)
        btn.setTitleColor(.white, for: .normal)
        btn.titleLabel?.font = .monospacedDigitSystemFont(ofSize: 14, weight: .semibold)
        btn.backgroundColor = UIColor(white: 1, alpha: 0.12)
        btn.layer.cornerRadius = 17
        btn.addTarget(self, action: action, for: .touchUpInside)
        btn.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            btn.widthAnchor.constraint(equalToConstant: 34),
            btn.heightAnchor.constraint(equalToConstant: 34)
        ])
    }

    private func configureArrowButton(_ btn: UIButton, symbol: String, label: String, action: Selector) {
        let cfg = UIImage.SymbolConfiguration(pointSize: 17, weight: .semibold)
        btn.setImage(UIImage(systemName: symbol, withConfiguration: cfg), for: .normal)
        btn.tintColor = UIColor(white: 1, alpha: 0.88)
        btn.backgroundColor = UIColor.black.withAlphaComponent(0.55)
        btn.layer.cornerRadius = 22
        btn.layer.borderWidth = 1
        btn.layer.borderColor = UIColor(white: 1, alpha: 0.15).cgColor
        btn.accessibilityLabel = label
        btn.addTarget(self, action: action, for: .touchUpInside)
        btn.translatesAutoresizingMaskIntoConstraints = false
    }

    private func makeSlideVC(at index: Int) -> ReaderSlidePageViewController {
        return ReaderSlidePageViewController(slide: slides[index], index: index)
    }

    private func syncUI() {
        let total = slides.count
        let multi = total > 1
        prevArrowButton.isHidden = !multi || currentIndex <= 0
        nextArrowButton.isHidden = !multi || currentIndex >= total - 1
        pageBadgeLabel.isHidden = !multi
        pageBadgeLabel.text = "  \(currentIndex + 1) / \(total)  "

        let engine = MetronomeAudioEngine.shared
        let expanded = engine.isRunning || studyControlsExpanded
        collapsedGaugeButton.isHidden = expanded
        expandedPill.isHidden = !expanded
        dotsPill.isHidden = !expanded
        pillCloseBtn.isHidden = engine.isRunning

        pillBpmLabel.text = "\(engine.bpm)"
        let iconCfg = UIImage.SymbolConfiguration(pointSize: 12, weight: .bold)
        if engine.isRunning {
            pillPlayButton.backgroundColor = AtrilColors.red
            pillPlayButton.tintColor = .white
            pillPlayButton.setImage(UIImage(systemName: "pause.fill", withConfiguration: iconCfg), for: .normal)
        } else {
            pillPlayButton.backgroundColor = AtrilColors.gold
            pillPlayButton.tintColor = AtrilColors.bgPrimary
            pillPlayButton.setImage(UIImage(systemName: "play.fill", withConfiguration: iconCfg), for: .normal)
        }
        visualDots.update(accents: engine.accents, currentBeat: engine.currentBeat, isRunning: engine.isRunning)
    }

    // MARK: - Actions & Hardware Keyboard

    @objc private func handleCloseTap() {
        dismiss(animated: true)
    }

    @objc private func handleExpandStudyTap() {
        studyControlsExpanded = true
        MetronomeAudioEngine.shared.start()
        syncUI()
    }

    @objc private func handleCollapseStudyTap() {
        studyControlsExpanded = false
        syncUI()
    }

    @objc private func handleToggleClickTap() {
        MetronomeAudioEngine.shared.toggle()
    }

    @objc private func handleMinusTap() {
        MetronomeAudioEngine.shared.adjustBpm(-1)
    }

    @objc private func handlePlusTap() {
        MetronomeAudioEngine.shared.adjustBpm(1)
    }

    @objc private func goPrev() {
        guard currentIndex > 0 else { return }
        currentIndex -= 1
        let vc = makeSlideVC(at: currentIndex)
        pageViewController.setViewControllers([vc], direction: .reverse, animated: true)
        syncUI()
    }

    @objc private func goNext() {
        guard currentIndex < slides.count - 1 else { return }
        currentIndex += 1
        let vc = makeSlideVC(at: currentIndex)
        pageViewController.setViewControllers([vc], direction: .forward, animated: true)
        syncUI()
    }

    override var keyCommands: [UIKeyCommand]? {
        return [
            UIKeyCommand(input: UIKeyCommand.inputRightArrow, modifierFlags: [], action: #selector(goNext)),
            UIKeyCommand(input: UIKeyCommand.inputLeftArrow, modifierFlags: [], action: #selector(goPrev)),
            UIKeyCommand(input: " ", modifierFlags: [], action: #selector(goNext)),
            UIKeyCommand(input: UIKeyCommand.inputEscape, modifierFlags: [], action: #selector(handleCloseTap))
        ]
    }

    // MARK: - UIPageViewControllerDataSource / Delegate

    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        guard let vc = viewController as? ReaderSlidePageViewController, vc.index > 0 else { return nil }
        return makeSlideVC(at: vc.index - 1)
    }

    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        guard let vc = viewController as? ReaderSlidePageViewController, vc.index < slides.count - 1 else { return nil }
        return makeSlideVC(at: vc.index + 1)
    }

    func pageViewController(_ pageViewController: UIPageViewController, didFinishAnimating finished: Bool, previousViewControllers: [UIViewController], transitionCompleted completed: Bool) {
        guard completed, let currentVC = pageViewController.viewControllers?.first as? ReaderSlidePageViewController else {
            return
        }
        currentIndex = currentVC.index
        syncUI()
    }

    // MARK: - MetronomeObserver

    func metronomeDidUpdateState(_ engine: MetronomeAudioEngine) {
        syncUI()
    }

    func metronomeDidTickBeat(_ engine: MetronomeAudioEngine, beatIndex: Int, beatTick: Int) {
        visualDots.update(accents: engine.accents, currentBeat: beatIndex, isRunning: engine.isRunning)
    }
}

/// Individual zoomable page inside UIPageViewController (pinch-to-zoom 1x..4x + double-tap reset).
private final class ReaderSlidePageViewController: UIViewController, UIScrollViewDelegate {
    let slide: ReaderSlide
    let index: Int

    private let scrollView = UIScrollView()
    private let imageView = UIImageView()
    private let spinner = UIActivityIndicatorView(style: .medium)
    private var loadedKey: String = ""

    init(slide: ReaderSlide, index: Int) {
        self.slide = slide
        self.index = index
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black

        scrollView.delegate = self
        scrollView.minimumZoomScale = 1.0
        scrollView.maximumZoomScale = 4.0
        scrollView.showsVerticalScrollIndicator = false
        scrollView.showsHorizontalScrollIndicator = false
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scrollView)

        imageView.contentMode = .scaleAspectFit
        imageView.backgroundColor = .black
        imageView.translatesAutoresizingMaskIntoConstraints = false
        scrollView.addSubview(imageView)

        spinner.color = AtrilColors.gold
        spinner.translatesAutoresizingMaskIntoConstraints = false
        spinner.startAnimating()
        view.addSubview(spinner)

        NSLayoutConstraint.activate([
            scrollView.topAnchor.constraint(equalTo: view.topAnchor),
            scrollView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor),

            imageView.topAnchor.constraint(equalTo: scrollView.contentLayoutGuide.topAnchor),
            imageView.bottomAnchor.constraint(equalTo: scrollView.contentLayoutGuide.bottomAnchor),
            imageView.leadingAnchor.constraint(equalTo: scrollView.contentLayoutGuide.leadingAnchor),
            imageView.trailingAnchor.constraint(equalTo: scrollView.contentLayoutGuide.trailingAnchor),
            imageView.widthAnchor.constraint(equalTo: scrollView.frameLayoutGuide.widthAnchor),
            imageView.heightAnchor.constraint(equalTo: scrollView.frameLayoutGuide.heightAnchor),

            spinner.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            spinner.centerYAnchor.constraint(equalTo: view.centerYAnchor)
        ])

        let doubleTap = UITapGestureRecognizer(target: self, action: #selector(handleDoubleTap(_:)))
        doubleTap.numberOfTapsRequired = 2
        scrollView.addGestureRecognizer(doubleTap)
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        let w = view.bounds.width
        let sizeKey = "\(Int(w))x\(Int(view.bounds.height))"
        if w > 100 && sizeKey != loadedKey {
            loadedKey = sizeKey
            let targetWidth = min(1800, max(w, view.bounds.height))
            let scale = min(UIScreen.main.scale, 2.0)
            let att = NoteAttachment(
                id: slide.attachmentId,
                fileName: slide.fileName,
                kind: slide.kind,
                mimeType: slide.kind == .pdf ? "application/pdf" : "image/jpeg",
                size: 0,
                pageCount: slide.totalAttachmentPages,
                createdAt: 0
            )
            AtrilRepository.shared.renderThumbnail(for: att, pageNumber: slide.pageNumber, targetWidthPoints: targetWidth, scale: scale) { [weak self] img in
                self?.spinner.stopAnimating()
                self?.imageView.image = img
            }
        }
    }

    func viewForZooming(in scrollView: UIScrollView) -> UIView? {
        return imageView
    }

    @objc private func handleDoubleTap(_ gesture: UITapGestureRecognizer) {
        if scrollView.zoomScale > 1.05 {
            scrollView.setZoomScale(1.0, animated: true)
        } else {
            let point = gesture.location(in: imageView)
            let w = scrollView.bounds.width / 2.2
            let h = scrollView.bounds.height / 2.2
            scrollView.zoom(to: CGRect(x: point.x - w / 2, y: point.y - h / 2, width: w, height: h), animated: true)
        }
    }
}
