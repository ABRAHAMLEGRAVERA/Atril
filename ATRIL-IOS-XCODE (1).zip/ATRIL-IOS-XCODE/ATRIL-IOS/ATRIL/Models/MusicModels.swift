import Foundation

enum AttachmentKind: String, Codable, Equatable {
    case pdf
    case image
}

struct NoteAttachment: Codable, Equatable, Identifiable {
    let id: String
    var fileName: String
    var kind: AttachmentKind
    var mimeType: String
    var size: Int64
    var pageCount: Int
    var createdAt: Int64
}

struct NoteBlock: Codable, Equatable, Identifiable {
    enum BlockType: String, Codable {
        case text
        case sheet
    }

    let id: String
    let type: BlockType
    var text: String?
    var attachmentId: String?

    init(id: String, text: String) {
        self.id = id
        self.type = .text
        self.text = text
        self.attachmentId = nil
    }

    init(id: String, attachmentId: String) {
        self.id = id
        self.type = .sheet
        self.text = nil
        self.attachmentId = attachmentId
    }
}

struct Note: Codable, Equatable, Identifiable {
    let id: String
    var title: String
    var body: String
    var pinned: Bool
    var attachments: [NoteAttachment]
    var blocks: [NoteBlock]
    var createdAt: Int64
    var updatedAt: Int64
}

enum NotesFilterTab: String, Equatable {
    case all
    case pinned
}

enum WorkspaceTab: Int, CaseIterable {
    case notes = 0
    case click = 1
    case tuner = 2
}

enum BeatAccent: String, Codable, Equatable {
    case strong
    case normal
    case mute
}

enum TimeSignature: String, Codable, CaseIterable, Equatable {
    case fourFour = "4/4"
    case threeFour = "3/4"
    case sixEight = "6/8"
}

enum RhythmicSubdivision: String, Codable, CaseIterable, Equatable {
    case quarter
    case eighth
    case triplet

    var displayLabel: String {
        switch self {
        case .quarter: return "Negras"
        case .eighth: return "Corcheas"
        case .triplet: return "Tresillos"
        }
    }
}

enum TunerInstrument: String, Equatable {
    case guitar
    case bass
}

struct TunerStringSpec: Equatable {
    let id: String
    let label: String
    let midi: Int
}

enum TuningStatus: Equatable {
    case inTune
    case flat
    case sharp
}

struct DetectedNoteInfo: Equatable {
    let midi: Int
    let noteName: String
    let octave: Int
    let label: String
    let frequency: Double
    let targetFrequency: Double
    let cents: Double
    let status: TuningStatus
}

struct AppPreferences: Codable, Equatable {
    var optimizeImagesFor16GB: Bool
    var liveMode: Bool

    static let `default` = AppPreferences(
        optimizeImagesFor16GB: true,
        liveMode: false
    )
}

struct StorageStatus: Equatable {
    let attachmentsBytes: Int64
    let noteCount: Int
    let attachmentCount: Int
    let deviceFreeBytes: Int64?
    let isNearLimit: Bool
}

struct ReaderSlide: Equatable {
    let attachmentId: String
    let kind: AttachmentKind
    let fileName: String
    let pageNumber: Int
    let totalAttachmentPages: Int

    var cacheKey: String {
        "\(attachmentId):\(pageNumber)"
    }
}

struct BackupManifest: Codable {
    let app: String
    let version: Int
    let exportedAt: String
    let notes: [Note]
}

struct BackupInspectionResult {
    let valid: Bool
    let errors: [String]
    let manifest: BackupManifest?
    let fileCount: Int
    let totalFilesBytes: Int64
}

struct AttachmentFileRecord {
    let id: String
    let noteId: String
    let fileName: String
    let mimeType: String
    let data: Data
}
