import AVFoundation
import Foundation

/// Real-time chromatic tuner engine using AVAudioEngine input tap + YIN pitch detection
/// and reference tone synthesis for guitar & bass strings.
final class TunerAudioEngine {
    private var captureEngine: AVAudioEngine?
    private let toneEngine = AVAudioEngine()
    private let tonePlayer = AVAudioPlayerNode()
    private let format = AVAudioFormat(standardFormatWithSampleRate: 44100, channels: 1)!

    private let dspQueue = DispatchQueue(label: "com.atril.tuner.dsp", qos: .userInitiated)
    private var ringBuffer = [Float](repeating: 0, count: 4096)
    private var ringWriteCount = 0
    private var lastAnalysisTime: CFAbsoluteTime = 0
    private(set) var isListening = false

    init() {
        toneEngine.attach(tonePlayer)
        toneEngine.connect(tonePlayer, to: toneEngine.mainMixerNode, format: format)
    }

    deinit {
        stopMicrophone()
        toneEngine.stop()
    }

    func playReferenceTone(frequency: Double) {
        guard frequency > 20, frequency < 3000 else { return }
        do {
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.playAndRecord, mode: .default, options: [.defaultToSpeaker, .mixWithOthers, .allowBluetoothA2DP])
            try session.setActive(true)
            if !toneEngine.isRunning {
                try toneEngine.start()
            }
        } catch {
            try? toneEngine.start()
        }

        let duration = 1.15
        let sr = format.sampleRate
        let frames = AVAudioFrameCount(sr * duration)
        guard let buffer = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: frames) else { return }
        buffer.frameLength = frames

        if let data = buffer.floatChannelData?[0] {
            for i in 0..<Int(frames) {
                let t = Double(i) / sr
                let attack = min(1.0, t / 0.02)
                let decay = exp(-3.2 * t)
                let fundamental = sin(2.0 * Double.pi * frequency * t)
                let harmonic2 = 0.24 * sin(2.0 * Double.pi * frequency * 2.0 * t)
                data[i] = Float((fundamental + harmonic2) * 0.28 * attack * decay)
            }
        }

        tonePlayer.stop()
        tonePlayer.scheduleBuffer(buffer, at: nil, options: [], completionHandler: nil)
        tonePlayer.play()
    }

    func startMicrophone(
        onPitch: @escaping (Double) -> Void,
        onStateChange: @escaping (Bool) -> Void,
        onError: @escaping (String) -> Void
    ) {
        let session = AVAudioSession.sharedInstance()
        let permission = session.recordPermission

        let proceed = { [weak self] (granted: Bool) in
            guard let self = self else { return }
            guard granted else {
                onStateChange(false)
                onError("Permiso de micrófono denegado. Actívalo en Ajustes > ATRIL.")
                return
            }
            self.beginAudioCapture(onPitch: onPitch, onStateChange: onStateChange, onError: onError)
        }

        if permission == .granted {
            proceed(true)
        } else if permission == .denied {
            proceed(false)
        } else {
            session.requestRecordPermission { granted in
                DispatchQueue.main.async {
                    proceed(granted)
                }
            }
        }
    }

    private func beginAudioCapture(
        onPitch: @escaping (Double) -> Void,
        onStateChange: @escaping (Bool) -> Void,
        onError: @escaping (String) -> Void
    ) {
        stopMicrophone()
        do {
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.playAndRecord, mode: .measurement, options: [.defaultToSpeaker, .allowBluetoothA2DP])
            try session.setActive(true)

            let engine = AVAudioEngine()
            let inputNode = engine.inputNode
            let hwFormat = inputNode.outputFormat(forBus: 0)
            let sampleRate = hwFormat.sampleRate > 0 ? hwFormat.sampleRate : 44100.0

            ringBuffer = [Float](repeating: 0, count: 4096)
            ringWriteCount = 0
            lastAnalysisTime = 0

            inputNode.installTap(onBus: 0, bufferSize: 2048, format: hwFormat) { [weak self] pcmBuffer, _ in
                guard let self = self,
                      let channelData = pcmBuffer.floatChannelData?[0] else { return }
                let count = Int(pcmBuffer.frameLength)
                guard count > 0 else { return }

                let chunk = Array(UnsafeBufferPointer(start: channelData, count: count))
                self.dspQueue.async { [weak self] in
                    guard let self = self, self.isListening else { return }
                    if chunk.count >= self.ringBuffer.count {
                        self.ringBuffer = Array(chunk.suffix(self.ringBuffer.count))
                    } else {
                        self.ringBuffer.removeFirst(chunk.count)
                        self.ringBuffer.append(contentsOf: chunk)
                    }
                    self.ringWriteCount += chunk.count
                    guard self.ringWriteCount >= 2048 else { return }

                    let now = CFAbsoluteTimeGetCurrent()
                    guard now - self.lastAnalysisTime >= 0.045 else { return }
                    self.lastAnalysisTime = now

                    if let freq = MusicStudioMath.detectPitchYIN(samples: self.ringBuffer, sampleRate: sampleRate) {
                        DispatchQueue.main.async {
                            onPitch(freq)
                        }
                    }
                }
            }

            engine.prepare()
            try engine.start()
            captureEngine = engine
            isListening = true
            onStateChange(true)
        } catch {
            stopMicrophone()
            onStateChange(false)
            onError("No se pudo iniciar el micrófono.")
        }
    }

    func stopMicrophone() {
        isListening = false
        if let engine = captureEngine {
            engine.inputNode.removeTap(onBus: 0)
            engine.stop()
            captureEngine = nil
        }
    }
}
