import AVFoundation
import Foundation

protocol MetronomeObserver: AnyObject {
    func metronomeDidUpdateState(_ engine: MetronomeAudioEngine)
    func metronomeDidTickBeat(_ engine: MetronomeAudioEngine, beatIndex: Int, beatTick: Int)
}

/// Sample-accurate metronome using AVAudioEngine + pre-synthesized PCM click buffers
/// with DispatchSourceTimer lookahead so audio stays steady across tab switches on iPad Air 2.
final class MetronomeAudioEngine {
    static let shared = MetronomeAudioEngine()

    private let audioEngine = AVAudioEngine()
    private let playerNode = AVAudioPlayerNode()
    private let renderFormat = AVAudioFormat(standardFormatWithSampleRate: 44100, channels: 1)!

    private var strongBuffer: AVAudioPCMBuffer!
    private var normalBuffer: AVAudioPCMBuffer!
    private var subdivisionBuffer: AVAudioPCMBuffer!

    private let schedulerQueue = DispatchQueue(label: "com.atril.metronome.scheduler", qos: .userInteractive)
    private var timer: DispatchSourceTimer?

    private(set) var isRunning: Bool = false
    private(set) var bpm: Int = 120
    private(set) var timeSignature: TimeSignature = .fourFour
    private(set) var subdivision: RhythmicSubdivision = .quarter
    private(set) var accents: [BeatAccent] = MusicStudioMath.defaultAccents(for: .fourFour)
    private(set) var currentBeat: Int?
    private(set) var beatTick: Int = 0

    private var tapHistoryMs: [Double] = []
    private var nextStepIndex: Int = 0
    private var nextStepHostTime: UInt64 = 0
    private var timebaseInfo = mach_timebase_info_data_t()

    private let observers = NSHashTable<AnyObject>.weakObjects()

    private init() {
        mach_timebase_info(&timebaseInfo)
        strongBuffer = makeClickBuffer(startHz: 1480, endHz: 920, duration: 0.036, gain: 0.72, triangle: true)
        normalBuffer = makeClickBuffer(startHz: 960, endHz: 620, duration: 0.028, gain: 0.45, triangle: false)
        subdivisionBuffer = makeClickBuffer(startHz: 1240, endHz: 760, duration: 0.022, gain: 0.28, triangle: false)

        audioEngine.attach(playerNode)
        audioEngine.connect(playerNode, to: audioEngine.mainMixerNode, format: renderFormat)

        NotificationCenter.default.addObserver(
            self,
            selector: #selector(handleInterruption(_:)),
            name: AVAudioSession.interruptionNotification,
            object: nil
        )
    }

    deinit {
        NotificationCenter.default.removeObserver(self)
        stop()
    }

    func addObserver(_ observer: MetronomeObserver) {
        observers.add(observer)
    }

    func removeObserver(_ observer: MetronomeObserver) {
        observers.remove(observer)
    }

    private func notifyState() {
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            for obj in self.observers.allObjects {
                (obj as? MetronomeObserver)?.metronomeDidUpdateState(self)
            }
        }
    }

    private func notifyBeat(beatIndex: Int, tick: Int) {
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            for obj in self.observers.allObjects {
                (obj as? MetronomeObserver)?.metronomeDidTickBeat(self, beatIndex: beatIndex, beatTick: tick)
            }
        }
    }

    @objc private func handleInterruption(_ notification: Notification) {
        guard let info = notification.userInfo,
              let typeVal = info[AVAudioSessionInterruptionTypeKey] as? UInt,
              let type = AVAudioSession.InterruptionType(rawValue: typeVal) else { return }
        if type == .began && isRunning {
            stop()
        }
    }

    // MARK: - Controls

    func toggle() {
        if isRunning {
            stop()
        } else {
            start()
        }
    }

    func start() {
        guard !isRunning else { return }
        do {
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.playAndRecord, mode: .default, options: [.defaultToSpeaker, .mixWithOthers, .allowBluetoothA2DP])
            try session.setActive(true)
            if !audioEngine.isRunning {
                try audioEngine.start()
            }
            if !playerNode.isPlaying {
                playerNode.play()
            }
        } catch {
            // Best-effort playback even if session category partially constrained
            try? audioEngine.start()
            playerNode.play()
        }

        schedulerQueue.sync {
            isRunning = true
            nextStepIndex = 0
            beatTick = 0
            currentBeat = 0
            let leadNs: UInt64 = 45_000_000
            nextStepHostTime = mach_absolute_time() + nanosToHostTicks(leadNs)
        }

        startSchedulerTimer()
        notifyState()
    }

    func stop() {
        schedulerQueue.sync {
            timer?.cancel()
            timer = nil
            isRunning = false
            currentBeat = nil
            nextStepIndex = 0
        }
        playerNode.stop()
        notifyState()
    }

    func setBpm(_ next: Int) {
        let clamped = MusicStudioMath.clampBpm(next)
        guard clamped != bpm else { return }
        schedulerQueue.sync {
            bpm = clamped
        }
        notifyState()
    }

    func adjustBpm(_ delta: Int) {
        setBpm(bpm + delta)
    }

    func setTimeSignature(_ signature: TimeSignature) {
        guard signature != timeSignature else { return }
        schedulerQueue.sync {
            timeSignature = signature
            accents = MusicStudioMath.resizeAccents(accents, for: signature)
            nextStepIndex = 0
            if isRunning {
                currentBeat = 0
            }
        }
        notifyState()
    }

    func setSubdivision(_ next: RhythmicSubdivision) {
        guard next != subdivision else { return }
        schedulerQueue.sync {
            subdivision = next
            nextStepIndex = 0
        }
        notifyState()
    }

    func cycleAccent(at index: Int) {
        schedulerQueue.sync {
            guard index >= 0 && index < accents.count else { return }
            accents[index] = MusicStudioMath.cycleAccent(accents[index])
        }
        notifyState()
    }

    func tapTempo() {
        let nowMs = CFAbsoluteTimeGetCurrent() * 1000.0
        let res = MusicStudioMath.computeTapTempoBpm(previousTapsMs: tapHistoryMs, nowMs: nowMs)
        tapHistoryMs = res.nextTaps
        if let newBpm = res.bpm {
            setBpm(newBpm)
        }
    }

    // MARK: - Scheduling & PCM Synthesis

    private func startSchedulerTimer() {
        timer?.cancel()
        let src = DispatchSource.makeTimerSource(queue: schedulerQueue)
        src.schedule(deadline: .now(), repeating: .milliseconds(16), leeway: .milliseconds(3))
        src.setEventHandler { [weak self] in
            self?.scheduleLookahead()
        }
        timer = src
        src.resume()
    }

    private func scheduleLookahead() {
        guard isRunning else { return }
        let nowHost = mach_absolute_time()
        let lookaheadTicks = nanosToHostTicks(120_000_000) // 120ms lookahead
        let horizon = nowHost + lookaheadTicks

        while nextStepHostTime <= horizon {
            let subCount = max(1, MusicStudioMath.subdivisionCount(for: subdivision))
            let beatCount = max(1, accents.count)
            let beatIdx = (nextStepIndex / subCount) % beatCount
            let subStep = nextStepIndex % subCount
            let accent = accents[beatIdx]
            let stepSec = MusicStudioMath.subdivisionStepSeconds(bpm: bpm, subdivision: subdivision)

            let scheduleTime = AVAudioTime(hostTime: nextStepHostTime)

            if accent != .mute {
                if subStep == 0 {
                    let buf: AVAudioPCMBuffer = (accent == .strong) ? strongBuffer : normalBuffer
                    playerNode.scheduleBuffer(buf, at: scheduleTime, options: [], completionHandler: nil)
                } else {
                    playerNode.scheduleBuffer(subdivisionBuffer, at: scheduleTime, options: [], completionHandler: nil)
                }
            }

            if subStep == 0 {
                let tickNumber = beatTick + 1
                beatTick = tickNumber
                let delayNs = hostTicksToNanos(nextStepHostTime > nowHost ? (nextStepHostTime - nowHost) : 0)
                DispatchQueue.main.asyncAfter(deadline: .now() + .nanoseconds(Int(delayNs))) { [weak self] in
                    guard let self = self, self.isRunning else { return }
                    self.currentBeat = beatIdx
                    self.notifyBeat(beatIndex: beatIdx, tick: tickNumber)
                }
            }

            nextStepIndex += 1
            let stepNs = UInt64(stepSec * 1_000_000_000.0)
            nextStepHostTime += nanosToHostTicks(stepNs)
        }
    }

    private func nanosToHostTicks(_ nanos: UInt64) -> UInt64 {
        let numer = UInt64(timebaseInfo.numer)
        let denom = UInt64(timebaseInfo.denom)
        guard numer > 0 else { return nanos }
        return (nanos / numer) * denom + ((nanos % numer) * denom) / numer
    }

    private func hostTicksToNanos(_ ticks: UInt64) -> UInt64 {
        let numer = UInt64(timebaseInfo.numer)
        let denom = UInt64(timebaseInfo.denom)
        guard denom > 0 else { return ticks }
        return (ticks / denom) * numer + ((ticks % denom) * numer) / denom
    }

    private func makeClickBuffer(startHz: Double, endHz: Double, duration: Double, gain: Float, triangle: Bool) -> AVAudioPCMBuffer {
        let sampleRate = renderFormat.sampleRate
        let frameCount = AVAudioFrameCount(max(64, Int(sampleRate * duration)))
        let buffer = AVAudioPCMBuffer(pcmFormat: renderFormat, frameCapacity: frameCount)!
        buffer.frameLength = frameCount

        guard let samples = buffer.floatChannelData?[0] else { return buffer }
        var phase = 0.0
        for i in 0..<Int(frameCount) {
            let t = Double(i) / Double(frameCount)
            let freq = startHz + (endHz - startHz) * t
            phase += (2.0 * Double.pi * freq) / sampleRate
            let wave: Double
            if triangle {
                let norm = (phase / (2.0 * Double.pi)).truncatingRemainder(dividingBy: 1.0)
                wave = 4.0 * abs(norm - 0.5) - 1.0
            } else {
                wave = sin(phase)
            }
            let env = Float(pow(1.0 - t, 2.4))
            samples[i] = Float(wave) * gain * env
        }
        return buffer
    }
}
