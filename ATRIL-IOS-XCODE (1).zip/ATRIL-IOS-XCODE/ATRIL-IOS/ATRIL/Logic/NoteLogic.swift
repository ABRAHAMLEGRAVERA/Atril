import Foundation

enum NoteLogic {
    private static let imageExtensions: Set<String> = [
        "png", "jpg", "jpeg", "webp", "gif", "bmp", "heic", "heif", "avif", "tif", "tiff"
    ]

    static func createId(prefix: String) -> String {
        return "\(prefix)-\(UUID().uuidString.lowercased())"
    }

    static func normalizeText(_ value: String) -> String {
        return value
            .folding(options: [.diacriticInsensitive, .caseInsensitive], locale: Locale(identifier: "es_ES"))
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }

    static func filterAndSortNotes(_ notes: [Note], query: String, tab: NotesFilterTab) -> [Note] {
        let q = normalizeText(query)
        let filtered = notes.filter { note in
            if tab == .pinned && !note.pinned { return false }
            if q.isEmpty { return true }
            let attNames = note.attachments.map { $0.fileName }.joined(separator: " ")
            let haystack = normalizeText("\(note.title) \(note.body) \(attNames)")
            return haystack.contains(q)
        }
        return filtered.sorted { lhs, rhs in
            if lhs.pinned != rhs.pinned {
                return lhs.pinned && !rhs.pinned
            }
            return lhs.updatedAt > rhs.updatedAt
        }
    }

    static func getNoteSnippet(_ note: Note) -> String {
        let lines = note.body
            .components(separatedBy: .newlines)
            .map { $0.trimmingCharacters(in: .whitespaces) }
            .filter { !$0.isEmpty }
        if let first = lines.first {
            return first
        }
        if !note.attachments.isEmpty {
            let count = note.attachments.count
            return "\(count) \(count == 1 ? "archivo adjunto" : "archivos adjuntos")"
        }
        return "Sin texto adicional"
    }

    static func getNoteTotalBytes(_ note: Note) -> Int64 {
        return note.attachments.reduce(0) { $0 + max(0, $1.size) }
    }

    static func formatBytes(_ bytes: Int64) -> String {
        guard bytes > 0 else { return "0 KB" }
        if bytes < 1024 {
            return "\(bytes) B"
        }
        let kb = Double(bytes) / 1024.0
        if kb < 1024.0 {
            return kb < 10.0 ? String(format: "%.1f KB", kb) : String(format: "%.0f KB", kb)
        }
        let mb = kb / 1024.0
        if mb < 1024.0 {
            return String(format: "%.1f MB", mb)
        }
        let gb = mb / 1024.0
        return String(format: "%.2f GB", gb)
    }

    private static let shortDateFormatter: DateFormatter = {
        let df = DateFormatter()
        df.locale = Locale(identifier: "es_ES")
        df.dateFormat = "d MMM"
        return df
    }()

    static func formatDateShort(_ timestampMs: Int64) -> String {
        let date = Date(timeIntervalSince1970: Double(timestampMs) / 1000.0)
        return shortDateFormatter.string(from: date)
    }

    static func detectAttachmentKind(fileName: String, mimeType: String? = nil) -> AttachmentKind? {
        let lowerMime = (mimeType ?? "").lowercased()
        let ext = URL(fileURLWithPath: fileName).pathExtension.lowercased()
        if lowerMime == "application/pdf" || ext == "pdf" {
            return .pdf
        }
        if lowerMime.hasPrefix("image/") || imageExtensions.contains(ext) {
            return .image
        }
        return nil
    }

    static func normalizeNoteBlocks(_ note: Note) -> [NoteBlock] {
        let validAttIds = Set(note.attachments.map { $0.id })

        if !note.blocks.isEmpty {
            var seenSheets = Set<String>()
            var cleaned: [NoteBlock] = []

            for block in note.blocks {
                if block.type == .text {
                    let blockText = block.text ?? ""
                    if let last = cleaned.last, last.type == .text {
                        let prevText = last.text ?? ""
                        let mergedText: String
                        if !prevText.isEmpty && !blockText.isEmpty {
                            mergedText = "\(prevText)\n\(blockText)"
                        } else {
                            mergedText = prevText.isEmpty ? blockText : prevText
                        }
                        cleaned[cleaned.count - 1] = NoteBlock(id: last.id, text: mergedText)
                    } else {
                        cleaned.append(NoteBlock(id: block.id, text: blockText))
                    }
                } else if let attId = block.attachmentId, validAttIds.contains(attId), !seenSheets.contains(attId) {
                    seenSheets.insert(attId)
                    cleaned.append(NoteBlock(id: block.id, attachmentId: attId))
                }
            }

            for att in note.attachments where !seenSheets.contains(att.id) {
                cleaned.append(NoteBlock(id: "blk-sheet-\(att.id)", attachmentId: att.id))
            }

            return ensureBookendTextBlocks(cleaned, noteId: note.id)
        }

        var blocks: [NoteBlock] = [NoteBlock(id: "blk-head-\(note.id)", text: note.body)]
        for att in note.attachments {
            blocks.append(NoteBlock(id: "blk-sheet-\(att.id)", attachmentId: att.id))
        }
        if !note.attachments.isEmpty {
            blocks.append(NoteBlock(id: "blk-tail-\(note.id)", text: ""))
        }
        return blocks
    }

    private static func ensureBookendTextBlocks(_ blocks: [NoteBlock], noteId: String? = nil) -> [NoteBlock] {
        var copy = blocks
        if copy.isEmpty || copy[0].type != .text {
            let headId = noteId.map { "blk-head-\($0)" } ?? createId(prefix: "blk")
            copy.insert(NoteBlock(id: headId, text: ""), at: 0)
        }
        if copy[copy.count - 1].type != .text {
            let tailId = noteId.map { "blk-tail-\($0)" } ?? createId(prefix: "blk")
            copy.append(NoteBlock(id: tailId, text: ""))
        }
        return copy
    }

    static func deriveBodyFromBlocks(_ blocks: [NoteBlock]) -> String {
        return blocks
            .filter { $0.type == .text }
            .map { $0.text ?? "" }
            .filter { !$0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
            .joined(separator: "\n")
    }

    static func orderAttachmentsByBlocks(_ blocks: [NoteBlock], attachments: [NoteAttachment]) -> [NoteAttachment] {
        let byId = Dictionary(uniqueKeysWithValues: attachments.map { ($0.id, $0) })
        var ordered: [NoteAttachment] = []
        var seen = Set<String>()
        for block in blocks where block.type == .sheet {
            if let attId = block.attachmentId, let att = byId[attId], !seen.contains(att.id) {
                ordered.append(att)
                seen.insert(att.id)
            }
        }
        for att in attachments where !seen.contains(att.id) {
            ordered.append(att)
        }
        return ordered
    }

    static func insertSheetsIntoBlocks(
        _ blocks: [NoteBlock],
        targetTextBlockId: String?,
        cursorPos: Int?,
        newAttachmentIds: [String]
    ) -> [NoteBlock] {
        guard !newAttachmentIds.isEmpty else { return blocks }

        let sheetBlocks = newAttachmentIds.map { NoteBlock(id: createId(prefix: "blk"), attachmentId: $0) }
        let targetIdx = targetTextBlockId.flatMap { id in
            blocks.firstIndex { $0.id == id && $0.type == .text }
        }

        guard let idx = targetIdx else {
            var copy = blocks
            while copy.count > 1, copy.last?.type == .text, (copy.last?.text ?? "").isEmpty {
                copy.removeLast()
            }
            copy.append(contentsOf: sheetBlocks)
            copy.append(NoteBlock(id: createId(prefix: "blk"), text: ""))
            return ensureBookendTextBlocks(copy)
        }

        let target = blocks[idx]
        let fullText = target.text ?? ""
        let nsText = fullText as NSString
        let safeCursor: Int
        if let pos = cursorPos, pos >= 0, pos <= nsText.length {
            safeCursor = pos
        } else {
            safeCursor = nsText.length
        }

        let rawBefore = nsText.substring(to: safeCursor)
        let rawAfter = nsText.substring(from: safeCursor)
        let before = rawBefore.replacingOccurrences(of: "\\s+$", with: "", options: .regularExpression)
        let after = rawAfter.replacingOccurrences(of: "^\\s+", with: "", options: .regularExpression)

        var replacement: [NoteBlock] = [NoteBlock(id: target.id, text: before)]
        replacement.append(contentsOf: sheetBlocks)
        replacement.append(NoteBlock(id: createId(prefix: "blk"), text: after))

        var next: [NoteBlock] = []
        next.append(contentsOf: blocks[..<idx])
        next.append(contentsOf: replacement)
        if idx + 1 < blocks.count {
            next.append(contentsOf: blocks[(idx + 1)...])
        }
        return ensureBookendTextBlocks(next)
    }

    static func removeSheetFromBlocks(_ blocks: [NoteBlock], attachmentId: String) -> [NoteBlock] {
        let filtered = blocks.filter { !($0.type == .sheet && $0.attachmentId == attachmentId) }
        var merged: [NoteBlock] = []
        for block in filtered {
            if block.type == .text {
                let text = block.text ?? ""
                if let last = merged.last, last.type == .text {
                    let prevText = last.text ?? ""
                    let combined: String
                    if !prevText.isEmpty && !text.isEmpty {
                        combined = "\(prevText)\n\(text)"
                    } else {
                        combined = prevText.isEmpty ? text : prevText
                    }
                    merged[merged.count - 1] = NoteBlock(id: last.id, text: combined)
                } else {
                    merged.append(block)
                }
            } else {
                merged.append(block)
            }
        }
        return ensureBookendTextBlocks(merged)
    }

    static func buildNoteSlides(_ note: Note) -> [ReaderSlide] {
        var slides: [ReaderSlide] = []
        for att in note.attachments {
            if att.kind == .image {
                slides.append(ReaderSlide(
                    attachmentId: att.id,
                    kind: .image,
                    fileName: att.fileName,
                    pageNumber: 1,
                    totalAttachmentPages: 1
                ))
            } else {
                let pages = max(1, att.pageCount)
                for p in 1...pages {
                    slides.append(ReaderSlide(
                        attachmentId: att.id,
                        kind: .pdf,
                        fileName: att.fileName,
                        pageNumber: p,
                        totalAttachmentPages: pages
                    ))
                }
            }
        }
        return slides
    }

    static func resolveReaderSlideIndex(slides: [ReaderSlide], attachmentId: String?, pageNumber: Int?) -> Int {
        guard let attId = attachmentId else { return 0 }
        if let page = pageNumber,
           let exact = slides.firstIndex(where: { $0.attachmentId == attId && $0.pageNumber == page }) {
            return exact
        }
        if let first = slides.firstIndex(where: { $0.attachmentId == attId }) {
            return first
        }
        return 0
    }

    static func validateBackupManifest(data: Data, fileCount: Int, totalFilesBytes: Int64) -> BackupInspectionResult {
        let decoder = JSONDecoder()
        do {
            let manifest = try decoder.decode(BackupManifest.self, from: data)
            var errors: [String] = []
            if manifest.app != "ATRIL" {
                errors.append("El archivo no pertenece a un respaldo de ATRIL.")
            }
            if manifest.version != 2 {
                errors.append("La versión del respaldo no es compatible.")
            }
            if !errors.isEmpty {
                return BackupInspectionResult(
                    valid: false,
                    errors: errors,
                    manifest: nil,
                    fileCount: fileCount,
                    totalFilesBytes: totalFilesBytes
                )
            }
            return BackupInspectionResult(
                valid: true,
                errors: [],
                manifest: manifest,
                fileCount: fileCount,
                totalFilesBytes: totalFilesBytes
            )
        } catch {
            return BackupInspectionResult(
                valid: false,
                errors: ["El archivo atril-backup.json no tiene un formato JSON válido."],
                manifest: nil,
                fileCount: fileCount,
                totalFilesBytes: totalFilesBytes
            )
        }
    }
}
