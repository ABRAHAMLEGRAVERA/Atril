import Foundation

enum MusicStudioMath {
    static let bpmMin = 30
    static let bpmMax = 240

    static let noteNames = [
        "C", "C#", "D", "D#", "E", "F",
        "F#", "G", "G#", "A", "A#", "B"
    ]

    static let guitarStrings: [TunerStringSpec] = [
        TunerStringSpec(id: "E2", label: "E2", midi: 40),
        TunerStringSpec(id: "A2", label: "A2", midi: 45),
        TunerStringSpec(id: "D3", label: "D3", midi: 50),
        TunerStringSpec(id: "G3", label: "G3", midi: 55),
        TunerStringSpec(id: "B3", label: "B3", midi: 59),
        TunerStringSpec(id: "E4", label: "E4", midi: 64)
    ]

    static let bassStrings: [TunerStringSpec] = [
        TunerStringSpec(id: "E1", label: "E1", midi: 28),
        TunerStringSpec(id: "A1", label: "A1", midi: 33),
        TunerStringSpec(id: "D2", label: "D2", midi: 38),
        TunerStringSpec(id: "G2", label: "G2", midi: 43)
    ]

    static func clampBpm(_ bpm: Int) -> Int {
        return max(bpmMin, min(bpmMax, bpm))
    }

    static func clampBpm(_ bpm: Double) -> Int {
        guard bpm.isFinite else { return 120 }
        return clampBpm(Int(bpm.rounded()))
    }

    static func beatsCount(for signature: TimeSignature) -> Int {
        switch signature {
        case .fourFour: return 4
        case .threeFour: return 3
        case .sixEight: return 6
        }
    }

    static func defaultAccents(for signature: TimeSignature) -> [BeatAccent] {
        let count = beatsCount(for: signature)
        return (0..<count).map { $0 == 0 ? .strong : .normal }
    }

    static func resizeAccents(_ existing: [BeatAccent], for signature: TimeSignature) -> [BeatAccent] {
        let count = beatsCount(for: signature)
        return (0..<count).map { idx in
            if idx < existing.count {
                return existing[idx]
            }
            return idx == 0 ? .strong : .normal
        }
    }

    static func cycleAccent(_ accent: BeatAccent) -> BeatAccent {
        switch accent {
        case .strong: return .normal
        case .normal: return .mute
        case .mute: return .strong
        }
    }

    static func tempoMarking(for bpm: Int) -> String {
        let v = clampBpm(bpm)
        if v < 60 { return "Largo" }
        if v < 76 { return "Adagio" }
        if v < 108 { return "Andante" }
        if v < 120 { return "Moderato" }
        if v < 156 { return "Allegro" }
        if v < 176 { return "Vivace" }
        return "Presto"
    }

    static func beatIntervalSeconds(bpm: Int) -> Double {
        return 60.0 / Double(clampBpm(bpm))
    }

    static func subdivisionCount(for subdivision: RhythmicSubdivision) -> Int {
        switch subdivision {
        case .quarter: return 1
        case .eighth: return 2
        case .triplet: return 3
        }
    }

    static func subdivisionStepSeconds(bpm: Int, subdivision: RhythmicSubdivision) -> Double {
        return beatIntervalSeconds(bpm: bpm) / Double(subdivisionCount(for: subdivision))
    }

    static func computeTapTempoBpm(previousTapsMs: [Double], nowMs: Double) -> (bpm: Int?, nextTaps: [Double]) {
        var recent: [Double]
        if let last = previousTapsMs.last, nowMs - last <= 2000.0 {
            recent = Array((previousTapsMs + [nowMs]).suffix(6))
        } else {
            recent = [nowMs]
        }

        guard recent.count >= 2 else {
            return (nil, recent)
        }

        var totalDiff = 0.0
        for i in 1..<recent.count {
            totalDiff += recent[i] - recent[i - 1]
        }
        let avgMs = totalDiff / Double(recent.count - 1)
        guard avgMs > 0 else {
            return (nil, recent)
        }
        return (clampBpm(60000.0 / avgMs), recent)
    }

    static func midiToFrequency(_ midi: Int, a4Hz: Double = 440.0) -> Double {
        return a4Hz * pow(2.0, Double(midi - 69) / 12.0)
    }

    static func frequencyToMidiFloat(_ freq: Double, a4Hz: Double = 440.0) -> Double {
        return 69.0 + 12.0 * log2(freq / a4Hz)
    }

    static func centsBetween(_ freq: Double, target: Double) -> Double {
        guard freq > 0, target > 0 else { return 0.0 }
        return 1200.0 * log2(freq / target)
    }

    static func formatMidiNoteName(_ midi: Int) -> (noteName: String, octave: Int, label: String) {
        let idx = ((midi % 12) + 12) % 12
        let noteName = noteNames[idx]
        let octave = Int(floor(Double(midi) / 12.0)) - 1
        return (noteName, octave, "\(noteName)\(octave)")
    }

    static func analyzeFrequency(_ freq: Double, a4Hz: Double = 440.0, lockedMidi: Int? = nil) -> DetectedNoteInfo? {
        guard freq.isFinite, freq >= 25.0, freq <= 2200.0 else { return nil }

        let targetMidi = lockedMidi ?? Int(frequencyToMidiFloat(freq, a4Hz: a4Hz).rounded())
        let targetFreq = midiToFrequency(targetMidi, a4Hz: a4Hz)
        let rawCents = centsBetween(freq, target: targetFreq)
        let cents = max(-50.0, min(50.0, rawCents))
        let formatted = formatMidiNoteName(targetMidi)

        let status: TuningStatus
        if rawCents < -5.0 {
            status = .flat
        } else if rawCents > 5.0 {
            status = .sharp
        } else {
            status = .inTune
        }

        return DetectedNoteInfo(
            midi: targetMidi,
            noteName: formatted.noteName,
            octave: formatted.octave,
            label: formatted.label,
            frequency: freq,
            targetFrequency: targetFreq,
            cents: cents,
            status: status
        )
    }

    /// YIN cumulative mean normalized difference pitch detector.
    /// Tuned for guitar/bass fundamentals (E1 ~ 41.2 Hz up to ~1200 Hz).
    static func detectPitchYIN(samples: [Float], sampleRate: Double, rmsThreshold: Float = 0.008) -> Double? {
        let len = samples.count
        guard len >= 512, sampleRate > 0 else { return nil }

        var sumSq: Float = 0
        for v in samples {
            sumSq += v * v
        }
        let rms = sqrtf(sumSq / Float(len))
        guard rms >= rmsThreshold else { return nil }

        let halfLen = len / 2
        let minTau = max(8, Int(sampleRate / 1200.0))
        let maxTau = min(halfLen - 2, Int(sampleRate / 34.0))
        guard maxTau > minTau else { return nil }

        var diff = [Float](repeating: 0, count: maxTau + 1)
        for tau in minTau...maxTau {
            var acc: Float = 0
            for i in 0..<halfLen {
                let d = samples[i] - samples[i + tau]
                acc += d * d
            }
            diff[tau] = acc
        }

        var cmndf = [Float](repeating: 1, count: maxTau + 1)
        var runningSum: Float = 0
        for tau in 1...maxTau {
            runningSum += diff[tau]
            cmndf[tau] = runningSum > 0 ? (diff[tau] * Float(tau)) / runningSum : 1.0
        }

        let threshold: Float = 0.16
        var foundTau = -1
        var tau = minTau
        while tau < maxTau {
            if cmndf[tau] < threshold {
                while tau + 1 < maxTau && cmndf[tau + 1] < cmndf[tau] {
                    tau += 1
                }
                foundTau = tau
                break
            }
            tau += 1
        }

        if foundTau == -1 {
            var bestTau = minTau
            var bestVal = cmndf[minTau]
            for t in (minTau + 1)...maxTau {
                if cmndf[t] < bestVal {
                    bestVal = cmndf[t]
                    bestTau = t
                }
            }
            guard bestVal <= 0.25 else { return nil }
            foundTau = bestTau
        }

        var betterTau = Double(foundTau)
        if foundTau > minTau && foundTau < maxTau {
            let s0 = Double(cmndf[foundTau - 1])
            let s1 = Double(cmndf[foundTau])
            let s2 = Double(cmndf[foundTau + 1])
            let denom = 2.0 * s1 - s2 - s0
            if abs(denom) > 1e-9 {
                betterTau = Double(foundTau) + (s2 - s0) / (2.0 * denom)
            }
        }

        guard betterTau > 0 else { return nil }
        return sampleRate / betterTau
    }
}
