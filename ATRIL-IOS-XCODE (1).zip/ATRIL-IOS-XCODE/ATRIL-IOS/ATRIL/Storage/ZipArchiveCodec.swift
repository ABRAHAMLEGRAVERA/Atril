import Compression
import Foundation

enum ZipArchiveError: LocalizedError {
    case invalidArchive
    case unsupportedCompression(UInt16)
    case corruptedEntry(String)

    var errorDescription: String? {
        switch self {
        case .invalidArchive:
            return "El archivo ZIP no es válido o está dañado."
        case .unsupportedCompression(let method):
            return "Método de compresión ZIP no compatible (\(method))."
        case .corruptedEntry(let name):
            return "No se pudo descomprimir \(name)."
        }
    }
}

struct ZipEntry {
    let path: String
    let data: Data
}

/// Pure Swift PKZIP reader/writer compatible with JSZip and macOS/iOS Files.
/// Uses Apple's built-in `Compression` (`COMPRESSION_ZLIB` raw DEFLATE) + pure Swift CRC32.
enum ZipArchiveCodec {
    private static let crcTable: [UInt32] = {
        (0..<256).map { i -> UInt32 in
            var c = UInt32(i)
            for _ in 0..<8 {
                c = (c & 1) != 0 ? (0xEDB88320 ^ (c >> 1)) : (c >> 1)
            }
            return c
        }
    }()

    static func crc32(_ data: Data) -> UInt32 {
        var crc: UInt32 = 0xFFFFFFFF
        for byte in data {
            let idx = Int((crc ^ UInt32(byte)) & 0xFF)
            crc = crcTable[idx] ^ (crc >> 8)
        }
        return crc ^ 0xFFFFFFFF
    }

    static func encode(entries: [ZipEntry], compress: Bool = false) -> Data {
        var output = Data()
        var centralDirectory = Data()

        let (dosTime, dosDate) = currentDosDateTime()

        for entry in entries {
            let cleanPath = entry.path.hasPrefix("/") ? String(entry.path.dropFirst()) : entry.path
            let nameData = cleanPath.data(using: .utf8) ?? Data()
            let crc = crc32(entry.data)
            let uncompressedSize = UInt32(entry.data.count)

            var method: UInt16 = 0 // STORE
            var payload = entry.data
            if compress, entry.data.count > 64, let deflated = deflateRaw(entry.data), deflated.count < entry.data.count {
                method = 8 // DEFLATE
                payload = deflated
            }
            let compressedSize = UInt32(payload.count)
            let localHeaderOffset = UInt32(output.count)

            // Local file header (30 bytes + name)
            output.appendLE(UInt32(0x04034B50))
            output.appendLE(UInt16(20)) // version needed
            output.appendLE(UInt16(0x0800)) // UTF-8 filename flag
            output.appendLE(method)
            output.appendLE(dosTime)
            output.appendLE(dosDate)
            output.appendLE(crc)
            output.appendLE(compressedSize)
            output.appendLE(uncompressedSize)
            output.appendLE(UInt16(nameData.count))
            output.appendLE(UInt16(0)) // extra length
            output.append(nameData)
            output.append(payload)

            // Central directory header (46 bytes + name)
            centralDirectory.appendLE(UInt32(0x02014B50))
            centralDirectory.appendLE(UInt16(20)) // version made by
            centralDirectory.appendLE(UInt16(20)) // version needed
            centralDirectory.appendLE(UInt16(0x0800)) // UTF-8
            centralDirectory.appendLE(method)
            centralDirectory.appendLE(dosTime)
            centralDirectory.appendLE(dosDate)
            centralDirectory.appendLE(crc)
            centralDirectory.appendLE(compressedSize)
            centralDirectory.appendLE(uncompressedSize)
            centralDirectory.appendLE(UInt16(nameData.count))
            centralDirectory.appendLE(UInt16(0)) // extra len
            centralDirectory.appendLE(UInt16(0)) // comment len
            centralDirectory.appendLE(UInt16(0)) // disk number start
            centralDirectory.appendLE(UInt16(0)) // internal attrs
            centralDirectory.appendLE(UInt32(0)) // external attrs
            centralDirectory.appendLE(localHeaderOffset)
            centralDirectory.append(nameData)
        }

        let cdOffset = UInt32(output.count)
        let cdSize = UInt32(centralDirectory.count)
        let entryCount = UInt16(min(entries.count, Int(UInt16.max)))

        output.append(centralDirectory)

        // End of central directory (22 bytes)
        output.appendLE(UInt32(0x06054B50))
        output.appendLE(UInt16(0)) // disk num
        output.appendLE(UInt16(0)) // start disk
        output.appendLE(entryCount)
        output.appendLE(entryCount)
        output.appendLE(cdSize)
        output.appendLE(cdOffset)
        output.appendLE(UInt16(0)) // comment len

        return output
    }

    static func decode(data: Data) throws -> [ZipEntry] {
        guard data.count >= 22 else { throw ZipArchiveError.invalidArchive }

        // Locate End of Central Directory signature 0x06054B50
        let minSearch = max(0, data.count - 65558)
        var eocdOffset: Int?
        var pos = data.count - 22
        while pos >= minSearch {
            if data.readUInt32LE(at: pos) == 0x06054B50 {
                eocdOffset = pos
                break
            }
            pos -= 1
        }
        guard let eocd = eocdOffset else { throw ZipArchiveError.invalidArchive }

        let totalEntries = Int(data.readUInt16LE(at: eocd + 10))
        let cdOffset = Int(data.readUInt32LE(at: eocd + 16))
        guard cdOffset >= 0, cdOffset < data.count else { throw ZipArchiveError.invalidArchive }

        var cursor = cdOffset
        var entries: [ZipEntry] = []

        for _ in 0..<totalEntries {
            guard cursor + 46 <= data.count, data.readUInt32LE(at: cursor) == 0x02014B50 else {
                throw ZipArchiveError.invalidArchive
            }

            let method = data.readUInt16LE(at: cursor + 10)
            let expectedCrc = data.readUInt32LE(at: cursor + 16)
            let compressedSize = Int(data.readUInt32LE(at: cursor + 20))
            let uncompressedSize = Int(data.readUInt32LE(at: cursor + 24))
            let nameLen = Int(data.readUInt16LE(at: cursor + 28))
            let extraLen = Int(data.readUInt16LE(at: cursor + 30))
            let commentLen = Int(data.readUInt16LE(at: cursor + 32))
            let localOffset = Int(data.readUInt32LE(at: cursor + 42))

            let nameStart = cursor + 46
            guard nameStart + nameLen <= data.count else { throw ZipArchiveError.invalidArchive }
            let path = String(data: data.subdata(in: nameStart..<(nameStart + nameLen)), encoding: .utf8) ?? ""
            cursor = nameStart + nameLen + extraLen + commentLen

            if path.hasSuffix("/") { continue }

            guard localOffset + 30 <= data.count, data.readUInt32LE(at: localOffset) == 0x04034B50 else {
                throw ZipArchiveError.invalidArchive
            }
            let localNameLen = Int(data.readUInt16LE(at: localOffset + 26))
            let localExtraLen = Int(data.readUInt16LE(at: localOffset + 28))
            let payloadStart = localOffset + 30 + localNameLen + localExtraLen
            let payloadEnd = payloadStart + compressedSize
            guard payloadStart >= 0, payloadEnd <= data.count else {
                throw ZipArchiveError.invalidArchive
            }

            let compressedSlice = data.subdata(in: payloadStart..<payloadEnd)
            let rawData: Data
            if method == 0 {
                rawData = compressedSlice
            } else if method == 8 {
                guard let inflated = inflateRaw(compressedSlice, expectedSize: max(uncompressedSize, compressedSize * 4)) else {
                    throw ZipArchiveError.corruptedEntry(path)
                }
                rawData = inflated
            } else {
                throw ZipArchiveError.unsupportedCompression(method)
            }

            if crc32(rawData) != expectedCrc {
                throw ZipArchiveError.corruptedEntry(path)
            }
            entries.append(ZipEntry(path: path, data: rawData))
        }

        return entries
    }

    private static func deflateRaw(_ input: Data) -> Data? {
        guard !input.isEmpty else { return Data() }
        let dstCapacity = max(256, input.count + 128)
        let dstBuffer = UnsafeMutablePointer<UInt8>.allocate(capacity: dstCapacity)
        defer { dstBuffer.deallocate() }

        let written: Int = input.withUnsafeBytes { rawBuf in
            guard let srcPtr = rawBuf.baseAddress?.assumingMemoryBound(to: UInt8.self) else {
                return 0
            }
            return compression_encode_buffer(dstBuffer, dstCapacity, srcPtr, input.count, nil, COMPRESSION_ZLIB)
        }
        guard written > 0 else { return nil }
        return Data(bytes: dstBuffer, count: written)
    }

    private static func inflateRaw(_ input: Data, expectedSize: Int) -> Data? {
        guard !input.isEmpty else { return Data() }
        var dstCapacity = max(4096, expectedSize + 64)
        for _ in 0..<5 {
            let dstBuffer = UnsafeMutablePointer<UInt8>.allocate(capacity: dstCapacity)
            let written: Int = input.withUnsafeBytes { rawBuf in
                guard let srcPtr = rawBuf.baseAddress?.assumingMemoryBound(to: UInt8.self) else {
                    return 0
                }
                return compression_decode_buffer(dstBuffer, dstCapacity, srcPtr, input.count, nil, COMPRESSION_ZLIB)
            }
            if written > 0 && written < dstCapacity {
                let out = Data(bytes: dstBuffer, count: written)
                dstBuffer.deallocate()
                return out
            }
            dstBuffer.deallocate()
            dstCapacity *= 2
        }
        return nil
    }

    private static func currentDosDateTime() -> (UInt16, UInt16) {
        let cal = Calendar(identifier: .gregorian)
        let comps = cal.dateComponents([.year, .month, .day, .hour, .minute, .second], from: Date())
        let year = max(1980, comps.year ?? 2026) - 1980
        let month = comps.month ?? 1
        let day = comps.day ?? 1
        let hour = comps.hour ?? 0
        let minute = comps.minute ?? 0
        let second = (comps.second ?? 0) / 2
        let dosTime = UInt16((hour << 11) | (minute << 5) | second)
        let dosDate = UInt16((year << 9) | (month << 5) | day)
        return (dosTime, dosDate)
    }
}

private extension Data {
    mutating func appendLE(_ value: UInt16) {
        var le = value.littleEndian
        Swift.withUnsafeBytes(of: &le) { append(contentsOf: $0) }
    }

    mutating func appendLE(_ value: UInt32) {
        var le = value.littleEndian
        Swift.withUnsafeBytes(of: &le) { append(contentsOf: $0) }
    }

    func readUInt16LE(at offset: Int) -> UInt16 {
        let b0 = UInt16(self[offset])
        let b1 = UInt16(self[offset + 1]) << 8
        return b0 | b1
    }

    func readUInt32LE(at offset: Int) -> UInt32 {
        let b0 = UInt32(self[offset])
        let b1 = UInt32(self[offset + 1]) << 8
        let b2 = UInt32(self[offset + 2]) << 16
        let b3 = UInt32(self[offset + 3]) << 24
        return b0 | b1 | b2 | b3
    }
}
