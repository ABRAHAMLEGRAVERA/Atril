import UIKit

enum SamplePdfGenerator {
    static func createSheetPdf(title: String, key: String, sections: [(heading: String, lines: [String])]) -> Data {
        let pageRect = CGRect(x: 0, y: 0, width: 612, height: 792) // US Letter
        let renderer = UIGraphicsPDFRenderer(bounds: pageRect)

        return renderer.pdfData { ctx in
            for (index, section) in sections.enumerated() {
                ctx.beginPage()

                let paragraphLeft = NSMutableParagraphStyle()
                paragraphLeft.lineSpacing = 4

                // Header rule on page 1 or continuation
                if index == 0 {
                    let titleAttrs: [NSAttributedString.Key: Any] = [
                        .font: UIFont.systemFont(ofSize: 24, weight: .bold),
                        .foregroundColor: UIColor(red: 0.1, green: 0.1, blue: 0.12, alpha: 1)
                    ]
                    (title as NSString).draw(in: CGRect(x: 48, y: 46, width: 516, height: 34), withAttributes: titleAttrs)

                    let keyAttrs: [NSAttributedString.Key: Any] = [
                        .font: UIFont.systemFont(ofSize: 13, weight: .semibold),
                        .foregroundColor: UIColor(red: 0.42, green: 0.42, blue: 0.46, alpha: 1)
                    ]
                    (key as NSString).draw(in: CGRect(x: 48, y: 82, width: 516, height: 22), withAttributes: keyAttrs)

                    let linePath = UIBezierPath()
                    linePath.move(to: CGPoint(x: 48, y: 112))
                    linePath.addLine(to: CGPoint(x: 564, y: 112))
                    UIColor(white: 0.85, alpha: 1).setStroke()
                    linePath.lineWidth = 1
                    linePath.stroke()
                }

                let startY: CGFloat = index == 0 ? 132 : 58
                let headingAttrs: [NSAttributedString.Key: Any] = [
                    .font: UIFont.systemFont(ofSize: 14, weight: .bold),
                    .foregroundColor: UIColor(red: 0.65, green: 0.45, blue: 0.10, alpha: 1)
                ]
                (section.heading as NSString).draw(in: CGRect(x: 48, y: startY, width: 516, height: 24), withAttributes: headingAttrs)

                var y = startY + 34
                let chordAttrs: [NSAttributedString.Key: Any] = [
                    .font: UIFont.monospacedSystemFont(ofSize: 14, weight: .semibold),
                    .foregroundColor: UIColor(red: 0.12, green: 0.12, blue: 0.14, alpha: 1),
                    .paragraphStyle: paragraphLeft
                ]
                let lyricAttrs: [NSAttributedString.Key: Any] = [
                    .font: UIFont.systemFont(ofSize: 15, weight: .regular),
                    .foregroundColor: UIColor(red: 0.18, green: 0.18, blue: 0.20, alpha: 1),
                    .paragraphStyle: paragraphLeft
                ]

                for line in section.lines {
                    let isChordLine = line.hasPrefix("[") || line.contains("   ")
                    let attrs = isChordLine ? chordAttrs : lyricAttrs
                    (line as NSString).draw(in: CGRect(x: 48, y: y, width: 516, height: 26), withAttributes: attrs)
                    y += isChordLine ? 22 : 28
                }

                // Draw clean 5-line musical staff guide at bottom of page for annotations
                let staffTop: CGFloat = 650
                UIColor(white: 0.82, alpha: 1).setStroke()
                for s in 0..<5 {
                    let sy = staffTop + CGFloat(s) * 10
                    let staffPath = UIBezierPath()
                    staffPath.move(to: CGPoint(x: 48, y: sy))
                    staffPath.addLine(to: CGPoint(x: 564, y: sy))
                    staffPath.lineWidth = 0.8
                    staffPath.stroke()
                }

                let footerAttrs: [NSAttributedString.Key: Any] = [
                    .font: UIFont.monospacedDigitSystemFont(ofSize: 11, weight: .medium),
                    .foregroundColor: UIColor(white: 0.55, alpha: 1)
                ]
                let pageLabel = "Página \(index + 1) de \(sections.count)"
                (pageLabel as NSString).draw(at: CGPoint(x: 48, y: 742), withAttributes: footerAttrs)
            }
        }
    }

    static func generateDefaultSheets() -> [(fileName: String, data: Data)] {
        let cuanGrande = createSheetPdf(
            title: "Cuán Grande Es Él",
            key: "Tonalidad: A Mayor · 4/4 · 72 BPM",
            sections: [
                (
                    heading: "VERSO 1",
                    lines: [
                        "A                 D",
                        "Señor mi Dios, al contemplar los cielos,",
                        "A            E             A",
                        "El firmamento y las estrellas mil,",
                        "A                  D",
                        "Al oír Tu voz en los potentes truenos,",
                        "A           E               A",
                        "Y ver brillar el sol en su cenit."
                    ]
                ),
                (
                    heading: "CORO",
                    lines: [
                        "A           D              A",
                        "Mi corazón entona la canción,",
                        "E                 A",
                        "¡Cuán grande es Él! ¡Cuán grande es Él!",
                        "A           D              A",
                        "Mi corazón entona la canción,",
                        "E                 A",
                        "¡Cuán grande es Él! ¡Cuán grande es Él!"
                    ]
                )
            ]
        )

        let sublimeGracia = createSheetPdf(
            title: "Sublime Gracia",
            key: "Tonalidad: G Mayor · 3/4 · 68 BPM",
            sections: [
                (
                    heading: "VERSO 1 & CORO",
                    lines: [
                        "G          C          G",
                        "Sublime gracia del Señor,",
                        "G              D",
                        "Que a un infeliz salvó;",
                        "G            C       G",
                        "Yo ciego fui, mas hoy veo ya,",
                        "G       D      G",
                        "Perdido y Él me halló."
                    ]
                )
            ]
        )

        return [
            (fileName: "Cuán Grande Es Él.pdf", data: cuanGrande),
            (fileName: "Sublime Gracia.pdf", data: sublimeGracia)
        ]
    }
}
