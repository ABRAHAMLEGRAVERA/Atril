import Foundation
import ImageIO
import PDFKit
import UIKit

/// Central native repository managing SQLite metadata, local FileManager binaries,
/// A8X 2 GB RAM bounded PDF/image render cache, 16 GB image optimization, and ZIP backup.
final class AtrilRepository {
    static let shared = AtrilRepository()

    private let fileManager = FileManager.default
    private let attachmentsDirectory: URL
    private let databaseURL: URL
    private let store: AtrilSQLiteStore

    // Bounded in-memory cache (48 MB ceiling) tuned for iPad Air 2 (2 GB RAM)
    private let renderCache = NSCache<NSString, UIImage>()
    private let pdfRenderQueue = DispatchQueue(label: "com.atril.pdf.render", qos: .userInitiated)
    private let fileIOQueue = DispatchQueue(label: "com.atril.file.io", qos: .userInitiated)

    private init() {
        let docs = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first
            ?? fileManager.temporaryDirectory
        let rootDir = docs.appendingPathComponent("AtrilData", isDirectory: true)
        let attDir = rootDir.appendingPathComponent("Attachments", isDirectory: true)
        try? fileManager.createDirectory(at: attDir, withIntermediateDirectories: true)

        self.attachmentsDirectory = attDir
        self.databaseURL = rootDir.appendingPathComponent("atril.sqlite3")
        do {
            self.store = try AtrilSQLiteStore(databaseURL: databaseURL)
        } catch {
            // Fallback inside temporary directory if documents fails
            let fallbackURL = fileManager.temporaryDirectory.appendingPathComponent("atril_fallback.sqlite3")
            self.store = try! AtrilSQLiteStore(databaseURL: fallbackURL)
        }

        renderCache.totalCostLimit = 48 * 1024 * 1024
        renderCache.countLimit = 36

        NotificationCenter.default.addObserver(
            self,
            selector: #selector(handleMemoryWarning),
            name: UIApplication.didReceiveMemoryWarningNotification,
            object: nil
        )
    }

    deinit {
        NotificationCenter.default.removeObserver(self)
    }

    @objc private func handleMemoryWarning() {
        renderCache.removeAllObjects()
    }

    func clearRenderCache() {
        renderCache.removeAllObjects()
    }

    // MARK: - Bootstrap & Notes

    func bootstrap() throws -> (notes: [Note], preferences: AppPreferences) {
        var notes = try store.fetchAllNotes()
        let prefs = store.fetchPreferences()

        if !store.isSeeded() && notes.isEmpty {
            notes = try seedDefaultNotes()
            store.markSeeded()
        } else if !store.isSeeded() {
            store.markSeeded()
        }

        return (notes, prefs)
    }

    private func seedDefaultNotes() throws -> [Note] {
        let nowMs = Int64(Date().timeIntervalSince1970 * 1000)
        let sheets = SamplePdfGenerator.generateDefaultSheets()

        var domingoAtts: [NoteAttachment] = []
        var domingoBlocks: [NoteBlock] = [
            NoteBlock(id: NoteLogic.createId(prefix: "blk"), text: "Tonalidad: La mayor (A)\nCapo 2 en guitarra acústica.\nSubir un punto en el último coro.")
        ]

        for item in sheets {
            let attId = NoteLogic.createId(prefix: "att")
            try saveBinaryData(item.data, forAttachmentId: attId)
            let doc = PDFDocument(data: item.data)
            let pageCount = max(1, doc?.pageCount ?? 1)
            let att = NoteAttachment(
                id: attId,
                fileName: item.fileName,
                kind: .pdf,
                mimeType: "application/pdf",
                size: Int64(item.data.count),
                pageCount: pageCount,
                createdAt: nowMs
            )
            domingoAtts.append(att)
            domingoBlocks.append(NoteBlock(id: NoteLogic.createId(prefix: "blk"), attachmentId: attId))
        }
        domingoBlocks.append(NoteBlock(id: NoteLogic.createId(prefix: "blk"), text: ""))

        let sundayNote = Note(
            id: NoteLogic.createId(prefix: "note"),
            title: "Domingo",
            body: NoteLogic.deriveBodyFromBlocks(domingoBlocks),
            pinned: true,
            attachments: domingoAtts,
            blocks: domingoBlocks,
            createdAt: nowMs - 86_400_000,
            updatedAt: nowMs - 3_600_000
        )

        let ideasBody = "Progresión puente: IV – V – vi – iii\nRecordar entrada suave con piano en compás 9."
        let ideasNote = Note(
            id: NoteLogic.createId(prefix: "note"),
            title: "Ideas y acordes",
            body: ideasBody,
            pinned: false,
            attachments: [],
            blocks: [NoteBlock(id: NoteLogic.createId(prefix: "blk"), text: ideasBody)],
            createdAt: nowMs - 172_800_000,
            updatedAt: nowMs - 7_200_000
        )

        try store.upsertNote(sundayNote)
        try store.upsertNote(ideasNote)
        return [sundayNote, ideasNote]
    }

    func getAllNotes() throws -> [Note] {
        return try store.fetchAllNotes()
    }

    func saveNote(_ note: Note) throws {
        try store.upsertNote(note)
    }

    func deleteNoteAndFiles(_ note: Note) throws {
        for att in note.attachments {
            deleteBinary(forAttachmentId: att.id)
        }
        try store.deleteNote(id: note.id)
    }

    func getPreferences() -> AppPreferences {
        return store.fetchPreferences()
    }

    func savePreferences(_ prefs: AppPreferences) {
        store.savePreferences(prefs)
    }

    // MARK: - Local File Storage (FileManager)

    func attachmentURL(for attachmentId: String) -> URL {
        let safeId = attachmentId.replacingOccurrences(of: "[^a-zA-Z0-9_-]", with: "_", options: .regularExpression)
        return attachmentsDirectory.appendingPathComponent("\(safeId).bin")
    }

    func saveBinaryData(_ data: Data, forAttachmentId attachmentId: String) throws {
        let url = attachmentURL(for: attachmentId)
        try data.write(to: url, options: .atomic)
    }

    func loadBinaryData(forAttachmentId attachmentId: String) -> Data? {
        let url = attachmentURL(for: attachmentId)
        return try? Data(contentsOf: url, options: .mappedIfSafe)
    }

    func deleteBinary(forAttachmentId attachmentId: String) {
        let url = attachmentURL(for: attachmentId)
        try? fileManager.removeItem(at: url)
    }

    // MARK: - Image Optimization (16 GB iPad Air 2 Storage Protection)

    func prepareImportedFile(rawData: Data, fileName: String, mimeType: String?, optimizeFor16GB: Bool) -> (attachment: NoteAttachment, storedData: Data)? {
        guard let kind = NoteLogic.detectAttachmentKind(fileName: fileName, mimeType: mimeType) else {
            return nil
        }
        let attId = NoteLogic.createId(prefix: "att")
        let nowMs = Int64(Date().timeIntervalSince1970 * 1000)

        if kind == .pdf {
            guard let pdfDoc = PDFDocument(data: rawData) else { return nil }
            let pages = max(1, pdfDoc.pageCount)
            let att = NoteAttachment(
                id: attId,
                fileName: fileName,
                kind: .pdf,
                mimeType: "application/pdf",
                size: Int64(rawData.count),
                pageCount: pages,
                createdAt: nowMs
            )
            return (att, rawData)
        }

        // Image: optimize via ImageIO downsampling when enabled (never decodes huge raw buffer unnecessarily)
        var finalData = rawData
        var finalMime = mimeType ?? "image/jpeg"
        var finalName = fileName

        if optimizeFor16GB, let compressed = downsampleImageData(rawData, maxPixelSize: 1800, quality: 0.82) {
            if compressed.count < rawData.count {
                finalData = compressed
                finalMime = "image/jpeg"
                let base = (fileName as NSString).deletingPathExtension
                finalName = "\(base.isEmpty ? "imagen" : base).jpg"
            }
        }

        let att = NoteAttachment(
            id: attId,
            fileName: finalName,
            kind: .image,
            mimeType: finalMime,
            size: Int64(finalData.count),
            pageCount: 1,
            createdAt: nowMs
        )
        return (att, finalData)
    }

    func downsampleImageData(_ data: Data, maxPixelSize: CGFloat, quality: CGFloat) -> Data? {
        let sourceOptions: [CFString: Any] = [kCGImageSourceShouldCache: false]
        guard let source = CGImageSourceCreateWithData(data as CFData, sourceOptions as CFDictionary) else {
            return nil
        }
        let thumbOptions: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceShouldCacheImmediately: true,
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceThumbnailMaxPixelSize: maxPixelSize
        ]
        guard let cgImage = CGImageSourceCreateThumbnailAtIndex(source, 0, thumbOptions as CFDictionary) else {
            return nil
        }
        let uiImage = UIImage(cgImage: cgImage)
        return uiImage.jpegData(compressionQuality: quality)
    }

    // MARK: - Asynchronous PDF & Image Rendering with Bounded NSCache

    func renderThumbnail(
        for attachment: NoteAttachment,
        pageNumber: Int,
        targetWidthPoints: CGFloat,
        scale: CGFloat = 1.5,
        completion: @escaping (UIImage?) -> Void
    ) {
        let clampedScale = min(2.0, max(1.0, scale))
        let pixelWidth = max(240, Int(targetWidthPoints * clampedScale))
        let key = "\(attachment.id):p\(pageNumber):w\(pixelWidth)" as NSString

        if let cached = renderCache.object(forKey: key) {
            completion(cached)
            return
        }

        pdfRenderQueue.async { [weak self] in
            guard let self = self else { return }
            if let cached = self.renderCache.object(forKey: key) {
                DispatchQueue.main.async { completion(cached) }
                return
            }

            let url = self.attachmentURL(for: attachment.id)
            var rendered: UIImage?

            if attachment.kind == .image {
                if let source = CGImageSourceCreateWithURL(url as CFURL, [kCGImageSourceShouldCache: false] as CFDictionary) {
                    let opts: [CFString: Any] = [
                        kCGImageSourceCreateThumbnailFromImageAlways: true,
                        kCGImageSourceShouldCacheImmediately: true,
                        kCGImageSourceCreateThumbnailWithTransform: true,
                        kCGImageSourceThumbnailMaxPixelSize: min(2048, pixelWidth)
                    ]
                    if let cgImg = CGImageSourceCreateThumbnailAtIndex(source, 0, opts as CFDictionary) {
                        rendered = UIImage(cgImage: cgImg)
                    }
                }
            } else if let pdfDoc = PDFDocument(url: url),
                      let page = pdfDoc.page(at: max(0, pageNumber - 1)) {
                let pageBounds = page.bounds(for: .cropBox)
                let aspect = pageBounds.width > 0 ? (pageBounds.height / pageBounds.width) : 1.33
                let renderW = CGFloat(min(1800, pixelWidth))
                let renderH = max(120, renderW * aspect)
                let format = UIGraphicsImageRendererFormat()
                format.scale = 1.0
                format.opaque = true
                let renderer = UIGraphicsImageRenderer(size: CGSize(width: renderW, height: renderH), format: format)
                rendered = renderer.image { ctx in
                    UIColor.white.setFill()
                    ctx.fill(CGRect(x: 0, y: 0, width: renderW, height: renderH))
                    ctx.cgContext.translateBy(x: 0, y: renderH)
                    ctx.cgContext.scaleBy(x: 1.0, y: -1.0)
                    let sx = renderW / max(1, pageBounds.width)
                    let sy = renderH / max(1, pageBounds.height)
                    ctx.cgContext.scaleBy(x: sx, y: sy)
                    ctx.cgContext.translateBy(x: -pageBounds.minX, y: -pageBounds.minY)
                    page.draw(with: .cropBox, to: ctx.cgContext)
                }
            }

            if let img = rendered {
                let cost = Int(img.size.width * img.size.height * img.scale * img.scale * 4)
                self.renderCache.setObject(img, forKey: key, cost: max(1024, cost))
            }
            DispatchQueue.main.async {
                completion(rendered)
            }
        }
    }

    func loadPdfDocument(for attachmentId: String) -> PDFDocument? {
        let url = attachmentURL(for: attachmentId)
        return PDFDocument(url: url)
    }

    func loadFullImage(for attachmentId: String, completion: @escaping (UIImage?) -> Void) {
        let key = "full:\(attachmentId)" as NSString
        if let cached = renderCache.object(forKey: key) {
            completion(cached)
            return
        }
        fileIOQueue.async { [weak self] in
            guard let self = self else { return }
            let url = self.attachmentURL(for: attachmentId)
            var image: UIImage?
            if let source = CGImageSourceCreateWithURL(url as CFURL, [kCGImageSourceShouldCache: false] as CFDictionary) {
                let opts: [CFString: Any] = [
                    kCGImageSourceCreateThumbnailFromImageAlways: true,
                    kCGImageSourceShouldCacheImmediately: true,
                    kCGImageSourceCreateThumbnailWithTransform: true,
                    kCGImageSourceThumbnailMaxPixelSize: 2048
                ]
                if let cgImg = CGImageSourceCreateThumbnailAtIndex(source, 0, opts as CFDictionary) {
                    image = UIImage(cgImage: cgImg)
                }
            }
            if let img = image {
                let cost = Int(img.size.width * img.size.height * 4)
                self.renderCache.setObject(img, forKey: key, cost: max(1024, cost))
            }
            DispatchQueue.main.async {
                completion(image)
            }
        }
    }

    // MARK: - Storage Telemetry & ZIP Backup / Restore

    func getStorageStatus(notes: [Note]) -> StorageStatus {
        let attCount = notes.reduce(0) { $0 + $1.attachments.count }
        var totalAttBytes: Int64 = 0
        for note in notes {
            for att in note.attachments {
                let url = attachmentURL(for: att.id)
                if let attrs = try? fileManager.attributesOfItem(atPath: url.path),
                   let size = attrs[.size] as? NSNumber {
                    totalAttBytes += size.int64Value
                } else {
                    totalAttBytes += att.size
                }
            }
        }

        var freeBytes: Int64?
        if let values = try? attachmentsDirectory.resourceValues(forKeys: [.volumeAvailableCapacityForImportantUsageKey]),
           let cap = values.volumeAvailableCapacityForImportantUsage {
            freeBytes = cap
        }

        let nearLimit = (freeBytes ?? Int64.max) < 400 * 1024 * 1024
        return StorageStatus(
            attachmentsBytes: totalAttBytes,
            noteCount: notes.count,
            attachmentCount: attCount,
            deviceFreeBytes: freeBytes,
            isNearLimit: nearLimit
        )
    }

    func exportBackupZip() throws -> (url: URL, fileName: String, size: Int64) {
        let notes = try store.fetchAllNotes()
        let iso = ISO8601DateFormatter()
        let manifest = BackupManifest(
            app: "ATRIL",
            version: 2,
            exportedAt: iso.string(from: Date()),
            notes: notes
        )

        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        let manifestData = try encoder.encode(manifest)

        var entries: [ZipEntry] = [
            ZipEntry(path: "atril-backup.json", data: manifestData)
        ]

        for note in notes {
            for att in note.attachments {
                if let bin = loadBinaryData(forAttachmentId: att.id) {
                    let safeName = att.fileName.replacingOccurrences(of: "[^a-zA-Z0-9._-]", with: "_", options: .regularExpression)
                    entries.append(ZipEntry(path: "files/\(att.id)/\(safeName)", data: bin))
                }
            }
        }

        let zipData = ZipArchiveCodec.encode(entries: entries, compress: false)
        let df = DateFormatter()
        df.dateFormat = "yyyy-MM-dd"
        let fileName = "atril-notas-\(df.string(from: Date())).zip"
        let outURL = fileManager.temporaryDirectory.appendingPathComponent(fileName)
        try zipData.write(to: outURL, options: .atomic)
        return (outURL, fileName, Int64(zipData.count))
    }

    func inspectBackupZip(at url: URL) -> BackupInspectionResult {
        do {
            let accessed = url.startAccessingSecurityScopedResource()
            defer {
                if accessed { url.stopAccessingSecurityScopedResource() }
            }
            let data = try Data(contentsOf: url)
            let entries = try ZipArchiveCodec.decode(data: data)
            guard let manifestEntry = entries.first(where: { $0.path == "atril-backup.json" }) else {
                return BackupInspectionResult(
                    valid: false,
                    errors: ["No se encontró \"atril-backup.json\" en el archivo ZIP."],
                    manifest: nil,
                    fileCount: 0,
                    totalFilesBytes: 0
                )
            }
            let fileEntries = entries.filter { $0.path.hasPrefix("files/") }
            let totalBytes = fileEntries.reduce(Int64(0)) { $0 + Int64($1.data.count) }
            return NoteLogic.validateBackupManifest(
                data: manifestEntry.data,
                fileCount: fileEntries.count,
                totalFilesBytes: totalBytes
            )
        } catch {
            return BackupInspectionResult(
                valid: false,
                errors: [error.localizedDescription],
                manifest: nil,
                fileCount: 0,
                totalFilesBytes: 0
            )
        }
    }

    func restoreBackupZip(at url: URL, replaceAll: Bool) throws -> Int {
        let accessed = url.startAccessingSecurityScopedResource()
        defer {
            if accessed { url.stopAccessingSecurityScopedResource() }
        }
        let data = try Data(contentsOf: url)
        let entries = try ZipArchiveCodec.decode(data: data)
        guard let manifestEntry = entries.first(where: { $0.path == "atril-backup.json" }) else {
            throw ZipArchiveError.invalidArchive
        }
        let fileEntries = entries.filter { $0.path.hasPrefix("files/") }
        let totalBytes = fileEntries.reduce(Int64(0)) { $0 + Int64($1.data.count) }
        let inspection = NoteLogic.validateBackupManifest(data: manifestEntry.data, fileCount: fileEntries.count, totalFilesBytes: totalBytes)
        guard inspection.valid, let manifest = inspection.manifest else {
            throw ZipArchiveError.invalidArchive
        }

        if replaceAll {
            let oldNotes = try store.fetchAllNotes()
            for note in oldNotes {
                for att in note.attachments {
                    deleteBinary(forAttachmentId: att.id)
                }
            }
        }

        for entry in fileEntries {
            let components = entry.path.split(separator: "/")
            if components.count >= 2 {
                let attId = String(components[1])
                try saveBinaryData(entry.data, forAttachmentId: attId)
            }
        }

        if replaceAll {
            try store.replaceAllNotes(manifest.notes)
        } else {
            let existing = try store.fetchAllNotes()
            var byId = Dictionary(uniqueKeysWithValues: existing.map { ($0.id, $0) })
            for incoming in manifest.notes {
                byId[incoming.id] = incoming
            }
            let merged = Array(byId.values)
            try store.replaceAllNotes(merged)
        }

        renderCache.removeAllObjects()
        return manifest.notes.count
    }
}
