import Foundation
import SQLite3

private let SQLITE_TRANSIENT_DESTRUCTOR = unsafeBitCast(-1, to: sqlite3_destructor_type.self)

enum AtrilSQLiteError: LocalizedError {
    case openFailed(String)
    case prepareFailed(String)
    case stepFailed(String)

    var errorDescription: String? {
        switch self {
        case .openFailed(let msg): return "No se pudo abrir SQLite: \(msg)"
        case .prepareFailed(let msg): return "Error SQLite prepare: \(msg)"
        case .stepFailed(let msg): return "Error SQLite step: \(msg)"
        }
    }
}

/// Thread-safe SQLite store for ATRIL notes and app preferences.
final class AtrilSQLiteStore {
    private let queue = DispatchQueue(label: "com.atril.sqlite", qos: .userInitiated)
    private var db: OpaquePointer?
    private let encoder = JSONEncoder()
    private let decoder = JSONDecoder()

    init(databaseURL: URL) throws {
        var pointer: OpaquePointer?
        let flags = SQLITE_OPEN_CREATE | SQLITE_OPEN_READWRITE | SQLITE_OPEN_FULLMUTEX
        if sqlite3_open_v2(databaseURL.path, &pointer, flags, nil) != SQLITE_OK {
            let msg = pointer.flatMap { String(cString: sqlite3_errmsg($0)) } ?? "Unknown"
            sqlite3_close(pointer)
            throw AtrilSQLiteError.openFailed(msg)
        }
        self.db = pointer
        try execute("""
            PRAGMA journal_mode = WAL;
            CREATE TABLE IF NOT EXISTS notes (
                id TEXT PRIMARY KEY NOT NULL,
                title TEXT NOT NULL,
                body TEXT NOT NULL,
                pinned INTEGER NOT NULL DEFAULT 0,
                attachments_json TEXT NOT NULL,
                blocks_json TEXT NOT NULL,
                created_at INTEGER NOT NULL,
                updated_at INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS preferences (
                key TEXT PRIMARY KEY NOT NULL,
                value TEXT NOT NULL
            );
        """)
    }

    deinit {
        if let db = db {
            sqlite3_close(db)
        }
    }

    private func execute(_ sql: String) throws {
        try queue.sync {
            guard let db = self.db else { return }
            var errMsg: UnsafeMutablePointer<CChar>?
            if sqlite3_exec(db, sql, nil, nil, &errMsg) != SQLITE_OK {
                let message = errMsg.map { String(cString: $0) } ?? "Unknown"
                sqlite3_free(errMsg)
                throw AtrilSQLiteError.stepFailed(message)
            }
        }
    }

    func fetchAllNotes() throws -> [Note] {
        return try queue.sync {
            guard let db = self.db else { return [] }
            let sql = "SELECT id, title, body, pinned, attachments_json, blocks_json, created_at, updated_at FROM notes ORDER BY pinned DESC, updated_at DESC;"
            var stmt: OpaquePointer?
            guard sqlite3_prepare_v2(db, sql, -1, &stmt, nil) == SQLITE_OK else {
                throw AtrilSQLiteError.prepareFailed(String(cString: sqlite3_errmsg(db)))
            }
            defer { sqlite3_finalize(stmt) }

            var results: [Note] = []
            while sqlite3_step(stmt) == SQLITE_ROW {
                guard let idC = sqlite3_column_text(stmt, 0),
                      let titleC = sqlite3_column_text(stmt, 1),
                      let bodyC = sqlite3_column_text(stmt, 2),
                      let attJsonC = sqlite3_column_text(stmt, 4),
                      let blkJsonC = sqlite3_column_text(stmt, 5) else {
                    continue
                }
                let id = String(cString: idC)
                let title = String(cString: titleC)
                let body = String(cString: bodyC)
                let pinned = sqlite3_column_int(stmt, 3) != 0
                let attData = String(cString: attJsonC).data(using: .utf8) ?? Data("[]".utf8)
                let blkData = String(cString: blkJsonC).data(using: .utf8) ?? Data("[]".utf8)
                let createdAt = sqlite3_column_int64(stmt, 6)
                let updatedAt = sqlite3_column_int64(stmt, 7)

                let attachments = (try? decoder.decode([NoteAttachment].self, from: attData)) ?? []
                let blocks = (try? decoder.decode([NoteBlock].self, from: blkData)) ?? []

                results.append(Note(
                    id: id,
                    title: title,
                    body: body,
                    pinned: pinned,
                    attachments: attachments,
                    blocks: blocks,
                    createdAt: createdAt,
                    updatedAt: updatedAt
                ))
            }
            return results
        }
    }

    func upsertNote(_ note: Note) throws {
        try queue.sync {
            guard let db = self.db else { return }
            let sql = """
                INSERT OR REPLACE INTO notes
                (id, title, body, pinned, attachments_json, blocks_json, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?);
            """
            var stmt: OpaquePointer?
            guard sqlite3_prepare_v2(db, sql, -1, &stmt, nil) == SQLITE_OK else {
                throw AtrilSQLiteError.prepareFailed(String(cString: sqlite3_errmsg(db)))
            }
            defer { sqlite3_finalize(stmt) }

            let attJson = String(data: (try? encoder.encode(note.attachments)) ?? Data("[]".utf8), encoding: .utf8) ?? "[]"
            let blkJson = String(data: (try? encoder.encode(note.blocks)) ?? Data("[]".utf8), encoding: .utf8) ?? "[]"

            sqlite3_bind_text(stmt, 1, note.id, -1, SQLITE_TRANSIENT_DESTRUCTOR)
            sqlite3_bind_text(stmt, 2, note.title, -1, SQLITE_TRANSIENT_DESTRUCTOR)
            sqlite3_bind_text(stmt, 3, note.body, -1, SQLITE_TRANSIENT_DESTRUCTOR)
            sqlite3_bind_int(stmt, 4, note.pinned ? 1 : 0)
            sqlite3_bind_text(stmt, 5, attJson, -1, SQLITE_TRANSIENT_DESTRUCTOR)
            sqlite3_bind_text(stmt, 6, blkJson, -1, SQLITE_TRANSIENT_DESTRUCTOR)
            sqlite3_bind_int64(stmt, 7, note.createdAt)
            sqlite3_bind_int64(stmt, 8, note.updatedAt)

            guard sqlite3_step(stmt) == SQLITE_DONE else {
                throw AtrilSQLiteError.stepFailed(String(cString: sqlite3_errmsg(db)))
            }
        }
    }

    func deleteNote(id: String) throws {
        try queue.sync {
            guard let db = self.db else { return }
            let sql = "DELETE FROM notes WHERE id = ?;"
            var stmt: OpaquePointer?
            guard sqlite3_prepare_v2(db, sql, -1, &stmt, nil) == SQLITE_OK else {
                throw AtrilSQLiteError.prepareFailed(String(cString: sqlite3_errmsg(db)))
            }
            defer { sqlite3_finalize(stmt) }
            sqlite3_bind_text(stmt, 1, id, -1, SQLITE_TRANSIENT_DESTRUCTOR)
            guard sqlite3_step(stmt) == SQLITE_DONE else {
                throw AtrilSQLiteError.stepFailed(String(cString: sqlite3_errmsg(db)))
            }
        }
    }

    func replaceAllNotes(_ notes: [Note]) throws {
        try queue.sync {
            guard let db = self.db else { return }
            sqlite3_exec(db, "BEGIN IMMEDIATE TRANSACTION;", nil, nil, nil)
            do {
                var delStmt: OpaquePointer?
                guard sqlite3_prepare_v2(db, "DELETE FROM notes;", -1, &delStmt, nil) == SQLITE_OK else {
                    throw AtrilSQLiteError.prepareFailed(String(cString: sqlite3_errmsg(db)))
                }
                sqlite3_step(delStmt)
                sqlite3_finalize(delStmt)

                let sql = """
                    INSERT OR REPLACE INTO notes
                    (id, title, body, pinned, attachments_json, blocks_json, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?);
                """
                for note in notes {
                    var stmt: OpaquePointer?
                    guard sqlite3_prepare_v2(db, sql, -1, &stmt, nil) == SQLITE_OK else {
                        throw AtrilSQLiteError.prepareFailed(String(cString: sqlite3_errmsg(db)))
                    }
                    let attJson = String(data: (try? encoder.encode(note.attachments)) ?? Data("[]".utf8), encoding: .utf8) ?? "[]"
                    let blkJson = String(data: (try? encoder.encode(note.blocks)) ?? Data("[]".utf8), encoding: .utf8) ?? "[]"
                    sqlite3_bind_text(stmt, 1, note.id, -1, SQLITE_TRANSIENT_DESTRUCTOR)
                    sqlite3_bind_text(stmt, 2, note.title, -1, SQLITE_TRANSIENT_DESTRUCTOR)
                    sqlite3_bind_text(stmt, 3, note.body, -1, SQLITE_TRANSIENT_DESTRUCTOR)
                    sqlite3_bind_int(stmt, 4, note.pinned ? 1 : 0)
                    sqlite3_bind_text(stmt, 5, attJson, -1, SQLITE_TRANSIENT_DESTRUCTOR)
                    sqlite3_bind_text(stmt, 6, blkJson, -1, SQLITE_TRANSIENT_DESTRUCTOR)
                    sqlite3_bind_int64(stmt, 7, note.createdAt)
                    sqlite3_bind_int64(stmt, 8, note.updatedAt)
                    guard sqlite3_step(stmt) == SQLITE_DONE else {
                        sqlite3_finalize(stmt)
                        throw AtrilSQLiteError.stepFailed(String(cString: sqlite3_errmsg(db)))
                    }
                    sqlite3_finalize(stmt)
                }
                sqlite3_exec(db, "COMMIT;", nil, nil, nil)
            } catch {
                sqlite3_exec(db, "ROLLBACK;", nil, nil, nil)
                throw error
            }
        }
    }

    func fetchPreferences() -> AppPreferences {
        return queue.sync {
            guard let db = self.db else { return .default }
            let sql = "SELECT value FROM preferences WHERE key = 'app_prefs';"
            var stmt: OpaquePointer?
            guard sqlite3_prepare_v2(db, sql, -1, &stmt, nil) == SQLITE_OK else { return .default }
            defer { sqlite3_finalize(stmt) }
            if sqlite3_step(stmt) == SQLITE_ROW, let textC = sqlite3_column_text(stmt, 0) {
                let data = String(cString: textC).data(using: .utf8) ?? Data()
                if let prefs = try? decoder.decode(AppPreferences.self, from: data) {
                    return prefs
                }
            }
            return .default
        }
    }

    func savePreferences(_ prefs: AppPreferences) {
        queue.sync {
            guard let db = self.db,
                  let encoded = try? encoder.encode(prefs),
                  let json = String(data: encoded, encoding: .utf8) else { return }
            let sql = "INSERT OR REPLACE INTO preferences (key, value) VALUES ('app_prefs', ?);"
            var stmt: OpaquePointer?
            guard sqlite3_prepare_v2(db, sql, -1, &stmt, nil) == SQLITE_OK else { return }
            defer { sqlite3_finalize(stmt) }
            sqlite3_bind_text(stmt, 1, json, -1, SQLITE_TRANSIENT_DESTRUCTOR)
            sqlite3_step(stmt)
        }
    }

    func isSeeded() -> Bool {
        return queue.sync {
            guard let db = self.db else { return false }
            let sql = "SELECT value FROM preferences WHERE key = 'seeded_v1';"
            var stmt: OpaquePointer?
            guard sqlite3_prepare_v2(db, sql, -1, &stmt, nil) == SQLITE_OK else { return false }
            defer { sqlite3_finalize(stmt) }
            return sqlite3_step(stmt) == SQLITE_ROW
        }
    }

    func markSeeded() {
        try? execute("INSERT OR REPLACE INTO preferences (key, value) VALUES ('seeded_v1', '1');")
    }
}
