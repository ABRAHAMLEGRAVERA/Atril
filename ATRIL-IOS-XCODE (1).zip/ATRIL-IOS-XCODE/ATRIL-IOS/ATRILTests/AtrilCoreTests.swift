import XCTest
@testable import ATRIL

final class AtrilCoreTests: XCTestCase {
    func testBpmClampingAndTempoMarking() {
        XCTAssertEqual(MusicStudioMath.clampBpm(10), MusicStudioMath.bpmMin)
        XCTAssertEqual(MusicStudioMath.clampBpm(400), MusicStudioMath.bpmMax)
        XCTAssertEqual(MusicStudioMath.clampBpm(99), 99)
        XCTAssertEqual(MusicStudioMath.tempoMarking(for: 52), "Largo")
        XCTAssertEqual(MusicStudioMath.tempoMarking(for: 120), "Allegro")
    }

    func testSubdivisionsAndAccents() {
        XCTAssertEqual(MusicStudioMath.beatsCount(for: .fourFour), 4)
        XCTAssertEqual(MusicStudioMath.beatsCount(for: .threeFour), 3)
        XCTAssertEqual(MusicStudioMath.beatsCount(for: .sixEight), 6)

        XCTAssertEqual(MusicStudioMath.subdivisionCount(for: .quarter), 1)
        XCTAssertEqual(MusicStudioMath.subdivisionCount(for: .eighth), 2)
        XCTAssertEqual(MusicStudioMath.subdivisionCount(for: .triplet), 3)

        XCTAssertEqual(MusicStudioMath.subdivisionStepSeconds(bpm: 120, subdivision: .eighth), 0.25, accuracy: 0.0001)
    }

    func testYinPitchDetectorOnA4() {
        let sr = 44100.0
        let count = 4096
        let freq = 440.0
        let samples: [Float] = (0..<count).map { i in
            Float(0.4 * sin(2.0 * Double.pi * freq * Double(i) / sr))
        }
        let detected = MusicStudioMath.detectPitchYIN(samples: samples, sampleRate: sr)
        XCTAssertNotNil(detected)
        XCTAssertEqual(detected ?? 0, 440.0, accuracy: 1.5)
    }

    func testInsertAndRemoveInterleavedSheetBlocks() {
        let initial = [NoteBlock(id: "b1", text: "Intro\nCoro")]
        let inserted = NoteLogic.insertSheetsIntoBlocks(
            initial,
            targetTextBlockId: "b1",
            cursorPos: 5,
            newAttachmentIds: ["att-1"]
        )
        XCTAssertEqual(inserted.count, 3)
        XCTAssertEqual(inserted[0].text, "Intro")
        XCTAssertEqual(inserted[1].attachmentId, "att-1")
        XCTAssertEqual(inserted[2].text, "Coro")

        let removed = NoteLogic.removeSheetFromBlocks(inserted, attachmentId: "att-1")
        XCTAssertEqual(removed.count, 1)
        XCTAssertEqual(removed[0].text, "Intro\nCoro")
    }

    func testZipArchiveRoundTrip() throws {
        let jsonData = Data("{\"app\":\"ATRIL\",\"version\":2}".utf8)
        let pdfPayload = Data(repeating: 0x41, count: 2048)
        let encoded = ZipArchiveCodec.encode(entries: [
            ZipEntry(path: "atril-backup.json", data: jsonData),
            ZipEntry(path: "files/att-1/partitura.pdf", data: pdfPayload)
        ], compress: true)

        let decoded = try ZipArchiveCodec.decode(data: encoded)
        XCTAssertEqual(decoded.count, 2)
        XCTAssertEqual(decoded[0].path, "atril-backup.json")
        XCTAssertEqual(decoded[0].data, jsonData)
        XCTAssertEqual(decoded[1].path, "files/att-1/partitura.pdf")
        XCTAssertEqual(decoded[1].data, pdfPayload)
    }
}
